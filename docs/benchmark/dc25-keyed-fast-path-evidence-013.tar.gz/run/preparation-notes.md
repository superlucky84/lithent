## 관찰된 한계와 준비 실패

- 단순 동일 객체 조기 반환은 children getter의 기존 관찰을 지운다. 새 baseline 회귀는 기준/결합 후보에서 통과하고 해당 shortcut을 넣은 negative control에서 실패했다. 이번 후보에서 제외했으며, 관찰을 보존하는 모든 대안을 기각한 것은 아니다.
- 실제 sparse array hole은 기존 base에서 원래 노드를 삭제하지만, unchanged concurrent에서는 `undefined.type` TypeError가 발생한다. 새 회귀는 각 코어의 기존 관찰을 구분해 확인한다. DC-25가 만든 회귀로 분류하거나 이 최적화에서 함께 수정하지 않았다. `null`/`undefined` 값으로 채운 dense 배열과 실제 hole은 다르다.
- 첫 격리 declaration build는 `/tmp`와 `/private/tmp`의 TS root 불일치로 실패했다. 상대 baseUrl로 해결했고 실패 config/dist/log는 별도 보존했다.
- 과거 고정 Chrome155는 완전한 app bundle이 아니어서 SIGKILL로 시작하지 못했다. 설치된 Chrome156을 새로 고정했다. 실패 브라우저 실행은 공식 측정 표본이 아니다.
- 첫 counter 도구는 주입한 `return` 뒤 개행의 ASI로 key를 잃었다. 실패 출력/로그를 보존하고 표현식을 괄호로 감싼 별도 v2 계측에서 계약·카운터 감사를 통과했다. production 소스는 해당 계측을 포함하지 않는다.
- 과거 peer 의존성 캐시는 필수 package가 빠져 검증에서 중단됐다. 새 실험 staging에 각 고정 lock으로 `npm ci --ignore-scripts` 후 버전을 대조하고 네 peer를 다시 빌드했다. sibling과 기존 캐시는 수정하지 않았다.

- 첫 공통 DOM 계약 adapter는 격리 디렉터리에서 @playwright/test를 찾지 못했다. 패키지 해석용 node_modules 링크를 추가한 별도 v2 실행에서 6앱 DOM 계약을 통과했으며 실패 driver/log를 보존했다.
