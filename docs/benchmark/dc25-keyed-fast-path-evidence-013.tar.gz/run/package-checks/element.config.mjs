export default {
    root: "/Users/n250109005/project/lithent/element",
    cacheDir: "/private/tmp/lithent-dc25-20261027/package-checks/element-cache",
    resolve: { alias: [
      { find: /^lithent$/, replacement: "/private/tmp/lithent-dc25-20261027/candidate/dist/lithent.mjs" },
      { find: '@', replacement: "/Users/n250109005/project/lithent/element/src" }
    ] },
    test: {"environment":"jsdom","include":["src/tests/*.test.{ts,tsx}"],"maxWorkers":1,"minWorkers":1}
  };
