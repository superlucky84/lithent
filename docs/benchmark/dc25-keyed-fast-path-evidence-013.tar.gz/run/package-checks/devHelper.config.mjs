export default {
    root: "/Users/n250109005/project/lithent/devHelper",
    cacheDir: "/private/tmp/lithent-dc25-20261027/package-checks/devHelper-cache",
    resolve: { alias: [
      { find: /^lithent$/, replacement: "/private/tmp/lithent-dc25-20261027/candidate/dist/lithent.mjs" },
      { find: '@', replacement: "/Users/n250109005/project/lithent/devHelper/src" }
    ] },
    test: {"environment":"jsdom","includeSource":["src/tests/*.{js,ts,jsx,tsx}"],"maxWorkers":1,"minWorkers":1}
  };
