"""A vs V1 (same V1 build 59b6d8f9eab9) across every session that measured both."""
import json, math, statistics, sys
from pathlib import Path
base = Path(sys.argv[1])
sessions = [
    ("v12 main", "results-v12-main", "lithent-x1"),
    ("v12 reverse", "results-v12-reverse", "lit-b1"),
    ("v4 main", "results-v4-main", "lithent-x1"),
    ("v4 reverse", "results-v4-reverse", "lit-b1"),
]
cpu = ["01_run1k", "02_replace1k", "03_update10th1k_x16", "04_select1k", "05_swap1k",
       "06_remove-one-1k", "07_create10k", "08_create1k-after1k_x2", "09_clear1k_x8"]
w = [0.64280248137063, 0.5607178150466176, 0.5643800750716564, 0.1925635870170522,
     0.13200612879341714, 0.5277091212292658, 0.5644449600965534, 0.5508359820582848,
     0.4225836631419211]
def xs(folder, fw, b, k):
    return json.loads((base / folder / f"{fw}-v1.25.3-keyed_{b}.json").read_text())["values"][k]["values"]
def wg(r): return math.exp(sum(wi * math.log(x) for x, wi in zip(r, w)) / sum(w)) - 1
pool = {k: {"A": {b: [] for b in cpu}, "V1": {b: [] for b in cpu}} for k in ("total", "script")}
for name, folder, v1 in sessions:
    out = []
    for k in ("total", "script"):
        r = []
        for b in cpu:
            a, v = xs(folder, "lithent", b, k), xs(folder, v1, b, k)
            pool[k]["A"][b] += a; pool[k]["V1"][b] += v
            r.append(statistics.median(v) / statistics.median(a))
        out.append(f"{k} {wg(r):+.1%}")
        if k == "total":
            r_nosel = [x for x, b in zip(r, cpu)]
    print(f"{name:12} " + ", ".join(out))
print("pooled 4 sessions:")
for k in ("total", "script"):
    r = [statistics.median(pool[k]["V1"][b]) / statistics.median(pool[k]["A"][b]) for b in cpu]
    print(f"  {k}: weighted {wg(r):+.1%}  per bench " + " ".join(f"{b[:2]}:{x - 1:+.1%}" for b, x in zip(cpu, r)))
