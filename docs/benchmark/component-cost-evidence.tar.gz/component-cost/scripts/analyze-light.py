"""Light-component experiment: A, A', C, C' medians and weighted ratios."""
import json
import math
import sys
from pathlib import Path

results = Path(sys.argv[1])
fws = {
    "A": "lithent-v1.25.3-keyed",
    "A'": "lithent-light-v1.25.3-keyed",
    "C": "lithent-row-memo-v1.25.3-keyed",
    "C'": "lithent-row-memo-light-v1.25.3-keyed",
}
cpu = [
    "01_run1k", "02_replace1k", "03_update10th1k_x16", "04_select1k", "05_swap1k",
    "06_remove-one-1k", "07_create10k", "08_create1k-after1k_x2", "09_clear1k_x8",
]
weights = [
    0.64280248137063, 0.5607178150466176, 0.5643800750716564, 0.1925635870170522,
    0.13200612879341714, 0.5277091212292658, 0.5644449600965534, 0.5508359820582848,
    0.4225836631419211,
]
mem = ["21_ready-memory", "22_run-memory", "25_run-clear-memory"]
pairs = [("A'", "A"), ("C", "A"), ("C'", "A"), ("C'", "C")]


def load(fw, bench):
    return json.loads((results / f"{fw}_{bench}.json").read_text())["values"]


names = list(fws)
tot = {n: {b: load(fws[n], b)["total"]["median"] for b in cpu} for n in names}
js = {n: {b: load(fws[n], b)["script"]["median"] for b in cpu} for n in names}


def pct(x, y):
    return f"{x / y - 1:+.1%}"


def table(title, data):
    print(title)
    print(f"{'bench':24}" + "".join(f"{n:>8}" for n in names) + "".join(f"{x + '/' + y:>8}" for x, y in pairs))
    for b in cpu:
        print(
            f"{b:24}" + "".join(f"{data[n][b]:>8.1f}" for n in names)
            + "".join(f"{pct(data[x][b], data[y][b]):>8}" for x, y in pairs)
        )
    print()


table("total median ms", tot)
table("script median ms", js)


def weighted(x, y, data):
    acc = sum(w * math.log(data[x][b] / data[y][b]) for b, w in zip(cpu, weights))
    return math.exp(acc / sum(weights))


print("weighted geometric mean of ratios")
for x, y in pairs:
    print(f"  {x:>2} / {y:<2} total {weighted(x, y, tot) - 1:+.1%}   script {weighted(x, y, js) - 1:+.1%}")

print("\nmemory MB")
for b in mem:
    print(f"{b:24}" + "".join(f"{load(fws[n], b)['DEFAULT']['median']:>8.2f}" for n in names))
