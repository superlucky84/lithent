#!/bin/bash
# V1 and V4 cores on the A app, under two names each so the runner order flips:
#   main:    lithent, lithent-x1 (V1), lithent-x4 (V4)
#   reverse: lit-a4 (V4), lit-b1 (V1), lithent
set -euo pipefail
S=/private/tmp/claude-501/-Users-n250109005-project-lithent/13ee46ac-bf92-49ec-a236-19617334cec4/scratchpad
K="$HOME/project/js-framework-benchmark-upstream/frameworks/keyed"
setup() {
  local name=$1 core=$2
  local dir="$K/$name"
  rsync -a --delete --exclude /dist "$K/lithent/" "$dir/"
  cp "$core/lithent.mjs" "$core/lithent.cjs" "$core/lithent.umd.js" "$dir/node_modules/lithent/dist/"
  (cd "$dir" && npm run build-prod > /dev/null 2>&1)
  echo "[$name] core $(shasum -a 256 "$dir/node_modules/lithent/dist/lithent.mjs" | cut -c1-12) main.js $(shasum -a 256 "$dir/dist/main.js" | cut -c1-12)"
}
setup lithent-x1 "$S/h-cand-dist"
setup lit-b1 "$S/h-cand-dist"
setup lithent-x4 "$S/v4-cand-dist"
setup lit-a4 "$S/v4-cand-dist"
echo "[lithent] core $(shasum -a 256 "$K/lithent/node_modules/lithent/dist/lithent.mjs" | cut -c1-12) main.js $(shasum -a 256 "$K/lithent/dist/main.js" | cut -c1-12)"
