"""Wrapper-reuse experiment: A, B, B', C, C' medians and weighted ratios."""
import json
import math
import sys
from pathlib import Path

results = Path(sys.argv[1])
fws = {
    "A": "lithent-v1.25.3-keyed",
    "B": "lithent-row-v1.25.3-keyed",
    "B'": "lithent-row-reuse-v1.25.3-keyed",
    "C": "lithent-row-memo-v1.25.3-keyed",
    "C'": "lithent-row-memo-reuse-v1.25.3-keyed",
}
cpu = [
    "01_run1k", "02_replace1k", "03_update10th1k_x16", "04_select1k", "05_swap1k",
    "06_remove-one-1k", "07_create10k", "08_create1k-after1k_x2", "09_clear1k_x8",
]
weights = [
    0.64280248137063, 0.5607178150466176, 0.5643800750716564, 0.1925635870170522,
    0.13200612879341714, 0.5277091212292658, 0.5644449600965534, 0.5508359820582848,
    0.4225836631419211,
]
mem = ["21_ready-memory", "22_run-memory", "25_run-clear-memory"]


def load(fw, bench):
    return json.loads((results / f"{fw}_{bench}.json").read_text())["values"]


names = list(fws)
tot = {n: {b: load(fws[n], b)["total"]["median"] for b in cpu} for n in names}
js = {n: {b: load(fws[n], b)["script"]["median"] for b in cpu} for n in names}


def pct(x, y):
    return f"{x / y - 1:+.1%}"


print("total median ms")
print(f"{'bench':24}" + "".join(f"{n:>9}" for n in names) + f"{'C/A':>9}{'C\'/A':>9}{'C\'/C':>9}{'B\'/B':>9}")
for b in cpu:
    t = tot
    print(
        f"{b:24}" + "".join(f"{t[n][b]:>9.1f}" for n in names)
        + f"{pct(t['C'][b], t['A'][b]):>9}{pct(t['C\''][b], t['A'][b]):>9}"
        + f"{pct(t['C\''][b], t['C'][b]):>9}{pct(t['B\''][b], t['B'][b]):>9}"
    )

print("\nscript median ms")
print(f"{'bench':24}" + "".join(f"{n:>9}" for n in names) + f"{'C\'/C':>9}")
for b in cpu:
    print(f"{b:24}" + "".join(f"{js[n][b]:>9.1f}" for n in names) + f"{pct(js['C\''][b], js['C'][b]):>9}")


def weighted(x, y, table):
    acc = sum(w * math.log(table[x][b] / table[y][b]) for b, w in zip(cpu, weights))
    return math.exp(acc / sum(weights))


print("\nweighted geometric mean of total-time ratios")
for x, y in (("B", "A"), ("C", "A"), ("C'", "A"), ("C'", "C"), ("B'", "B")):
    print(f"  {x:>2} / {y:<2} {weighted(x, y, tot) - 1:+.1%}   (script {weighted(x, y, js) - 1:+.1%})")

print("\nmemory MB")
for b in mem:
    print(f"{b:24}" + "".join(f"{load(fws[n], b)['DEFAULT']['median']:>9.2f}" for n in names))
