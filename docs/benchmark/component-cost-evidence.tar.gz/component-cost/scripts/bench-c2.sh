#!/bin/bash
# Two CPU sessions: candidate after A, then candidate before A.
set -uo pipefail
S=/private/tmp/claude-501/-Users-n250109005-project-lithent/13ee46ac-bf92-49ec-a236-19617334cec4/scratchpad/variants
R="$HOME/project/js-framework-benchmark-upstream/webdriver-ts"
cd "$R"
B="01_ 02_ 03_ 04_ 05_ 06_ 07_ 08_ 09_"
npm run bench -- keyed/lithent keyed/lithent-zc2 --headless true --benchmark $B
mkdir -p "$S/results-c2-main" && cp results/lithent-v1.25.3-keyed_0* results/lithent-zc2-v1.25.3-keyed_0* "$S/results-c2-main/"
npm run bench -- keyed/lit-c2 keyed/lithent --headless true --benchmark $B
mkdir -p "$S/results-c2-reverse" && cp results/lithent-v1.25.3-keyed_0* results/lit-c2-v1.25.3-keyed_0* "$S/results-c2-reverse/"
