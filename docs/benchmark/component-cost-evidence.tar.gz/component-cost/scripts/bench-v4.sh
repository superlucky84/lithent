#!/bin/bash
# Two CPU sessions. Main: A, V1, V4. Reverse: V4, V1, A.
set -uo pipefail
S=/private/tmp/claude-501/-Users-n250109005-project-lithent/13ee46ac-bf92-49ec-a236-19617334cec4/scratchpad/variants
cd "$HOME/project/js-framework-benchmark-upstream/webdriver-ts"
B="01_ 02_ 03_ 04_ 05_ 06_ 07_ 08_ 09_"
npm run bench -- keyed/lithent keyed/lithent-x1 keyed/lithent-x4 --headless true --benchmark $B
mkdir -p "$S/results-v4-main" && cp results/lithent-v1.25.3-keyed_0* results/lithent-x1-v1.25.3-keyed_0* results/lithent-x4-v1.25.3-keyed_0* "$S/results-v4-main/"
npm run bench -- keyed/lit-a4 keyed/lit-b1 keyed/lithent --headless true --benchmark $B
mkdir -p "$S/results-v4-reverse" && cp results/lithent-v1.25.3-keyed_0* results/lit-a4-v1.25.3-keyed_0* results/lit-b1-v1.25.3-keyed_0* "$S/results-v4-reverse/"
