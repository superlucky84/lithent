"""Build the row-component variants from the current lithent benchmark source.

Only the row type, row creation and table/row rendering change. The store,
data generation, buttons and App stay byte-identical.
"""
import sys
from pathlib import Path

src_path, out_dir = Path(sys.argv[1]), Path(sys.argv[2])
src = src_path.read_text()

ROW_CELLS = """      <tr class={props.selected ? "danger" : undefined}>
        <td class="col-md-1">{props.row.id}</td>
        <td class="col-md-4">
          <a onClick={onSelect}>{props.row.label}</a>
        </td>
        <td class="col-md-1">
          <a onClick={onRemove}>
            <span class="glyphicon glyphicon-remove" aria-hidden="true" />
          </a>
        </td>
        <td class="col-md-6" />
      </tr>"""

HANDLERS = """  const onSelect = () => {
    store.select(props.row.id);
    renewTable();
  };
  const onRemove = () => {
    store.remove(props.row.id);
    renewTable();
  };
"""

TABLE = """const Table = mount((renew) => {
  renewTable = renew;
  return () => (
    <Fragment>
      {store.state.rows.map((row) => (
        <RowView
          key={row.id}
          row={row}
          selected={store.state.selected === row.id}
        />
      ))}
    </Fragment>
  );
});
"""

ROW_PLAIN = (
    "const RowView = mount<RowProps>((_renew, props) => {\n"
    + HANDLERS
    + "  return () => (\n"
    + ROW_CELLS
    + "\n  );\n});\n"
)

ROW_MEMO = (
    "const RowView = mount<RowProps>((_renew, props) => {\n"
    + HANDLERS
    + "  return cacheUpdate(\n"
    + "    () => [props.row.label, props.selected],\n"
    + "    () => (\n"
    + "\n".join("  " + line for line in ROW_CELLS.splitlines())
    + "\n    ),\n  );\n});\n"
)


def build(row_component: str, keep_helper: bool) -> str:
    out = src
    old_import = 'import { cacheUpdate } from "lithent/helper";\n'
    assert old_import in out
    if not keep_helper:
        out = out.replace(old_import, "")
    old_type = "type Row = { id: number; label: string; view: ReturnType<typeof cacheUpdate> };"
    assert old_type in out
    out = out.replace(
        old_type,
        "type Row = { id: number; label: string };\n"
        "type RowProps = { key: number; row: Row; selected: boolean };",
    )
    old_build = "data[i] = makeRow(nextId, buildLabel());"
    assert old_build in out
    out = out.replace(old_build, "data[i] = { id: nextId, label: buildLabel() };")
    start = out.index("function makeRow(")
    end = out.index("const App = mount(")
    return out[:start] + row_component + "\n" + TABLE + "\n" + out[end:]


out_dir.mkdir(parents=True, exist_ok=True)
(out_dir / "row-main.tsx").write_text(build(ROW_PLAIN, keep_helper=False))
(out_dir / "row-memo-main.tsx").write_text(build(ROW_MEMO, keep_helper=True))
print("ok")
