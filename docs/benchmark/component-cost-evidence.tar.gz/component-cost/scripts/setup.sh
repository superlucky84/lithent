#!/bin/bash
# Create the two temporary variant apps next to keyed/lithent, typecheck and
# build them, then run the upstream keyed check against all three.
set -euo pipefail
S=/private/tmp/claude-501/-Users-n250109005-project-lithent/13ee46ac-bf92-49ec-a236-19617334cec4/scratchpad/variants
ROOT="$HOME/project/js-framework-benchmark-upstream"
K="$ROOT/frameworks/keyed"

for v in row row-memo; do
  rsync -a --delete --exclude /dist "$K/lithent/" "$K/lithent-$v/"
  cp "$S/$v-main.tsx" "$K/lithent-$v/src/main.tsx"
  (cd "$K/lithent-$v" && npx tsc --noEmit -p . && echo "[$v] tsc ok" && npm run build-prod 2>&1 | tail -4)
done

# The benchmark harness needs the static server on :8080.
if ! curl -s -o /dev/null http://localhost:8080/; then
  (cd "$ROOT" && nohup npm start > "$S/server.log" 2>&1 &)
  for _ in $(seq 1 20); do
    curl -s -o /dev/null http://localhost:8080/ && break
    perl -e 'select(undef,undef,undef,0.5)'
  done
fi

cd "$ROOT/webdriver-ts"
npm run isKeyed -- --runner playwright --headless true keyed/lithent keyed/lithent-row keyed/lithent-row-memo 2>&1 | grep -E "is keyed|is not keyed|ERROR|Error" || true
