"""A vs V1 (early return) vs V4 (block-scoped closure variable), two sessions with opposite order."""
import json
import math
import statistics
import sys
from pathlib import Path

base = Path(sys.argv[1])
sessions = {
    "main (A, V1, V4)": (base / "results-v4-main", {"A": "lithent", "V1": "lithent-x1", "V4": "lithent-x4"}),
    "reverse (V4, V1, A)": (base / "results-v4-reverse", {"A": "lithent", "V1": "lit-b1", "V4": "lit-a4"}),
}
cpu = [
    "01_run1k", "02_replace1k", "03_update10th1k_x16", "04_select1k", "05_swap1k",
    "06_remove-one-1k", "07_create10k", "08_create1k-after1k_x2", "09_clear1k_x8",
]
weights = [
    0.64280248137063, 0.5607178150466176, 0.5643800750716564, 0.1925635870170522,
    0.13200612879341714, 0.5277091212292658, 0.5644449600965534, 0.5508359820582848,
    0.4225836631419211,
]
roles = ["A", "V1", "V4"]
pairs = [("V1", "A"), ("V4", "A"), ("V4", "V1")]


def samples(folder, fw, bench, kind):
    return json.loads((folder / f"{fw}-v1.25.3-keyed_{bench}.json").read_text())["values"][kind]["values"]


def weighted(ratios):
    return math.exp(sum(w * math.log(r) for r, w in zip(ratios, weights)) / sum(weights)) - 1


def report(title, med):
    print(f"== {title}")
    head = f"{'bench':24}" + "".join(f"{r:>8}" for r in roles) + "".join(f"{x + '/' + y:>9}" for x, y in pairs)
    for kind in ("total", "script"):
        print(f"  [{kind}]")
        print("  " + head)
        for b in cpu:
            m = med[kind]
            print(
                f"  {b:24}" + "".join(f"{m[r][b]:>8.1f}" for r in roles)
                + "".join(f"{m[x][b] / m[y][b] - 1:>+9.1%}" for x, y in pairs)
            )
    for kind in ("total", "script"):
        m = med[kind]
        parts = ", ".join(f"{x}/{y} {weighted([m[x][b] / m[y][b] for b in cpu]):+.1%}" for x, y in pairs)
        print(f"  weighted {kind}: {parts}")
    print()


pool = {k: {r: {b: [] for b in cpu} for r in roles} for k in ("total", "script")}
for title, (folder, names) in sessions.items():
    med = {k: {r: {} for r in roles} for k in ("total", "script")}
    for kind in ("total", "script"):
        for r in roles:
            for b in cpu:
                xs = samples(folder, names[r], b, kind)
                pool[kind][r][b] += xs
                med[kind][r][b] = statistics.median(xs)
    report(title, med)

report("pooled", {k: {r: {b: statistics.median(pool[k][r][b]) for b in cpu} for r in roles} for k in pool})
