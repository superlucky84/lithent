"""Recompute the published CPU weighted geometric mean from results.ts and
place the measured B/C ratios relative to the published lithent score."""
import json
import math
import re
import statistics
import sys
from pathlib import Path

text = Path(sys.argv[1]).read_text()
ratios = {"B row, no cache": float(sys.argv[2]), "C row + cacheUpdate": float(sys.argv[3])}


def grab(name):
    start = text.index(f"export const {name}")
    start = text.index("=", start) + 1
    end = text.index("\nexport const", start) if "\nexport const" in text[start:] else len(text)
    body = text[start:end].strip().rstrip(";").rstrip()
    body = re.sub(r",\s*\]$", "]", body)
    return json.loads(body)


results, frameworks, benchmarks = grab("results"), grab("frameworks"), grab("benchmarks")
weights = [
    0.64280248137063, 0.5607178150466176, 0.5643800750716564, 0.1925635870170522,
    0.13200612879341714, 0.5277091212292658, 0.5644449600965534, 0.5508359820582848,
    0.4225836631419211,
]
cpu_ids = [b["id"] for b in benchmarks if b["id"][:2] in {f"0{i}" for i in range(1, 10)}]

for stat_name, stat in (("median", statistics.median), ("mean", statistics.fmean)):
    table = {}
    for r in results:
        name = frameworks[r["f"]]["name"]
        for entry in r["b"]:
            bid = benchmarks[entry["b"]]["id"]
            if bid in cpu_ids and "total" in entry["v"]:
                table.setdefault(name, {})[bid] = stat(entry["v"]["total"])
    complete = {n: v for n, v in table.items() if len(v) == len(cpu_ids)}
    mins = {b: min(v[b] for v in complete.values()) for b in cpu_ids}
    scores = {
        n: math.exp(sum(w * math.log(v[b] / mins[b]) for b, w in zip(cpu_ids, weights)) / sum(weights))
        for n, v in complete.items()
    }
    ranked = sorted(scores.items(), key=lambda kv: kv[1])
    lith = next(n for n in scores if n.startswith("lithent-"))
    base = scores[lith]
    print(f"\n[{stat_name}] {len(ranked)} frameworks; {lith} = {base:.3f}, rank {[n for n, _ in ranked].index(lith) + 1}")
    for label, ratio in ratios.items():
        est = base * ratio
        rank = sum(1 for _, s in ranked if s < est and not _ == base) + 1
        print(f"  {label:22} est {est:.3f}, about rank {rank}")
    names_of_interest = ("vanillajs", "solid", "svelte", "vue", "preact", "react-hooks", "inferno", "ivi", "lit", "angular-cf", "preact-hooks", "preact-classes", "preact-signals")
    for i, (n, s) in enumerate(ranked, 1):
        if n.startswith(lith) or any(n.startswith(p + "-v") or n.startswith(p + "-keyed") for p in names_of_interest):
            print(f"    {i:>3}. {n:40} {s:.3f}")
