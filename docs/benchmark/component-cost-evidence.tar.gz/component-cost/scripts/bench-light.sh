#!/bin/bash
# Full CPU + memory run: A, A+candidate, C, C+candidate in one session.
set -uo pipefail
ROOT="$HOME/project/js-framework-benchmark-upstream"
cd "$ROOT/webdriver-ts"
npm run bench -- keyed/lithent keyed/lithent-light keyed/lithent-row-memo keyed/lithent-row-memo-light \
  --headless true \
  --benchmark 01_ 02_ 03_ 04_ 05_ 06_ 07_ 08_ 09_ 21_ 22_ 25_
