"""Ceiling estimate: how far C' could get if a core change erased parts of its gap to A."""
import json, math, sys
from pathlib import Path
R = Path(sys.argv[1])
fw = {"A": "lithent-v1.25.3-keyed", "C": "lithent-row-memo-v1.25.3-keyed", "C'": "lithent-row-memo-reuse-v1.25.3-keyed"}
cpu = ["01_run1k","02_replace1k","03_update10th1k_x16","04_select1k","05_swap1k","06_remove-one-1k","07_create10k","08_create1k-after1k_x2","09_clear1k_x8"]
w = [0.64280248137063,0.5607178150466176,0.5643800750716564,0.1925635870170522,0.13200612879341714,0.5277091212292658,0.5644449600965534,0.5508359820582848,0.4225836631419211]
t = {n: {b: json.loads((R/f"{f}_{b}.json").read_text())["values"]["total"]["median"] for b in cpu} for n, f in fw.items()}
upd = {"03_update10th1k_x16","04_select1k","05_swap1k","06_remove-one-1k"}
def wg(x):  # weighted ratio of table x vs A
    return math.exp(sum(wi*math.log(x[b]/t["A"][b]) for b, wi in zip(cpu, w))/sum(w)) - 1
print(f"C  vs A: {wg(t['C']):+.1%}")
print(f"C' vs A: {wg(t[chr(67)+chr(39)]):+.1%}")
cp = t["C'"]
print(f"C' with update paths = A (create/clear/replace gap left): {wg({b: (t['A'][b] if b in upd else cp[b]) for b in cpu}):+.1%}")
print(f"C' with create/clear/replace = A (update-path gap left): {wg({b: (cp[b] if b in upd else t['A'][b]) for b in cpu}):+.1%}")
# share of log-gap by item
tot = sum(wi*math.log(cp[b]/t['A'][b]) for b, wi in zip(cpu, w))
for b, wi in zip(cpu, w):
    g = wi*math.log(cp[b]/t['A'][b])
    print(f"  {b:24} C'/A {cp[b]/t['A'][b]-1:+6.1%}  share of gap {g/tot:6.1%}")
