#!/bin/bash
# Full CPU + memory run for the three lithent variants and vanillajs.
# The runner interleaves frameworks inside each benchmark, so the variants
# share the same machine conditions.
set -uo pipefail
ROOT="$HOME/project/js-framework-benchmark-upstream"
cd "$ROOT/webdriver-ts"
npm run bench -- keyed/lithent keyed/lithent-row keyed/lithent-row-memo keyed/vanillajs \
  --headless true \
  --benchmark 01_ 02_ 03_ 04_ 05_ 06_ 07_ 08_ 09_ 21_ 22_ 23_ 25_ 26_
