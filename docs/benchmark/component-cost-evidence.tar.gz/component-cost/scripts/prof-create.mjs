// CPU profiles of 1k / 10k row creation, baseline vs no-children fast path.
// Same warmup as the official runner (5 x create 1k + clear), a fresh page per
// sample, variants alternated so neither always runs first. No CPU throttling,
// as the official 01/07 benchmarks.
import { createRequire } from 'node:module';

const require = createRequire(process.argv[2] + '/package.json');
const { chromium } = require('@playwright/test');
const REPS = Number(process.argv[3] || 12);
const root = 'http://localhost:8080/frameworks/keyed/lithent-prof';
const variants = { base: 'dist-prof-base', h: 'dist-prof-h' };
const scenarios = {
  run1k: { act: '#run', done: 'tbody>tr:nth-of-type(1000)' },
  run10k: { act: '#runlots', done: 'tbody>tr:nth-of-type(10000)' },
};
const skip = new Set(['[(idle)]', '[(program)]', '[(root)]']);

const browser = await chromium.launch({ headless: true });
const stats = {};

const sample = async (scenario, variant) => {
  const page = await browser.newPage();
  const cdp = await page.context().newCDPSession(page);
  await page.goto(`${root}/${variants[variant]}/index.html`);
  await page.waitForSelector('#run');
  const click = sel =>
    page.evaluate(
      s =>
        new Promise(res => {
          const t = performance.now();
          document.querySelector(s).click();
          requestAnimationFrame(() => setTimeout(() => res(performance.now() - t), 0));
        }),
      sel
    );
  for (let i = 0; i < 5; i++) {
    await click('#run');
    await click('#clear');
  }
  await cdp.send('Profiler.enable');
  await cdp.send('Profiler.setSamplingInterval', { interval: 100 });
  await cdp.send('Profiler.start');
  const wall = await click(scenarios[scenario].act);
  const { profile } = await cdp.send('Profiler.stop');
  if (!(await page.$(scenarios[scenario].done))) throw new Error(`${scenario} did not render`);
  await page.close();

  const byId = new Map(profile.nodes.map(n => [n.id, n]));
  const self = new Map();
  profile.samples.forEach((id, k) => {
    const f = byId.get(id).callFrame;
    const key = f.url.includes('main.js')
      ? f.functionName || '(anon)'
      : `[${f.functionName || 'native'}]`;
    self.set(key, (self.get(key) || 0) + profile.timeDeltas[k] / 1000);
  });
  const s = ((stats[scenario] ||= {})[variant] ||= { wall: [], js: [], gc: [], jsNoGc: [], fn: new Map() });
  let js = 0;
  for (const [key, ms] of self) {
    if (skip.has(key)) continue;
    js += ms;
    s.fn.set(key, (s.fn.get(key) || 0) + ms);
  }
  s.wall.push(wall);
  s.js.push(js);
  s.gc.push(self.get('[(garbage collector)]') || 0);
  s.jsNoGc.push(js - (self.get('[(garbage collector)]') || 0));
};

for (let rep = 0; rep < REPS; rep++) {
  for (const scenario of Object.keys(scenarios)) {
    const order = rep % 2 ? ['h', 'base'] : ['base', 'h'];
    for (const variant of order) await sample(scenario, variant);
  }
}
await browser.close();

const median = xs => {
  const a = [...xs].sort((x, y) => x - y);
  const m = a.length >> 1;
  return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2;
};
const pct = (x, y) => `${((x / y - 1) * 100).toFixed(1)}%`;

for (const [scenario, v] of Object.entries(stats)) {
  const b = v.base;
  const h = v.h;
  console.log(`\n== ${scenario} (${REPS} samples each, medians)`);
  for (const k of ['wall', 'js', 'gc', 'jsNoGc']) {
    console.log(`  ${k.padEnd(5)} base ${median(b[k]).toFixed(2).padStart(7)}  h ${median(h[k]).toFixed(2).padStart(7)}  ${pct(median(h[k]), median(b[k]))}`);
  }
  const keys = new Set([...b.fn.keys(), ...h.fn.keys()]);
  const rows = [...keys]
    .map(key => [key, (b.fn.get(key) || 0) / REPS, (h.fn.get(key) || 0) / REPS])
    .sort((x, y) => Math.abs(y[2] - y[1]) - Math.abs(x[2] - x[1]));
  const q = xs => [...xs].sort((x, y) => x - y).map(x => x.toFixed(1)).join(' ');
  console.log(`  gc samples base: ${q(b.gc)}`);
  console.log(`  gc samples h:    ${q(h.gc)}`);
  console.log('  largest per-function self-time differences (mean ms/sample): base -> h');
  for (const [key, mb, mh] of rows.slice(0, 12)) {
    console.log(`    ${(mh - mb >= 0 ? '+' : '') + (mh - mb).toFixed(2).padStart(6)}  ${mb.toFixed(2).padStart(6)} -> ${mh.toFixed(2).padStart(6)}  ${key}`);
  }
}
