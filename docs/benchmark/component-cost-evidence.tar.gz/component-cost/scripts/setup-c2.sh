#!/bin/bash
# Candidate-2-only core on the A app, under two names so the runner order flips:
#   lithent-zc2 runs after keyed/lithent, lit-c2 runs before it.
set -euo pipefail
CORE_DIST=/private/tmp/claude-501/-Users-n250109005-project-lithent/13ee46ac-bf92-49ec-a236-19617334cec4/scratchpad/lithent-c2/dist
K="$HOME/project/js-framework-benchmark-upstream/frameworks/keyed"
for name in lithent-zc2 lit-c2; do
  dir="$K/$name"
  rsync -a --delete --exclude /dist "$K/lithent/" "$dir/"
  cp "$CORE_DIST/lithent.mjs" "$CORE_DIST/lithent.cjs" "$CORE_DIST/lithent.umd.js" "$dir/node_modules/lithent/dist/"
  (cd "$dir" && npm run build-prod > /dev/null 2>&1)
  echo "[$name] core $(shasum -a 256 "$dir/node_modules/lithent/dist/lithent.mjs" | cut -c1-12) main.js $(shasum -a 256 "$dir/dist/main.js" | cut -c1-12)"
done
echo "[lithent] core $(shasum -a 256 "$K/lithent/node_modules/lithent/dist/lithent.mjs" | cut -c1-12) main.js $(shasum -a 256 "$K/lithent/dist/main.js" | cut -c1-12)"
