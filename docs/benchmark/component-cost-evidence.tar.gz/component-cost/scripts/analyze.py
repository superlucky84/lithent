"""Summarize the A/B/C lithent variants against vanillajs.

Medians of the click-to-paint total (and script) per benchmark, ratios to A,
and the results table's weighted geometric mean with the fastest of the four
as the per-benchmark denominator.
"""
import json
import math
import sys
from pathlib import Path

results = Path(sys.argv[1])
fws = {
    "A current": "lithent-v1.25.3-keyed",
    "B row, no cache": "lithent-row-v1.25.3-keyed",
    "C row + cacheUpdate": "lithent-row-memo-v1.25.3-keyed",
    "vanillajs": "vanillajs-keyed",
}
cpu = [
    "01_run1k", "02_replace1k", "03_update10th1k_x16", "04_select1k", "05_swap1k",
    "06_remove-one-1k", "07_create10k", "08_create1k-after1k_x2", "09_clear1k_x8",
]
weights = [
    0.64280248137063, 0.5607178150466176, 0.5643800750716564, 0.1925635870170522,
    0.13200612879341714, 0.5277091212292658, 0.5644449600965534, 0.5508359820582848,
    0.4225836631419211,
]
mem = ["21_ready-memory", "22_run-memory", "25_run-clear-memory"]


def load(fw, bench):
    return json.loads((results / f"{fw}_{bench}.json").read_text())["values"]


names = list(fws)
med = {n: {b: load(fws[n], b)["total"]["median"] for b in cpu} for n in names}
js = {n: {b: load(fws[n], b)["script"]["median"] for b in cpu} for n in names}
counts = {n: {b: len(load(fws[n], b)["total"]["values"]) for b in cpu} for n in names}

print("total median ms (samples)")
print(f"{'bench':26}" + "".join(f"{n:>22}" for n in names) + f"{'B/A':>9}{'C/A':>9}")
for b in cpu:
    row = "".join(f"{med[n][b]:>16.1f} ({counts[n][b]:>2})" for n in names)
    a = med[names[0]][b]
    print(f"{b:26}{row}{med[names[1]][b] / a - 1:>+9.1%}{med[names[2]][b] / a - 1:>+9.1%}")

print("\nscript median ms")
for b in cpu:
    print(f"{b:26}" + "".join(f"{js[n][b]:>22.1f}" for n in names))

print("\nweighted geometric mean (fastest of the four = 1.00)")
scores = {}
for n in names:
    acc = 0.0
    for b, w in zip(cpu, weights):
        fastest = min(med[m][b] for m in names)
        acc += w * math.log(med[n][b] / fastest)
    scores[n] = math.exp(acc / sum(weights))
for n in names:
    print(f"  {n:22} {scores[n]:.3f}  vs A {scores[n] / scores[names[0]] - 1:+.1%}")

print("\nmemory MB")
for b in mem:
    print(f"{b:26}" + "".join(f"{load(fws[n], b)['DEFAULT']['median']:>22.2f}" for n in names))
