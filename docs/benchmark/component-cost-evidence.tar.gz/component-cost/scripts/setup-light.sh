#!/bin/bash
# Light-component experiment apps:
#   lithent-light                A source, candidate core
#   lithent-row-memo             C source, npm lithent 1.25.3
#   lithent-row-memo-light       C source, candidate core
set -euo pipefail
S=/private/tmp/claude-501/-Users-n250109005-project-lithent/13ee46ac-bf92-49ec-a236-19617334cec4/scratchpad/variants
CORE_DIST=/private/tmp/claude-501/-Users-n250109005-project-lithent/13ee46ac-bf92-49ec-a236-19617334cec4/scratchpad/lithent-light/dist
ROOT="$HOME/project/js-framework-benchmark-upstream"
K="$ROOT/frameworks/keyed"

make_app() { # name source-variant(or "same") use-candidate
  local dir="$K/$1"
  rsync -a --delete --exclude /dist "$K/lithent/" "$dir/"
  [ "$2" = same ] || cp "$S/$2-main.tsx" "$dir/src/main.tsx"
  if [ "$3" = yes ]; then
    cp "$CORE_DIST/lithent.mjs" "$CORE_DIST/lithent.cjs" "$CORE_DIST/lithent.umd.js" "$dir/node_modules/lithent/dist/"
  fi
  (cd "$dir" && npx tsc --noEmit -p . && npm run build-prod > /dev/null 2>&1)
  echo "[$1] built; core $(shasum -a 256 "$dir/node_modules/lithent/dist/lithent.mjs" | cut -c1-12)"
}

echo "[lithent] core $(shasum -a 256 "$K/lithent/node_modules/lithent/dist/lithent.mjs" | cut -c1-12)"
make_app lithent-light same yes
make_app lithent-row-memo row-memo no
make_app lithent-row-memo-light row-memo yes

if ! curl -s -o /dev/null http://localhost:8080/; then
  (cd "$ROOT" && nohup npm start > "$S/server.log" 2>&1 &)
  for _ in $(seq 1 20); do
    curl -s -o /dev/null http://localhost:8080/ && break
    perl -e 'select(undef,undef,undef,0.5)'
  done
fi

cd "$ROOT/webdriver-ts"
npm run isKeyed -- --runner playwright --headless true keyed/lithent-light keyed/lithent-row-memo-light 2>&1 | grep -E "is keyed|is not keyed|ERROR|Error" || true
npm run bench -- keyed/lithent-light keyed/lithent-row-memo-light --headless true --smoketest true \
  --benchmark 01_ 02_ 03_ 04_ 05_ 06_ 07_ 08_ 09_ 2>&1 | grep -E "successful run|failed|Error" | tail -3
