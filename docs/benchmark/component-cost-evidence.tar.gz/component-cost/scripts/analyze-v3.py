"""Candidate 2 on the A app: two sessions with opposite order, each and pooled."""
import json
import math
import statistics
import sys
from pathlib import Path

base = Path(sys.argv[1])
sessions = {
    "main (cand after A)": (base / "results-v3-main", "lithent-zv3-v1.25.3-keyed"),
    "reverse (cand before A)": (base / "results-v3-reverse", "lit-v3-v1.25.3-keyed"),
}
A = "lithent-v1.25.3-keyed"
cpu = [
    "01_run1k", "02_replace1k", "03_update10th1k_x16", "04_select1k", "05_swap1k",
    "06_remove-one-1k", "07_create10k", "08_create1k-after1k_x2", "09_clear1k_x8",
]
weights = [
    0.64280248137063, 0.5607178150466176, 0.5643800750716564, 0.1925635870170522,
    0.13200612879341714, 0.5277091212292658, 0.5644449600965534, 0.5508359820582848,
    0.4225836631419211,
]


def samples(folder, fw, bench, kind):
    return json.loads((folder / f"{fw}_{bench}.json").read_text())["values"][kind]["values"]


def weighted(ratios):
    return math.exp(sum(w * math.log(r) for r, w in zip(ratios, weights)) / sum(weights)) - 1


pooled = {k: {"A": {b: [] for b in cpu}, "C2": {b: [] for b in cpu}} for k in ("total", "script")}

for label, (folder, cand) in sessions.items():
    print(f"== {label}")
    print(f"{'bench':24}{'A tot':>8}{'C2 tot':>8}{'ratio':>8}{'A js':>8}{'C2 js':>8}{'ratio':>8}")
    rt, rs = [], []
    for b in cpu:
        row = []
        for kind in ("total", "script"):
            a = samples(folder, A, b, kind)
            c = samples(folder, cand, b, kind)
            pooled[kind]["A"][b] += a
            pooled[kind]["C2"][b] += c
            ma, mc = statistics.median(a), statistics.median(c)
            row += [ma, mc, mc / ma - 1]
            (rt if kind == "total" else rs).append(mc / ma)
        print(f"{b:24}{row[0]:>8.1f}{row[1]:>8.1f}{row[2]:>+8.1%}{row[3]:>8.1f}{row[4]:>8.1f}{row[5]:>+8.1%}")
    print(f"  weighted: total {weighted(rt):+.1%}, script {weighted(rs):+.1%}\n")

print("== pooled (both sessions)")
rt, rs = [], []
for b in cpu:
    t = [statistics.median(pooled["total"][n][b]) for n in ("A", "C2")]
    s = [statistics.median(pooled["script"][n][b]) for n in ("A", "C2")]
    rt.append(t[1] / t[0])
    rs.append(s[1] / s[0])
    print(f"{b:24}{t[0]:>8.1f}{t[1]:>8.1f}{t[1] / t[0] - 1:>+8.1%}{s[0]:>8.1f}{s[1]:>8.1f}{s[1] / s[0] - 1:>+8.1%}")
print(f"  weighted: total {weighted(rt):+.1%}, script {weighted(rs):+.1%}")
