#!/bin/bash
# Full CPU + memory run: A, B, B+candidate, C, C+candidate in one session.
set -uo pipefail
S=/private/tmp/claude-501/-Users-n250109005-project-lithent/13ee46ac-bf92-49ec-a236-19617334cec4/scratchpad/variants
ROOT="$HOME/project/js-framework-benchmark-upstream"
cd "$ROOT/webdriver-ts"
mkdir -p "$S/results-run1"
cp results/lithent*-v1.25.3-keyed_*.json results/vanillajs-keyed_*.json "$S/results-run1/" 2>/dev/null || true
npm run bench -- keyed/lithent keyed/lithent-row keyed/lithent-row-reuse keyed/lithent-row-memo keyed/lithent-row-memo-reuse \
  --headless true \
  --benchmark 01_ 02_ 03_ 04_ 05_ 06_ 07_ 08_ 09_ 21_ 22_ 25_
