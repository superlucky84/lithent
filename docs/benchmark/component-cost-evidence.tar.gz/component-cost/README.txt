Component cost and h() experiments, 2026-10-28.
Report: docs/benchmark/COMPONENT_COST_RESULTS.md

patches/  (all against main a0f2552, src only)
  wrapper-reuse.patch    reuse the component Fragment wrapper when the updater
                         returns the node it already holds
  light-component.patch  lazy hook queues + h() early return + resolver method
  c2-only.patch          h() early return + resolver method ("candidate 2")
  c2-h-only.patch        V1: h() early return when there are no children
  h-v2.patch             V2: the same condition inline in the makeNode call
  h-v3.patch             V3: V1 + parent kept in a function-scope closure variable
  h-v4.patch             V4: V3 with the variable inside the if block

apps/  row-main.tsx = B (row component), row-memo-main.tsx = C (row component +
       cacheUpdate). A is the unchanged keyed/lithent app of PR #2136.

results/  raw js-framework-benchmark result JSON
  results-run1           A, B, C, vanillajs (CPU + memory)
  results-run2           A, B, B+wrapper reuse, C, C+wrapper reuse
  results-run3           A, A+light, C, C+light
  results-c2-*           A vs candidate 2 (main: after A, reverse: before A)
  results-v12-*          A, V1, V2
  results-v3-*           A vs V3
  results-v4-*           A, V1, V4
  App directory names only set the runner order: lithent-x*/lithent-z* run
  after keyed/lithent, lit-* run before it. Same core under both names.

scripts/  setup, bench and analysis scripts as run (absolute paths are from the
  original session). Analysis scripts take the folder holding results-* as
  their argument, e.g. python3 scripts/analyze-v4.py results
  analyze.py/analyze-reuse.py/analyze-light.py take the result folder itself.

profiles/  CPU profiles of 1k/10k creation, base vs V1 (prof-create-v2.log: V2).
  prof-create*.log and prof-create-prod.log/prod2.log: no forced GC.
  prof-create-prod3.log: same flags and forced major GC as the official runner.
  prof-create-prod.mjs is the final script; its variant map was last edited to
  the V2 app for prof-create-v2.log.

core-sha256.txt  SHA-256 of each candidate dist/lithent.mjs.
