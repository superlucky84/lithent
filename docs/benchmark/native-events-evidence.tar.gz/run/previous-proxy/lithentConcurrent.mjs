const b = Symbol.for("lithentWDomSymbol"), O = { value: "" }, k = { value: null }, M = { value: !1 }, h = /* @__PURE__ */ new WeakMap(), Ft = /* @__PURE__ */ new WeakSet();
let Ut = !1;
const pe = (t, e) => {
  h.set(t, {
    ctor: e,
    vd: { value: null },
    up: () => {
    },
    upR: [],
    upS: { value: 0 },
    upD: [],
    upCB: [],
    mts: [],
    umts: [],
    wdCB: []
    // WDom creation callback queue
  });
}, de = () => k.value, L = () => h.get(k.value), Vt = (t, e) => {
  const n = h.get(t);
  return n ? n[e] : null;
}, he = (t) => {
  k.value = t;
}, ye = (t, e) => {
  k.value = t, pe(t, e);
}, On = (t) => {
  Ut = t;
}, ve = () => Ut, _t = (t) => {
  const e = h.get(t);
  e && (e.umts.forEach((n) => n()), e.umts = []);
}, Fn = (t) => {
  _t(t), h.delete(t);
}, R = (t) => t.getParent && t.getParent(), It = (t) => () => t, Et = Object.keys, Qt = (t, e) => Object.prototype.propertyIsEnumerable.call(t, e), jt = (t, e) => {
  if (Qt(t, e)) return !0;
  const n = Object.getPrototypeOf(t);
  return !Object.prototype.hasOwnProperty.call(t, e) && !!n && jt(n, e);
}, V = (t) => typeof t == "object" && t !== null, ge = Object.assign, Un = (t) => V(t) && !Array.isArray(t) && !Object.getOwnPropertySymbols(t).includes(b), Ce = (t, e) => "ctor" in t ? t.ctor === (e && e.ctor) : t === (e && e.ctor), ke = (t, e) => e.type === "f" && // A component's node is a one-child fragment too: never update it in
// place as a plain fragment, or the component is never unmounted, nor
// update a plain fragment with one (a hoisted <Comp /> first drawn by a
// redraw), or it is never mounted.
!e.ctor && !t.ctor && !!e.children && e.children.length === (t.children && t.children.length), Pe = (t, e) => e.type === "e" && e.tag === t.tag && !!e.children && e.children.length === (t.children && t.children.length), Rt = (t, e) => e.type === t.type, Ee = (t, e) => e.type === t.type && (G(t) && G(e) || !!e.children && e.children.length === (t.children && t.children.length)), H = (t) => (t && t.compProps && t.compProps.key) ?? (t && t.props && t.props.key), T = (t) => t === "f" || t === "l", J = (t) => typeof t == "function" && !zt(t) || V(t) && "resolve" in t, zt = (t) => t === dt, Re = (t) => !t.type, Se = (t) => t[0] === "o" && t[1] === "n", it = (t) => j(H(t)), G = (t) => !!t && !!t.children && t.children.some(it), j = (t) => t != null, St = (t, e) => t === "style" && V(e), be = (t, e) => t === "ref" && V(e), bt = /* @__PURE__ */ new WeakMap(), Mt = (t, e) => {
  const n = t.constructor.prototype;
  let s = bt.get(n);
  s || bt.set(n, s = /* @__PURE__ */ new Map());
  let c = s.get(e);
  if (c === void 0) {
    const o = Object.getOwnPropertyDescriptor(n, e);
    c = !!(o && o.get && o.set), s.set(e, c);
  }
  return c;
}, xt = (t) => t.localName.includes("-") && t.constructor === HTMLElement, Me = (t) => J(t) ? "c" : t.type || "et", xe = {
  c: Ce,
  l: Ee,
  t: Rt,
  e: Pe,
  f: ke,
  et: Rt
}, F = Symbol(), _ = Symbol();
function m(t) {
  var n;
  const e = (n = this[F]) == null ? void 0 : n["on" + t.type];
  typeof e == "function" ? e.call(this, t) : e && e.handleEvent(t);
}
const Kt = (t, e, n) => {
  const s = e.slice(2).toLowerCase(), c = "on" + s, o = t[F];
  o && o[c] === n ? (delete o[c], t.removeEventListener(s, m)) : t.removeEventListener(s, n);
}, $ = (t, e, n, s) => {
  var i;
  if (s === n) return;
  const c = e.slice(2).toLowerCase(), o = "on" + c, r = t[F] || (t[F] = {}), l = r[o];
  (i = r[_]) != null && i.has(o) ? (s && Kt(t, e, s), n && n !== r[o] && t.addEventListener(c, n)) : n ? l && l !== s && l !== n ? ((r[_] || (r[_] = /* @__PURE__ */ new Set())).add(o), t.addEventListener(c, n)) : (r[o] = n, l || t.addEventListener(c, m)) : l && l === s && (delete r[o], t.removeEventListener(c, m));
}, Yt = (t) => {
  const e = L();
  e && e.umts.push(t);
}, Z = (t) => {
  const { compKey: e } = t;
  e && (t.il = !0, Ne(e)), Xt(t);
}, Xt = (t) => {
  if (t.tag === "portal" && t.el)
    for (const e in t.props)
      Se(e) && Kt(
        t.el,
        e,
        t.props[e]
      );
  (t.children || []).forEach((e) => {
    e.compKey ? Z(e) : Xt(e);
  });
}, Ne = (t) => {
  _t(t), ve() || h.delete(t);
};
let w = [];
const Jt = (t) => {
  t.compKey && w.push(t);
}, Zt = () => {
  w.forEach(Te), w = [];
}, Vn = (t) => {
  const e = L();
  e && e.mts.push(t);
}, Te = (t) => {
  const { compKey: e } = t, n = e && h.get(e);
  if (n) {
    const s = n.mts;
    k.value = e, n.upS.value = 0, n.mts = [], s.forEach((c) => {
      const o = c();
      o && Yt(o);
    });
  }
}, _n = (t) => {
  const e = L();
  e && e.wdCB.push(t);
}, $t = (t) => {
  const { compKey: e } = t;
  if (e) {
    const n = h.get(e), s = n && n.wdCB;
    k.value = e, s && s.length > 0 && (n.wdCB = [], s.forEach((c) => {
      const o = c();
      typeof o == "function" && Yt(o);
    }));
  }
}, Nt = (t, e = () => []) => {
  const n = L();
  if (!n) return;
  const { upD: s, upS: c } = n, o = s[c.value], r = e();
  if (o && Ae(o, r)) {
    const l = t();
    l && n.upCB.push(l);
  }
  s[c.value] = r, c.value += 1;
}, Le = (t) => {
  const { compKey: e } = t, n = e && h.get(e);
  if (n) {
    const s = n.upCB;
    k.value = e, n.upS.value = 0, t.ctor && (n.upCB = [], s.forEach((c) => c()));
  }
}, Ae = (t, e) => t.length ? t.some((n, s) => n !== e[s]) : !0, W = () => new DocumentFragment(), D = /* @__PURE__ */ new WeakMap(), Be = (t) => {
  const e = t.el, n = [], s = [], c = { ready: n, mounted: s }, o = A(t, !1, c);
  t.el = e, c.hasPortal || D.set(t, { el: o, ready: n, mounted: s });
}, tt = (t, e) => e && e.parentNode === t ? e : null, ut = (t) => {
  const e = D.get(t);
  if (e)
    return D.delete(t), t.el = e.el, e.ready.forEach($t), e.mounted.forEach(Jt), e.el;
}, Oe = (t) => document.createElement(t), In = (t, e, n, s) => {
  t.isRoot = !0, e = e || document.body, t.we = e;
  const c = A(t, s);
  return n ? (t.ae = n, e.insertBefore(c, n)) : s || (e.tagName === "HTML" ? e.replaceWith(c) : e.appendChild(c)), Zt(), () => {
    const o = h.get(t.compProps || {}), r = o && o.vd.value || t;
    Z(r), Fe(r);
  };
}, Fe = (t) => ft(t, t.we), at = (t) => {
  const e = R(t), n = t.isRoot ? t.we : e ? B(e) : void 0;
  n && ft(t, n);
}, ft = (t, e) => {
  if (e && t.el) {
    const n = t.el.nodeType;
    n === 11 || (t == null ? void 0 : t.tag) === "portal" ? qt(t, e) : (n === 1 || n === 3) && e.removeChild(t.el), t.el = void 0;
  }
}, qt = (t, e) => {
  const n = t && t.oc || t && t.children || [];
  if (n.length > 1 && n.every((s) => {
    const c = s.el && s.el.nodeType;
    return (c === 1 || c === 3) && s.el.tagName !== "HTML" && s.tag !== "portal";
  })) {
    let s = 0;
    for (let c = e.firstChild; c && s <= n.length; c = c.nextSibling)
      s++;
    if (s === n.length) {
      e.textContent = "", n.forEach((c) => c.el = void 0);
      return;
    }
  }
  n.forEach((s) => {
    const c = s.el && s.el.nodeType;
    if (c)
      if (c === 1 || c === 3) {
        const o = s.el;
        o.tagName === "HTML" ? o.innerHTML = "" : o.remove();
      } else c === 11 && qt(s, e);
  });
}, Ue = (t, e) => {
  const n = B(e);
  t.forEach((s) => {
    Z(s), ft(s, n);
  });
}, et = (t) => {
  at(t), Ht(t);
}, Ht = (t, e) => {
  e || (e = ut(t) || A(t));
  const n = R(t);
  if (!n || !n.type) {
    t.isRoot && t.we && e && t.tag !== "portal" && (t.ae ? t.we.insertBefore(e, t.ae) : t.we.tagName === "HTML" ? t.we.replaceWith(e) : t.we.appendChild(e));
    return;
  }
  const s = B(n), c = pt(t, n, s);
  e && s && t.tag !== "portal" && s.insertBefore(e, tt(s, c));
}, Gt = (t) => T(t.type) ? (t && t.children || []).reduce((e, n) => {
  const s = Gt(n);
  return s && e.appendChild(s), e;
}, W()) : t.el, pt = (t, e, n) => {
  const s = e.children || [], o = s.indexOf(t) + 1, r = s.slice(o), l = K(
    r,
    n
  ), i = e.type || "";
  if (l)
    return l;
  if (!e.isRoot && T(i))
    return pt(
      e,
      R(e),
      n
    );
  if (e.isRoot && T(i) && e.ae)
    return e.ae;
}, z = /* @__PURE__ */ new Set(), K = (t, e) => t.reduce(
  (n, s) => {
    if (n || z.size && z.has(s)) return n;
    const { type: c, el: o } = s;
    if (c && T(c)) {
      const r = K(
        s.children || [],
        e
      );
      if (r) return r;
    }
    return o && o.nodeType !== 11 && (!e || o.parentNode === e) ? o : n;
  },
  void 0
), Ve = (t) => {
  const e = R(t), n = t.el;
  if (t.isRoot && !e && n) {
    et(t);
    return;
  }
  if (e && e.type && n)
    if (n.nodeType === 11)
      et(t);
    else {
      const s = B(e), c = ut(t) || A(t);
      s && t.tag !== "portal" && s.replaceChild(c, n);
    }
}, nt = (t) => {
  if (t.type === "t") {
    je(t);
    return;
  }
  if (t.el) {
    const { op: e, props: n } = t;
    wt(n, t.el, e), t.tag === "input" && (t.el.value = String(
      n && n.value || ""
    ));
  }
  _e(t), Le(t);
}, _e = (t) => {
  const e = t.children || [];
  let n = !1;
  if (t.type === "l") {
    for (const u of e)
      if ("ATS".includes(u.nr) || u.oi !== void 0) {
        n = !0;
        break;
      }
  }
  if (!n) {
    e.forEach((u) => st(u));
    return;
  }
  const s = [], c = [], o = [];
  let r = !0;
  e.forEach((u, d) => {
    const v = u.oi;
    u.nr === "A" || u.nr === "S" ? o.push(u) : v !== void 0 && (v < c[c.length - 1] && (r = !1), s.push(d), c.push(v));
  });
  let l;
  if (!r) {
    const u = l = [];
    s.forEach((d) => u[d] = !1), Ie(c).forEach((d) => u[s[d]] = !0), s.forEach((d) => u[d] || o.push(e[d]));
  }
  const i = [];
  let a = 0;
  o.forEach((u) => z.add(u));
  try {
    e.forEach((u, d) => {
      const v = u.nr;
      v === "A" || v === "S" ? (v === "S" && at(u), i[d] = ut(u) || A(u), a++) : v === "T" ? nt(u) : st(u);
    });
  } finally {
    o.forEach((u) => z.delete(u));
  }
  const p = B(t), P = t.isRoot ? t.ae : pt(t, R(t), p);
  let S = e.length;
  for (; S > 0 && i[S - 1] !== void 0; )
    S--;
  for (let u = S; u < e.length; u++) {
    const d = i[u];
    d && p && e[u].tag !== "portal" && p.insertBefore(d, tt(p, P));
  }
  if (l || a > e.length - S) {
    let u = K(e.slice(S), p) || P;
    for (let d = S - 1; d >= 0; d--) {
      const v = e[d], Ct = i[d] !== void 0, fe = !!l && l[d] === !1;
      if ((Ct || fe) && p && v.tag !== "portal") {
        const Pt = Ct ? i[d] : Gt(v);
        Pt && p.insertBefore(Pt, tt(p, u));
      }
      const kt = K([v], p);
      kt && (u = kt);
    }
  }
  e.forEach(mt);
}, mt = (t) => {
  t.oi = t.oc = t.op = void 0, t.nr = "N";
}, Ie = (t) => {
  const e = [];
  if (!t.length)
    return e;
  const n = new Array(t.length);
  e.push(0);
  for (let o = 1; o < t.length; o++) {
    const r = t[o];
    if (t[e[e.length - 1]] < r) {
      n[o] = e[e.length - 1], e.push(o);
      continue;
    }
    let l = 0, i = e.length - 1;
    for (; l < i; ) {
      const a = l + i >> 1;
      t[e[a]] < r ? l = a + 1 : i = a;
    }
    r < t[e[l]] && (l > 0 && (n[o] = e[l - 1]), e[l] = o);
  }
  let s = e.length, c = e[s - 1];
  for (; s-- > 0; )
    e[s] = c, c = n[c];
  return e;
}, st = (t) => {
  const { nr: e } = t;
  e !== void 0 && e !== "N" && (Qe[e](t), mt(t));
}, Qe = {
  A: Ht,
  D: at,
  R: Ve,
  U: nt,
  S: et,
  // A keyed item reaches here only as a component redrawing itself: it has
  // not moved, so it is updated in place. Re-inserting its nodes would blur a
  // focused input inside it or reload an iframe. Moves within a list are
  // placed by updateChildren.
  T: nt
}, je = (t) => {
  t.el && (t.el.nodeValue = String(t.text));
}, wt = (t, e, n, s) => {
  const c = n || {};
  for (const o in t) {
    const r = t[o];
    if (r === c[o])
      continue;
    const l = o[0] === "o" && o[1] === "n";
    s && l ? $(
      e,
      o,
      r,
      c[o]
    ) : o === "key" || o === "portal" && V(r) || (o === "innerHTML" && typeof r == "string" ? e.innerHTML = r : St(o, r) ? Ye(
      r,
      St(o, c.style) ? c.style : {},
      e
    ) : be(o, r) ? r.value = e : l ? $(
      e,
      o,
      r,
      c[o]
    ) : o && (o !== "type" && Mt(e, o) ? e[o] = r : (ze(
      o === "className" ? "class" : o,
      e,
      r
    ), xt(e) && !(o in HTMLElement.prototype) && (e[o] = r))));
  }
  for (const o in c)
    if (!(t && jt(t, o))) {
      if (o[0] === "o" && o[1] === "n") {
        $(
          e,
          o,
          void 0,
          c[o]
        );
        continue;
      }
      e.removeAttribute(o), xt(e) ? delete e[o] : e.localName.includes("-") && Mt(e, o) && (e[o] = void 0);
    }
}, ze = (t, e, n) => O.value && t !== "xmlns" ? e.setAttributeNS(null, t, n) : e.setAttribute(t, n), A = (t, e, n) => {
  let s;
  const { type: c, tag: o, text: r, props: l, children: i = [] } = t, a = T(c);
  if (n && o === "portal")
    return n.hasPortal = !0, l == null ? void 0 : l.portal;
  if (n ? t.compKey && n.ready.push(t) : $t(t), o === "svg" && (O.value = String(l && l.xmlns)), e)
    s = t.el;
  else {
    if (!c)
      s = W();
    else if (a)
      s = W();
    else if (c === "e" && o)
      o === "portal" && l && l.portal ? s = l.portal : s = O.value ? document.createElementNS(O.value, o) : Oe(o);
    else if (c === "t" && j(r))
      s = document.createTextNode(String(r));
    else
      throw Error("Invalid wDom");
    t.el = s;
  }
  return Ke(t, i, s, e, n), wt(l, s, null, e), n ? t.compKey && n.mounted.push(t) : Jt(t), o === "svg" && (O.value = ""), s;
}, Ke = (t, e, n, s, c) => {
  const o = It(t);
  e.forEach((r, l) => {
    if (r.nr === "N" && !s) {
      const i = ue(r);
      r = e[l] = "resolve" in i ? i.resolve() : i;
    }
    if (r.getParent = o, r.nr = "N", r.type) {
      const i = A(r, s, c);
      r.tag !== "portal" && !s && n && n.appendChild(i);
    }
  });
}, Ye = (t, e, n) => {
  const s = { ...e }, c = n instanceof HTMLElement ? n : null, o = c == null ? void 0 : c.style;
  if (!o) return;
  const r = o;
  for (const l in t)
    r[l] = t[l], delete s[l];
  for (const l in s)
    r[l] = "";
}, B = (t) => {
  const e = T(t.type);
  return t.isRoot && e ? t.we : e ? B(R(t)) : t.el;
}, f = Object.assign(h, {
  renderGate: {
    beforePause() {
      if (M.value)
        throw new Error("Pause outside component rendering");
    }
  }
}).renderGate, Xe = (t, e, n) => {
  const s = [Tt(t, e)];
  return {
    advance: (c) => {
      for (; ; ) {
        const o = s[s.length - 1];
        if (o.cursor < o.children.length)
          s.push(
            Tt(
              o.children[o.cursor],
              o.originals[o.cursor],
              o
            )
          );
        else {
          if ($e(o, n), s.pop(), !s.length)
            return o.wip;
          He(o);
        }
        if (c && c())
          return null;
      }
    }
  };
}, Je = (t, e) => !!e && xe[Me(t)](t, e), Ze = (t) => {
  t.forEach((e) => e());
}, Tt = (t, e, n) => {
  t !== e && t.nr && (t = ue(t));
  const s = Je(t, e), c = tn(t, s, e), o = me(c, s, e);
  c.nr = o;
  const r = {
    wip: c,
    needRerender: o,
    isSameType: s,
    originalWDom: e,
    children: I,
    originals: I,
    matchedIndexes: I,
    unused: null,
    built: I,
    cursor: 0,
    getParent: void 0,
    parent: n
  };
  return o !== "N" && en(r), r;
}, I = [], $e = (t, e) => {
  const { wip: n, originalWDom: s, needRerender: c } = t, o = c === "N";
  if (!o) {
    if (t.unused) {
      const r = t.unused;
      e.push(() => Ue(r, s));
    }
    n.children = t.built;
  }
  n.nr = c, Ge(n, s, e, c), !o && s && e.push(() => {
    s.il = !0, s.ctor && (s.children = void 0);
  }), s && s.tag === "portal" && (n.tag = "portal"), Lt(c) && n.type && !Lt(qe(t)) && Be(n);
}, Lt = (t) => t === "A" || t === "R" || t === "S", qe = (t) => t.parent && t.parent.needRerender, He = (t) => {
  var c;
  const e = t.parent, n = e.cursor, s = e.matchedIndexes[n];
  s !== void 0 && (t.wip.oi = s), t.wip === t.originalWDom && ((c = f.reparent) == null || c.call(f, t.wip)), t.wip.getParent = e.getParent, e.built[n] = t.wip, e.cursor = n + 1;
}, Ge = (t, e, n, s) => {
  s !== "A" && e && (t.el = e.el), (s === "D" || s === "R" || s === "S") && (e && n.push(() => Z(e)), t.oc = e && e.children), t.op = e && e.props;
}, me = (t, e, n) => {
  if (Re(t)) return "D";
  if (t.type === "t" && e && t.text === (n && n.text) || t === n) return "N";
  if (!(n && n.type)) return "A";
  const o = R(n), r = !t.isRoot && o && o.type === "l" && it(t);
  return e ? r ? "T" : "U" : r ? "S" : "R";
}, we = (t, e) => {
  t && e !== t && (e = e || {}, Et(t).forEach(
    (n) => Qt(e, n) || delete t[n]
  ), Et(e).forEach((n) => t[n] = e[n]));
}, We = (t, e) => {
  t && (t.splice(0, t.length), e && e.forEach((n) => t.push(n)));
}, De = (t, e) => {
  var l;
  const { compProps: n, compChild: s } = t, { props: c, children: o } = e;
  return n && we(n, c), s && o && s !== o && We(s, o), (l = f.blocks) != null && l.call(f, t) ? t : t.reRender && t.reRender();
}, tn = (t, e, n) => J(t) ? e && n ? De(n, t) : (
  // Resolved before (children a component draws again somewhere else):
  // the first instance owns its props, which are also its key, so the
  // new instance is made from a copy.
  (t.rd ? vt(t) : (t.rd = !0, t)).resolve()
) : t, en = (t) => {
  const { wip: e, isSameType: n, originalWDom: s } = t, c = e.children;
  if (!c || !c.length || (t.children = c, t.built = new Array(c.length), t.getParent = It(e), !n || !s))
    return;
  t.originals = new Array(c.length);
  const o = s.children || [];
  if (e.type === "l" && G(e)) {
    t.matchedIndexes = new Array(c.length);
    const r = /* @__PURE__ */ new Map(), l = [];
    o.forEach((i, a) => {
      const p = H(i);
      j(p) && !r.has(p) && r.set(p, a);
    }), c.forEach((i, a) => {
      const p = H(i), P = j(p) ? r.get(p) : a < o.length && !it(o[a]) ? a : void 0;
      P !== void 0 && (r.delete(p), l[P] = !0, t.originals[a] = o[P], t.matchedIndexes[a] = P);
    }), t.unused = o.filter((i, a) => !l[a]);
    return;
  }
  c.forEach((r, l) => {
    t.originals[l] = o[l];
  });
}, Q = { value: "sync" }, y = {
  sync: /* @__PURE__ */ new Map(),
  low: /* @__PURE__ */ new Map()
}, Qn = (t) => {
  const e = Q.value;
  Q.value = "low";
  try {
    t();
  } finally {
    Q.value = e;
  }
}, nn = 5;
let sn = nn, ot = !1, Y = !1, Wt = 0, q = null, X = [], g = null;
const on = (t) => {
  g = t, x("low");
}, cn = () => {
  g = null;
}, ct = () => {
  if (g) {
    const t = g;
    g = null, t();
  }
}, rt = () => performance.now() >= Wt, rn = () => {
  if (typeof MessageChannel != "function") {
    setTimeout(At);
    return;
  }
  if (!q) {
    const t = new MessageChannel();
    t.port1.onmessage = At, q = t.port2;
  }
  q.postMessage(null);
}, x = (t) => {
  t === "sync" ? ot || (ot = !0, queueMicrotask(ln)) : Y || (Y = !0, rn());
}, ln = () => {
  const t = E;
  E = !1;
  try {
    y.sync.forEach((e, n) => {
      y.sync.delete(n), e();
    });
  } finally {
    ot = !1, E = t, y.sync.size && x("sync");
  }
};
let E = !1;
const un = f.beforePause;
f.beforePause = (t) => {
  var n;
  un();
  const e = E;
  E = !1;
  try {
    (n = f.settle) == null || n.call(f, t);
  } finally {
    E = e;
  }
};
const an = () => E, At = () => {
  Y = !1, E = !0;
  try {
    fn();
  } finally {
    E = !1, (y.low.size || g || X.length) && x("low");
  }
}, fn = () => {
  if (Wt = performance.now() + sn, g) {
    const n = g;
    if (g = null, n(), (y.low.size || g) && rt()) {
      x("low");
      return;
    }
  }
  const t = y.low;
  for (const [n, s] of t)
    if (t.delete(n), s(), t.size && rt()) {
      x("low");
      return;
    }
  if (g) {
    x("low");
    return;
  }
  const e = X;
  X = [], e.forEach((n) => n());
}, Bt = /* @__PURE__ */ new WeakMap(), pn = (t, e) => {
  const n = h.get(t);
  n && (Bt.set(t, e), n.up = () => {
    const s = Q.value;
    if (s === "sync")
      y.low.delete(t);
    else if (y.sync.has(t))
      return;
    y[s].set(t, () => (Bt.get(t) || e)()), x(s);
  });
}, jn = (t, e) => e ? y[e].has(t) : y.sync.has(t) || y.low.has(t), zn = () => y.low.size || Y || g ? new Promise((t) => {
  X.push(t);
}) : Promise.resolve(), Dt = { value: 0 }, te = () => Dt.value, Kn = () => {
  Dt.value += 1;
}, ee = (t) => () => {
  const e = h.get(t), n = e && e.up;
  return n ? (n(), !0) : !1;
}, Yn = (t, e = () => []) => {
  const n = L();
  n && (n.upR.push(() => Nt(t, e)), Nt(t, e));
}, dn = () => {
  const t = L(), e = t && t.upR;
  e && e.length && e.forEach((n) => n());
}, dt = (t, ...e) => ({
  type: "f",
  // fragment
  nr: void 0,
  [b]: !0,
  children: e
}), hn = (t, e, ...n) => {
  const s = { value: void 0 }, c = le(s, n), o = xn(t, e || {}, c);
  return J(o) || (s.value = o), o;
}, Xn = (t, e) => hn("portal", { portal: e }, t), Jn = (t) => (e, n) => t, Zn = (t) => (e, n) => (Ft.add(t), t), yn = (t, e, n) => {
  const s = (c, o) => {
    if (!(!c || o.has(c))) {
      if (o.add(c), c.compChild) {
        const r = c.compChild.indexOf(e);
        r !== -1 && c.compChild.splice(r, 1, n);
      }
      s(c.getParent ? c.getParent() : void 0, o);
    }
  };
  s(t, /* @__PURE__ */ new Set());
}, vn = 2;
let N = null;
const gn = () => {
  N && (N.mounted = !0);
}, Cn = (t) => {
  if (!N)
    return;
  const e = h.get(t);
  e && N.snapshots.push({
    compKey: t,
    // `upD` slots are replaced wholesale, never mutated in place, so copying
    // the outer array is enough.
    upD: [...e.upD],
    upCB: [...e.upCB],
    upS: e.upS.value,
    mts: [...e.mts]
  });
}, ht = (t) => t.some((e) => {
  const n = h.get(e.compKey);
  if (!n)
    return !1;
  for (let s = 0; s < n.upS.value; s++) {
    const c = e.upD[s], o = n.upD[s] || [];
    if (c && (!c.length || c.some((r, l) => r !== o[l])))
      return !0;
  }
  return !1;
}), yt = (t) => {
  for (let e = t.length - 1; e >= 0; e--) {
    const n = t[e], s = h.get(n.compKey);
    s && (s.upD = n.upD, s.upCB = n.upCB, s.upS.value = n.upS, s.mts = n.mts);
  }
};
let C = null;
const kn = (t, e, n, s) => {
  var o;
  let c = s;
  if (!(c.il || (o = f.blocks) != null && o.call(f, c))) {
    if (C) {
      if (C.props === e)
        if (C.trace.mounted || ht(C.trace.snapshots)) {
          if (ct(), c = lt(e) || c, c.il)
            return;
        } else
          ce();
      else if (ne(C.props, e) && (ct(), c.il && (c = lt(e) || c, c.il)))
        return;
    }
    oe(Pn(t, e, n, c));
  }
}, Ot = (t, e) => {
  let n = lt(e);
  for (; n; )
    if (n = R(n), n && n.compKey === t)
      return !0;
  return !1;
}, ne = (t, e) => Ot(t, e) || Ot(e, t), Pn = (t, e, n, s) => {
  const c = {
    tag: t,
    props: e,
    children: n,
    originalWDom: s,
    trace: { snapshots: [], mounted: !1 },
    attempt: 0,
    startVersion: 0,
    effects: [],
    work: { advance: () => null }
  };
  return se(c), c;
}, se = (t) => {
  t.startVersion = te(), t.trace.snapshots = [], t.trace.mounted = !1, t.effects = [], re(t, () => {
    t.work = Xe(
      gt(t.tag, t.props, t.children),
      t.originalWDom,
      t.effects
    );
  });
}, oe = (t) => {
  for (; ; ) {
    const e = re(
      t,
      () => t.work.advance(Rn(t) ? Sn : void 0)
    );
    if (!e) {
      C = t, on(() => {
        C = null, En(t);
      });
      return;
    }
    const n = bn(t, e);
    if (!t.trace.mounted && t.attempt < vn && !ht(t.trace.snapshots) && te() !== t.startVersion) {
      yt(t.trace.snapshots), t.attempt += 1, se(t);
      continue;
    }
    Mn(t.effects, n);
    return;
  }
}, En = (t) => {
  if (t.originalWDom.il) {
    yt(t.trace.snapshots);
    return;
  }
  oe(t);
}, Rn = (t) => an() && !t.originalWDom.il, Sn = () => rt(), lt = (t) => {
  const e = Vt(t, "vd");
  return e && e.value;
}, ce = () => {
  const t = C;
  C = null, cn(), yt(t.trace.snapshots);
};
f.settle = (t) => {
  var n;
  if (!C) return;
  const e = C;
  t && e.props !== t && !ne(e.props, t) || (e.trace.mounted || ht(e.trace.snapshots) ? ct() : (ce(), (n = h.get(e.props)) == null || n.up()));
};
let U = null;
const re = (t, e) => {
  const n = N, s = U;
  N = t.trace, U = t.effects, M.value = !0;
  try {
    return e();
  } finally {
    M.value = !1, N = n, U = s;
  }
}, bn = (t, e) => {
  var i;
  const { originalWDom: n, effects: s } = t, { isRoot: c, getParent: o, we: r, ae: l } = n;
  if (e.getParent && e.getParent !== o && ((i = f.reparent) == null || i.call(f, e)), e.getParent = o, !c && o) {
    const a = o(), p = a && a.children || [], P = p.indexOf(n);
    s.push(() => {
      P !== -1 && p.splice(P, 1, e), yn(a, n, e);
    });
  } else
    e.isRoot = !0, e.we = r, e.ae = l;
  return e;
}, Mn = (t, e) => {
  Ze(t), st(e), Zt();
}, xn = (t, e, n) => {
  if (zt(t))
    return dt(e, ...n);
  if (J(t)) {
    const s = gt(t, e, n);
    if (M.value)
      return s;
    const c = vt(s).resolve();
    return c.rs = s, c;
  }
  return {
    type: "e",
    // element
    // Declared on every new node: a diff sets it, and a drawn node keeps it
    // ('N'), so the node keeps its shape and reading it is a plain lookup.
    nr: void 0,
    [b]: !0,
    tag: t,
    props: e,
    children: n
  };
}, le = (t, e) => {
  const n = () => t.value;
  return e.map((s) => {
    var o;
    const c = ie(s);
    return c.getParent && ((o = f.reparent) == null || o.call(f, c)), c.getParent = n, c;
  });
}, ie = (t) => {
  if (t == null || typeof t == "boolean")
    return { type: null, nr: void 0, [b]: !0 };
  if (Array.isArray(t)) {
    const e = { value: void 0 }, n = le(e, t), s = {
      type: "l",
      // loop (array mapping)
      nr: void 0,
      [b]: !0,
      children: n
    };
    return e.value = s, s;
  } else if (typeof t == "string" || typeof t == "number")
    return { type: "t", nr: void 0, [b]: !0, text: t };
  return t;
}, Nn = (t, e, n) => (s = e) => {
  const c = M.value, o = k.value;
  M.value = !1;
  try {
    gn(), ye(s, t);
    const r = t(e, n);
    let l;
    if (typeof r == "function") {
      const i = r;
      l = Ft.has(i) ? i(e, n) : i(ee(s), e, n);
    } else {
      let i = !0;
      l = (a) => i ? (i = !1, r) : t(a, n);
    }
    return Tn(
      l,
      s,
      t,
      e,
      n
    );
  } finally {
    k.value = o, M.value = c;
  }
}, ue = (t) => t.ctor ? vt(
  t.rs || {
    ctor: t.ctor,
    props: t.compProps,
    children: t.compChild
  }
) : {
  type: t.type,
  tag: t.tag,
  props: t.props,
  text: t.text,
  children: t.children && [...t.children],
  getParent: t.getParent,
  [b]: !0
}, vt = ({
  ctor: t,
  props: e,
  children: n
}) => gt(t, { ...e }, [...n || []]), gt = (t, e, n) => {
  const s = t, c = n, o = Nn(t, e, c);
  return { ctor: s, props: e, children: c, resolve: o };
}, Tn = (t, e, n, s, c) => {
  const o = (a) => ie(t(a)), { wrappedComponentMaker: r, customNode: l } = Bn(
    o,
    s
  ), i = Ln(
    r,
    e,
    n,
    s,
    c
  );
  return ae(l, e, n, s, c, i), l;
}, Ln = (t, e, n, s, c) => {
  const o = () => An(t, e, n, s, c, o);
  return o;
}, An = (t, e, n, s, c, o) => {
  const r = k.value;
  try {
    Cn(e), he(e), dn();
    const l = t(s);
    return ae(l, e, n, s, c, o), l;
  } finally {
    k.value = r;
  }
}, Bn = (t, e) => {
  const n = (c) => {
    var l;
    const o = t(c), r = dt({}, o);
    return o.getParent && ((l = f.reparent) == null || l.call(f, o)), o.getParent = () => r, r;
  }, s = n(e);
  return { wrappedComponentMaker: n, customNode: s };
}, ae = (t, e, n, s, c, o) => {
  ge(t, {
    compProps: s,
    compChild: c,
    ctor: n,
    compKey: e,
    reRender: o
  });
  const r = () => {
    pn(
      e,
      () => kn(
        n,
        t.compProps || s,
        t.compChild || c,
        t
      )
    );
    const l = Vt(e, "vd");
    l && (l.value = t);
  };
  U ? U.push(r) : r();
}, $n = (t) => ({ value: t }), qn = () => Promise.resolve(), Hn = () => {
  const t = de();
  return t ? ee(t) : () => !1;
};
export {
  dt as Fragment,
  h as componentMap,
  ee as componentUpdate,
  Qn as deferRender,
  Fn as disposeComponentEntry,
  de as getComponentKey,
  Vt as getComponentSubInfo,
  hn as h,
  jn as hasPending,
  Un as isPropType,
  Zn as lmount,
  Ft as lmountComponentSet,
  Jn as mount,
  Vn as mountCallback,
  _n as mountReadyCallback,
  qn as nextTick,
  Kn as notifyStoreWrite,
  Xn as portal,
  $n as ref,
  In as render,
  kn as replaceWDom,
  On as setComponentMapManualMode,
  te as storeVersion,
  Yn as updateCallback,
  Hn as useRenew,
  zn as whenIdle
};
//# sourceMappingURL=lithentConcurrent.mjs.map
