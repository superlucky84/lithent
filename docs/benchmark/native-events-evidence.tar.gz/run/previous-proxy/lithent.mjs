const it = Symbol.for("lithentWDomSymbol"), M = { value: "" }, y = { value: null }, k = { value: !1 }, p = /* @__PURE__ */ new WeakMap(), ft = /* @__PURE__ */ new WeakSet();
let at = !1;
const Bt = (t, e) => {
  p.set(t, {
    ctor: e,
    vd: { value: null },
    up: () => {
    },
    upR: [],
    upS: { value: 0 },
    upD: [],
    upCB: [],
    mts: [],
    umts: [],
    wdCB: []
    // WDom creation callback queue
  });
}, Qt = () => y.value, R = () => p.get(y.value), Ae = (t, e) => {
  const n = p.get(t);
  return n ? n[e] : null;
}, Kt = (t) => {
  y.value = t;
}, jt = (t, e) => {
  y.value = t, Bt(t, e);
}, Oe = (t) => {
  at = t;
}, _t = () => at, dt = (t) => {
  const e = p.get(t);
  e && (e.umts.forEach((n) => n()), e.umts = []);
}, Ue = (t) => {
  dt(t), p.delete(t);
}, C = (t) => t.getParent && t.getParent(), Q = (t) => () => t, tt = Object.keys, pt = (t, e) => Object.prototype.propertyIsEnumerable.call(t, e), ht = (t, e) => {
  if (pt(t, e)) return !0;
  const n = Object.getPrototypeOf(t);
  return !Object.prototype.hasOwnProperty.call(t, e) && !!n && ht(n, e);
}, x = (t) => typeof t == "object" && t !== null, Be = (t) => x(t) && !Array.isArray(t) && !Object.getOwnPropertySymbols(t).includes(it), Vt = (t, e) => "ctor" in t ? t.ctor === (e && e.ctor) : t === (e && e.ctor), qt = (t, e) => e.type === "f" && // A component's node is a one-child fragment too: never update it in
// place as a plain fragment, or the component is never unmounted, nor
// update a plain fragment with one (a hoisted <Comp /> first drawn by a
// redraw), or it is never mounted.
!e.ctor && !t.ctor && !!e.children && e.children.length === (t.children && t.children.length), zt = (t, e) => e.type === "e" && e.tag === t.tag && !!e.children && e.children.length === (t.children && t.children.length), et = (t, e) => e.type === t.type, Gt = (t, e) => e.type === t.type && (z(t) && z(e) || !!e.children && e.children.length === (t.children && t.children.length)), V = (t) => (t && t.compProps && t.compProps.key) ?? (t && t.props && t.props.key), N = (t) => t === "f" || t === "l", K = (t) => typeof t == "function" && !vt(t) || x(t) && "resolve" in t, vt = (t) => t === H, It = (t) => !t.type, q = (t) => t[0] === "o" && t[1] === "n", X = (t) => A(V(t)), z = (t) => !!t && !!t.children && t.children.some(X), A = (t) => t != null, nt = (t, e) => t === "style" && x(e), Jt = (t, e) => t === "ref" && x(e), ct = /* @__PURE__ */ new WeakMap(), ot = (t, e) => {
  const n = t.constructor.prototype;
  let c = ct.get(n);
  c || ct.set(n, c = /* @__PURE__ */ new Map());
  let o = c.get(e);
  if (o === void 0) {
    const s = Object.getOwnPropertyDescriptor(n, e);
    o = !!(s && s.get && s.set), c.set(e, o);
  }
  return o;
}, st = (t) => t.localName.includes("-") && t.constructor === HTMLElement, Xt = (t) => K(t) ? "c" : t.type || "et", Yt = {
  c: Vt,
  l: Gt,
  t: et,
  e: zt,
  f: qt,
  et
}, S = Symbol(), L = Symbol();
function G(t) {
  var n;
  const e = (n = this[S]) == null ? void 0 : n["on" + t.type];
  typeof e == "function" ? e.call(this, t) : e && e.handleEvent(t);
}
const yt = (t, e, n) => {
  const c = e.slice(2).toLowerCase(), o = "on" + c, s = t[S];
  s && s[o] === n ? (delete s[o], t.removeEventListener(c, G)) : t.removeEventListener(c, n);
}, rt = (t, e, n, c) => {
  var u;
  if (c === n) return;
  const o = e.slice(2).toLowerCase(), s = "on" + o, r = t[S] || (t[S] = {}), l = r[s];
  (u = r[L]) != null && u.has(s) ? (c && yt(t, e, c), n && n !== r[s] && t.addEventListener(o, n)) : n ? l && l !== c && l !== n ? ((r[L] || (r[L] = /* @__PURE__ */ new Set())).add(s), t.addEventListener(o, n)) : (r[s] = n, l || t.addEventListener(o, G)) : l && l === c && (delete r[s], t.removeEventListener(o, G));
}, Ct = (t) => {
  const e = R();
  e && e.umts.push(t);
}, j = (t) => {
  const { compKey: e } = t;
  e && (t.il = !0, Zt(e)), kt(t);
}, kt = (t) => {
  if (t.tag === "portal" && t.el)
    for (const e in t.props)
      q(e) && yt(
        t.el,
        e,
        t.props[e]
      );
  (t.children || []).forEach((e) => {
    e.compKey ? j(e) : kt(e);
  });
}, Zt = (t) => {
  dt(t), _t() || p.delete(t);
};
let I = [];
const $t = (t) => {
  t.compKey && I.push(t);
}, b = () => {
  I.forEach(Ht), I = [];
}, Qe = (t) => {
  const e = R();
  e && e.mts.push(t);
}, Ht = (t) => {
  const { compKey: e } = t, n = e && p.get(e);
  if (n) {
    const c = n.mts;
    y.value = e, n.upS.value = 0, n.mts = [], c.forEach((o) => {
      const s = o();
      s && Ct(s);
    });
  }
}, Ke = (t) => {
  const e = R();
  e && e.wdCB.push(t);
}, mt = (t) => {
  const { compKey: e } = t;
  if (e) {
    const n = p.get(e), c = n && n.wdCB;
    y.value = e, c && c.length > 0 && (n.wdCB = [], c.forEach((o) => {
      const s = o();
      typeof s == "function" && Ct(s);
    }));
  }
}, lt = (t, e = () => []) => {
  const n = R();
  if (!n) return;
  const { upD: c, upS: o } = n, s = c[o.value], r = e();
  if (s && Wt(s, r)) {
    const l = t();
    l && n.upCB.push(l);
  }
  c[o.value] = r, o.value += 1;
}, wt = (t) => {
  const { compKey: e } = t, n = e && p.get(e);
  if (n) {
    const c = n.upCB;
    y.value = e, n.upS.value = 0, t.ctor && (n.upCB = [], c.forEach((o) => o()));
  }
}, Wt = (t, e) => t.length ? t.some((n, c) => n !== e[c]) : !0, Et = () => new DocumentFragment(), Rt = (t, e, n) => n ? t.insertBefore(e, n) : t.tagName === "HTML" ? t.replaceWith(e) : t.appendChild(e), Dt = (t) => document.createElement(t), je = (t, e, n, c) => {
  t.isRoot = !0, e = e || document.body, t.we = e;
  const o = T(t, c);
  return t.ae = n, (n || !c) && Rt(e, o, n), b(), () => {
    const s = p.get(t.compProps), r = s && s.vd.value || t;
    j(r), te(r);
  };
}, te = (t) => Z(t, t.we), Y = (t) => {
  const e = C(t);
  Z(
    t,
    t.isRoot ? t.we : e && P(e)
  );
}, Z = (t, e) => {
  if (e && t.el) {
    const n = t.el.nodeType;
    n === 11 || t.tag === "portal" ? Pt(t, e) : (n === 1 || n === 3) && e.removeChild(t.el), t.el = void 0;
  }
}, Pt = (t, e) => {
  const n = t.oc || t.children || [];
  if (n.length > 1 && n.every((c) => {
    const o = c.el && c.el.nodeType;
    return (o === 1 || o === 3) && c.el.tagName !== "HTML" && c.tag !== "portal";
  })) {
    let c = 0;
    for (let o = e.firstChild; o && c <= n.length; o = o.nextSibling)
      c++;
    if (c === n.length) {
      e.textContent = "", n.forEach((o) => o.el = void 0);
      return;
    }
  }
  n.forEach((c) => {
    const o = c.el && c.el.nodeType;
    if (o)
      if (o === 1 || o === 3) {
        const s = c.el;
        s.tagName === "HTML" ? s.innerHTML = "" : s.remove();
      } else o === 11 && Pt(c, e);
  });
}, ee = (t, e) => {
  const n = P(e);
  t.forEach((c) => {
    j(c), Z(c, n);
  });
}, gt = (t) => {
  Y(t), Mt(t);
}, Mt = (t, e) => {
  e = e || T(t);
  const n = C(t);
  if (!n || !n.type) {
    t.isRoot && t.we && t.tag !== "portal" && (Rt(t.we, e, t.ae), b());
    return;
  }
  const c = P(n), o = $(t, n);
  c && (t.tag !== "portal" && c.insertBefore(e, o || null), b());
}, St = (t) => N(t.type) ? (t.children || []).reduce((e, n) => {
  const c = St(n);
  return c && e.appendChild(c), e;
}, Et()) : t.el, $ = (t, e) => {
  const n = e.children || [];
  return U(n.slice(n.indexOf(t) + 1)) || (N(e.type) ? e.isRoot ? e.ae : $(e, C(e)) : void 0);
}, O = /* @__PURE__ */ new Set(), U = (t) => t.reduce(
  (e, n) => {
    if (e || O.size && O.has(n)) return e;
    const { type: c, el: o } = n;
    if (c && N(c)) {
      const s = U(n.children || []);
      if (s) return s;
    }
    return o && o.nodeType !== 11 ? o : e;
  },
  void 0
), ne = (t) => {
  const e = C(t), n = t.el;
  if (n && (e ? e.type : t.isRoot))
    if (!e || n.nodeType === 11)
      gt(t);
    else {
      const c = P(e), o = T(t);
      c && t.tag !== "portal" && c.replaceChild(o, n), b();
    }
}, ut = (t) => {
  if (t.type === "t") {
    re(t);
    return;
  }
  if (t.el) {
    const { op: e, props: n } = t;
    xt(n, t.el, e), t.tag === "input" && (t.el.value = String(
      n && n.value || ""
    ));
  }
  ce(t), wt(t);
}, ce = (t) => {
  const e = t.children || [];
  if (t.type !== "l" || !e.some(
    (i) => "ATS".includes(i.nr) || i.oi !== void 0
  )) {
    e.forEach(J);
    return;
  }
  const n = [], c = [], o = [];
  let s = !0;
  e.forEach((i, a) => {
    const v = i.oi, g = i.nr;
    g === "S" ? o.push(i) : g !== "A" && v !== void 0 && (v < c[c.length - 1] && (s = !1), n.push(a), c.push(v));
  });
  let r;
  if (!s) {
    const i = r = [];
    oe(c).forEach((a) => i[n[a]] = !0), n.forEach(
      (a) => i[a] || (i[a] = !1, o.push(e[a]))
    );
  }
  const l = [];
  let u = 0;
  o.forEach((i) => O.add(i));
  try {
    e.forEach((i, a) => {
      const v = i.nr;
      v === "A" || v === "S" ? (v === "S" && Y(i), l[a] = T(i), u++) : J(i);
    });
  } finally {
    o.forEach((i) => O.delete(i));
  }
  const f = P(t), h = t.isRoot ? t.ae : $(t, C(t));
  let d = e.length;
  for (; d > 0 && l[d - 1] !== void 0; )
    d--;
  for (let i = d; i < e.length; i++) {
    const a = l[i];
    a && f && e[i].tag !== "portal" && f.insertBefore(a, h || null);
  }
  if (r || u > e.length - d) {
    let i = U(e.slice(d)) || h;
    for (let a = d - 1; a >= 0; a--) {
      const v = e[a], g = l[a] !== void 0, Ut = !!r && r[a] === !1;
      if ((g || Ut) && f && v.tag !== "portal") {
        const D = g ? l[a] : St(v);
        D && f.insertBefore(D, i || null);
      }
      const W = U([v]);
      W && (i = W);
    }
  }
  e.forEach(bt), b();
}, bt = (t) => {
  t.oi = t.oc = t.op = void 0, t.nr = "N";
}, oe = (t) => {
  const e = [], n = [];
  t.forEach((s, r) => {
    let l = 0, u = e.length;
    if (u && t[e[u - 1]] < s)
      l = u;
    else
      for (; l < u; ) {
        const f = l + u >> 1;
        t[e[f]] < s ? l = f + 1 : u = f;
      }
    n[r] = l ? e[l - 1] : -1, e[l] = r;
  });
  let c = e.length, o = e[c - 1];
  for (; c-- > 0; )
    e[c] = o, o = n[o];
  return e;
}, J = (t) => {
  const { nr: e } = t;
  e && e !== "N" && (se[e](t), bt(t));
}, se = {
  A: Mt,
  D: Y,
  R: ne,
  U: ut,
  S: gt,
  // A keyed item reaches here only as a component redrawing itself: it has
  // not moved, so it is updated in place. Re-inserting its nodes would blur a
  // focused input inside it or reload an iframe. Moves within a list are
  // placed by updateChildren.
  T: ut
}, re = (t) => {
  t.el && (t.el.nodeValue = String(t.text));
}, xt = (t, e, n) => {
  const c = n || {};
  for (const o in t) {
    const s = t[o];
    s !== c[o] && (q(o) ? rt(
      e,
      o,
      s,
      c[o]
    ) : o === "key" || o === "portal" && x(s) || (o === "innerHTML" && typeof s == "string" ? e.innerHTML = s : nt(o, s) ? ie(
      s,
      nt(o, c.style) ? c.style : {},
      e
    ) : Jt(o, s) ? s.value = e : o && (o !== "type" && ot(e, o) ? e[o] = s : (le(
      o === "className" ? "class" : o,
      e,
      s
    ), st(e) && !(o in HTMLElement.prototype) && (e[o] = s)))));
  }
  for (const o in c)
    if (!(t && ht(t, o))) {
      if (q(o)) {
        rt(
          e,
          o,
          void 0,
          c[o]
        );
        continue;
      }
      e.removeAttribute(o), st(e) ? delete e[o] : e.localName.includes("-") && ot(e, o) && (e[o] = void 0);
    }
}, le = (t, e, n) => M.value && t !== "xmlns" ? e.setAttributeNS(null, t, n) : e.setAttribute(t, n), T = (t, e) => {
  let n;
  const { type: c, tag: o, text: s, props: r, children: l = [] } = t, u = N(c);
  if (mt(t), o === "svg" && (M.value = String(r && r.xmlns)), e)
    n = t.el;
  else {
    if (!c || u)
      n = Et();
    else if (c === "e" && o)
      o === "portal" && r && r.portal ? n = r.portal : n = M.value ? document.createElementNS(M.value, o) : Dt(o);
    else if (c === "t" && A(s))
      n = document.createTextNode(String(s));
    else
      throw Error("Invalid wDom");
    t.el = n;
  }
  return ue(t, l, n, e), xt(r, n, null), $t(t), o === "svg" && (M.value = ""), n;
}, ue = (t, e, n, c) => {
  const o = Q(t);
  e.forEach((s, r) => {
    if (s.nr === "N" && !c) {
      const l = At(s);
      s = e[r] = "resolve" in l ? l.resolve() : l;
    }
    if (s.getParent = o, s.nr = "N", s.type) {
      const l = T(s, c);
      s.tag !== "portal" && !c && n && n.appendChild(l);
    }
  });
}, ie = (t, e, n) => {
  const c = { ...e };
  if (!(n instanceof HTMLElement)) return;
  const o = n.style;
  for (const s in t)
    o[s] = t[s], delete c[s];
  for (const s in c)
    o[s] = "";
}, P = (t) => N(t.type) ? t.isRoot ? t.we : P(C(t)) : t.el, _ = (t, e) => (t !== e && t.nr && (t = At(t)), fe(
  t,
  !!e && Yt[Xt(t)](t, e),
  e
)), fe = (t, e, n) => {
  const c = ve(t, e, n), o = de(
    c,
    e,
    n
  ), s = o === "N";
  return s || (c.children = ye(
    c,
    e,
    n
  )), c.nr = o, ae(c, n, o), !s && n && (n.il = !0, n.ctor && (n.children = void 0)), n && n.tag === "portal" && (c.tag = "portal"), c;
}, ae = (t, e, n) => {
  n !== "A" && e && (t.el = e.el), (n === "D" || n === "R" || n === "S") && (e && j(e), t.oc = e && e.children), t.op = e && e.props;
}, de = (t, e, n) => {
  if (It(t)) return "D";
  if (t === n || e && t.type === "t" && t.text === n.text)
    return "N";
  if (!(n && n.type)) return "A";
  const c = C(n), o = !t.isRoot && c && c.type === "l" && X(t);
  return e ? o ? "T" : "U" : o ? "S" : "R";
}, pe = (t, e) => {
  t && e !== t && (e = e || {}, tt(t).forEach(
    (n) => pt(e, n) || delete t[n]
  ), tt(e).forEach((n) => t[n] = e[n]));
}, he = (t, e) => {
  const { compProps: n, compChild: c } = t, { props: o, children: s } = e;
  return n && pe(n, o), c && s && c !== s && c.splice(0, c.length, ...s), t.reRender && t.reRender();
}, ve = (t, e, n) => K(t) ? e && n ? he(n, t) : (
  // Resolved before (children a component draws again somewhere else):
  // the first instance owns its props, which are also its key, so the
  // new instance is made from a copy.
  (t.rd ? m(t) : (t.rd = !0, t)).resolve()
) : t, ye = (t, e, n) => e && n ? ke(t, n) : Ce(t), Ce = (t) => {
  const e = Q(t);
  return (t.children || []).map((n) => {
    const c = _(n);
    return c.getParent = e, c;
  });
}, ke = (t, e) => {
  if (t.type === "l" && z(t))
    return Ee(t, e);
  const n = e.children || [], c = Q(t);
  return (t.children || []).map((o, s) => {
    const r = _(o, n[s]);
    return r.getParent = c, r;
  });
}, Ee = (t, e) => {
  const n = e.children || [], c = /* @__PURE__ */ new Map();
  n.forEach((l, u) => {
    const f = V(l);
    A(f) && !c.has(f) && c.set(f, u);
  });
  const o = [], s = Q(t), r = (t.children || []).map((l, u) => {
    const f = V(l), h = A(f) ? c.get(f) : u < n.length && !X(n[u]) ? u : void 0;
    let d;
    h !== void 0 && (c.delete(f), o[h] = !0, d = n[h]);
    const i = _(l, d);
    return d && (i.oi = h), i.getParent = s, i;
  });
  return ee(
    n.filter((l, u) => !o[u]),
    e
  ), r;
}, F = /* @__PURE__ */ new Map();
let B = !1;
const Re = (t, e) => {
  F.set(t, e), B || (B = !0, queueMicrotask(Tt));
}, Pe = (t, e) => {
  const n = p.get(t);
  n && (n.up = () => {
    const c = n.vd.value;
    Re(t, () => e(c));
  });
}, Nt = (t) => () => {
  const e = p.get(t), n = e && e.up;
  return n ? (n(), !0) : !1;
}, Tt = () => {
  try {
    F.forEach((t, e) => {
      F.delete(e), t();
    });
  } finally {
    B = !!F.size, B && queueMicrotask(Tt);
  }
}, E = (t, e, n, c, o, s) => ({
  type: t,
  nr: void 0,
  tag: e,
  props: n,
  text: c,
  children: o,
  getParent: s,
  el: void 0,
  oi: void 0,
  oc: void 0,
  op: void 0,
  il: void 0,
  [it]: !0
}), _e = (t, e = () => []) => {
  const n = R();
  n && (n.upR.push(() => lt(t, e)), lt(t, e));
}, ge = () => {
  const t = R(), e = t && t.upR;
  e && e.length && e.forEach((n) => n());
}, H = (t, ...e) => E("f", void 0, void 0, void 0, e), Me = (t, e, ...n) => {
  const c = { value: void 0 }, o = Lt(c, n), s = xe(t, e || {}, o);
  return K(s) || (c.value = s), s;
}, Ve = (t, e) => Me("portal", { portal: e }, t), qe = (t) => (e, n) => t, ze = (t) => (e, n) => (ft.add(t), t), Se = (t, e, n) => {
  const c = (o, s) => {
    if (!(!o || s.has(o))) {
      if (s.add(o), o.compChild) {
        const r = o.compChild.indexOf(e);
        r !== -1 && o.compChild.splice(r, 1, n);
      }
      c(o.getParent ? o.getParent() : void 0, s);
    }
  };
  c(t, /* @__PURE__ */ new Set());
}, be = (t, e, n, c) => {
  if (c.il)
    return;
  k.value = !0;
  let o;
  try {
    const s = w(t, e, n);
    o = _(s, c);
    const { isRoot: r, getParent: l, we: u, ae: f } = c;
    if (o.getParent = l, !r && l) {
      const h = l(), d = h && h.children || [], i = d.indexOf(c);
      i !== -1 && d.splice(i, 1, o), Se(h, c, o);
    } else
      o.isRoot = !0, o.we = u, o.ae = f;
  } finally {
    k.value = !1;
  }
  J(o);
}, xe = (t, e, n) => {
  if (vt(t))
    return H(e, ...n);
  if (K(t)) {
    const c = w(t, e, n);
    if (k.value)
      return c;
    const o = m(c).resolve();
    return o.rs = c, o;
  }
  return E("e", t, e, void 0, n);
}, Lt = (t, e) => {
  const n = () => t.value;
  return e.map((c) => {
    const o = Ft(c);
    return o.getParent = n, o;
  });
}, Ft = (t) => {
  if (t == null || typeof t == "boolean")
    return E(null);
  if (Array.isArray(t)) {
    const e = { value: void 0 }, n = Lt(e, t), c = E("l", void 0, void 0, void 0, n);
    return e.value = c, c;
  } else if (typeof t == "string" || typeof t == "number")
    return E("t", void 0, void 0, t);
  return t;
}, Ne = (t, e, n) => (c = e) => {
  const o = k.value, s = y.value;
  k.value = !1;
  try {
    jt(c, t);
    const r = t(e, n);
    let l;
    if (typeof r == "function") {
      const u = r;
      l = ft.has(u) ? u(e, n) : u(Nt(c), e, n);
    } else {
      let u = !0;
      l = (f) => u ? (u = !1, r) : t(f, n);
    }
    return Te(
      l,
      c,
      t,
      e,
      n
    );
  } finally {
    y.value = s, k.value = o;
  }
}, At = (t) => t.ctor ? m(
  t.rs || {
    ctor: t.ctor,
    props: t.compProps,
    children: t.compChild
  }
) : E(
  t.type,
  t.tag,
  t.props,
  t.text,
  t.children && [...t.children],
  t.getParent
), m = ({
  ctor: t,
  props: e,
  children: n
}) => w(t, { ...e }, [...n || []]), w = (t, e, n) => ({
  ctor: t,
  props: e,
  children: n,
  resolve: Ne(t, e, n)
}), Te = (t, e, n, c, o) => {
  const s = Fe(t), r = s(c), l = Le(
    s,
    e,
    n,
    c,
    o
  );
  return Ot(r, e, n, c, o, l), Pe(
    e,
    (u) => be(
      n,
      u.compProps || c,
      u.compChild || o,
      u
    )
  ), r;
}, Le = (t, e, n, c, o) => {
  const s = () => {
    const r = y.value;
    try {
      Kt(e), ge();
      const l = t(c);
      return Ot(l, e, n, c, o, s), l;
    } finally {
      y.value = r;
    }
  };
  return s;
}, Fe = (t) => (e) => {
  const n = Ft(t(e)), c = H({}, n);
  return n.getParent = () => c, c;
}, Ot = (t, e, n, c, o, s) => {
  t.compProps = c, t.compChild = o, t.ctor = n, t.compKey = e, t.reRender = s;
  const r = p.get(e);
  r && (r.vd.value = t);
}, Ge = (t) => ({ value: t }), Ie = () => Promise.resolve(), Je = () => {
  const t = Qt();
  return t ? Nt(t) : () => !1;
};
export {
  H as Fragment,
  p as componentMap,
  Nt as componentUpdate,
  Ue as disposeComponentEntry,
  Qt as getComponentKey,
  Ae as getComponentSubInfo,
  Me as h,
  Be as isPropType,
  ze as lmount,
  ft as lmountComponentSet,
  qe as mount,
  Qe as mountCallback,
  Ke as mountReadyCallback,
  Ie as nextTick,
  Ve as portal,
  Ge as ref,
  je as render,
  be as replaceWDom,
  Oe as setComponentMapManualMode,
  _e as updateCallback,
  Je as useRenew
};
//# sourceMappingURL=lithent.mjs.map
