const Ht = Symbol.for("lithentWDomSymbol"), P = { value: "" }, w = { value: null }, E = { value: !1 }, m = /* @__PURE__ */ new WeakMap(), jt = /* @__PURE__ */ new WeakSet(), Kt = (t, e) => {
  m.set(t, {
    ctor: e,
    vd: { value: null },
    up: () => {
    },
    upR: [],
    upS: { value: 0 },
    upD: [],
    upCB: [],
    mts: [],
    umts: [],
    wdCB: []
    // WDom creation callback queue
  });
}, yt = () => m.get(w.value), Ut = (t) => {
  w.value = t;
}, Wt = (t, e) => {
  w.value = t, Kt(t, e);
}, zt = (t) => {
  const e = m.get(t);
  e && (e.umts.forEach((o) => o()), e.umts = []);
}, b = (t) => t.getParent && t.getParent(), K = (t) => () => t, rt = Object.keys, gt = (t, e) => Object.prototype.propertyIsEnumerable.call(t, e), mt = (t, e) => {
  if (gt(t, e)) return !0;
  const o = Object.getPrototypeOf(t);
  return !Object.prototype.hasOwnProperty.call(t, e) && !!o && mt(o, e);
}, U = (t) => typeof t == "object" && t !== null, qt = (t, e) => "ctor" in t ? t.ctor === (e && e.ctor) : t === (e && e.ctor), It = (t, e) => e.type === "f" && // A component's node is a one-child fragment too: never update it in
// place as a plain fragment, or the component is never unmounted, nor
// update a plain fragment with one (a hoisted <Comp /> first drawn by a
// redraw), or it is never mounted.
!e.ctor && !t.ctor && !!e.children && e.children.length === (t.children && t.children.length), $t = (t, e) => e.type === "e" && e.tag === t.tag && !!e.children && e.children.length === (t.children && t.children.length), lt = (t, e) => e.type === t.type, Ft = (t, e) => e.type === t.type && (V(t) && V(e) || !!e.children && e.children.length === (t.children && t.children.length)), F = (t) => (t && t.compProps && t.compProps.key) ?? (t && t.props && t.props.key), M = (t) => t === "f" || t === "l", W = (t) => typeof t == "function" && !wt(t) || U(t) && "resolve" in t, wt = (t) => t === I, Qt = (t) => !t.type, Q = (t) => t[0] === "o" && t[1] === "n", J = (t) => B(F(t)), V = (t) => !!t && !!t.children && t.children.some(J), B = (t) => t != null, st = (t, e) => t === "style" && U(e), Vt = (t, e) => t === "ref" && U(e), ct = /* @__PURE__ */ new WeakMap(), at = (t, e) => {
  const o = t.constructor.prototype;
  let n = ct.get(o);
  n || ct.set(o, n = /* @__PURE__ */ new Map());
  let r = n.get(e);
  if (r === void 0) {
    const l = Object.getOwnPropertyDescriptor(o, e);
    r = !!(l && l.get && l.set), n.set(e, r);
  }
  return r;
}, it = (t) => t.localName.includes("-") && t.constructor === HTMLElement, _t = (t) => W(t) ? "c" : t.type || "et", Gt = {
  c: qt,
  l: Ft,
  t: lt,
  e: $t,
  f: It,
  et: lt
}, bt = (t) => {
  const e = yt();
  e && e.umts.push(t);
}, z = (t) => {
  const { compKey: e } = t;
  e && (t.il = !0, Jt(e)), Et(t);
}, Et = (t) => {
  if (t.tag === "portal" && t.el)
    for (const e in t.props)
      Q(e) && t.el.removeEventListener(
        e.slice(2).toLowerCase(),
        t.props[e]
      );
  (t.children || []).forEach((e) => {
    e.compKey ? z(e) : Et(e);
  });
}, Jt = (t) => {
  zt(t), m.delete(t);
};
let _ = [];
const Xt = (t) => {
  t.compKey && _.push(t);
}, k = () => {
  _.forEach(Yt), _ = [];
}, Yt = (t) => {
  const { compKey: e } = t, o = e && m.get(e);
  if (o) {
    const n = o.mts;
    w.value = e, o.upS.value = 0, o.mts = [], n.forEach((r) => {
      const l = r();
      l && bt(l);
    });
  }
}, Zt = (t) => {
  const { compKey: e } = t;
  if (e) {
    const o = m.get(e), n = o && o.wdCB;
    w.value = e, n && n.length > 0 && (o.wdCB = [], n.forEach((r) => {
      const l = r();
      typeof l == "function" && bt(l);
    }));
  }
}, te = (t) => {
  const { compKey: e } = t, o = e && m.get(e);
  if (o) {
    const n = o.upCB;
    w.value = e, o.upS.value = 0, t.ctor && (o.upCB = [], n.forEach((r) => r()));
  }
}, R = {}, Ct = () => new DocumentFragment(), kt = (t, e, o) => o ? t.insertBefore(e, o) : t.tagName === "HTML" ? t.replaceWith(e) : t.appendChild(e), ee = (t) => document.createElement(t), oe = (t, e, o, n) => {
  t.isRoot = !0, e = e || document.body, t.we = e;
  const r = L(t, n);
  return t.ae = o, kt(e, r, o), k(), () => {
    const l = m.get(t.compProps), s = l && l.vd.value || t;
    z(s), ne(s);
  };
}, ne = (t) => Y(t, t.we), X = (t) => {
  const e = b(t);
  Y(
    t,
    t.isRoot ? t.we : e && S(e)
  );
}, Y = (t, e) => {
  if (e && t.el) {
    const o = t.el.nodeType;
    o === 11 || t.tag === "portal" ? St(t, e) : (o === 1 || o === 3) && e.removeChild(t.el), t.el = void 0;
  }
}, St = (t, e) => {
  const o = t.oc || t.children || [];
  if (o.length > 1 && o.every((n) => {
    const r = n.el && n.el.nodeType;
    return (r === 1 || r === 3) && n.el.tagName !== "HTML" && n.tag !== "portal";
  })) {
    let n = 0;
    for (let r = e.firstChild; r && n <= o.length; r = r.nextSibling)
      n++;
    if (n === o.length) {
      e.textContent = "", o.forEach((r) => r.el = void 0);
      return;
    }
  }
  o.forEach((n) => {
    const r = n.el && n.el.nodeType;
    if (r)
      if (r === 1 || r === 3) {
        const l = n.el;
        l.tagName === "HTML" ? l.innerHTML = "" : l.remove();
      } else r === 11 && St(n, e);
  });
}, re = (t, e) => {
  const o = S(e);
  t.forEach((n) => {
    z(n), Y(n, o);
  });
}, xt = (t) => {
  X(t), Pt(t);
}, Pt = (t, e) => {
  e = e || L(t);
  const o = b(t);
  if (!o || !o.type) {
    t.isRoot && t.we && t.tag !== "portal" && (kt(t.we, e, t.ae), k());
    return;
  }
  const n = S(o), r = Z(t, o);
  n && (t.tag !== "portal" && n.insertBefore(e, r || null), k());
}, Rt = (t) => M(t.type) ? (t.children || []).reduce((e, o) => {
  const n = Rt(o);
  return n && e.appendChild(n), e;
}, Ct()) : t.el, Z = (t, e) => {
  const o = e.children || [];
  return H(o.slice(o.indexOf(t) + 1)) || (M(e.type) ? e.isRoot ? e.ae : Z(e, b(e)) : void 0);
}, O = /* @__PURE__ */ new Set(), H = (t) => t.reduce(
  (e, o) => {
    if (e || O.size && O.has(o)) return e;
    const { type: n, el: r } = o;
    if (n && M(n)) {
      const l = H(o.children || []);
      if (l) return l;
    }
    return r && r.nodeType !== 11 ? r : e;
  },
  void 0
), le = (t) => {
  const e = b(t), o = t.el;
  if (o && (e ? e.type : t.isRoot))
    if (!e || o.nodeType === 11)
      xt(t);
    else {
      const n = S(e), r = L(t);
      n && t.tag !== "portal" && n.replaceChild(r, o), k();
    }
}, pt = (t) => {
  if (t.type === "t") {
    ie(t);
    return;
  }
  let e = !1;
  if (t.type === "l") {
    const o = R.value, n = o && o.proofs.get(t);
    o && o.proofs.delete(t), e = !!(o && o.ready && !o.invalid && n && n === t.children);
  }
  if (t.el) {
    const { op: o, props: n } = t;
    Tt(n, t.el, o), t.tag === "input" && (t.el.value = String(
      n && n.value || ""
    ));
  }
  se(t, e), te(t);
}, se = (t, e) => {
  const o = t.children || [];
  if (e) {
    o.forEach(A), o.forEach(G), k();
    return;
  }
  if (t.type !== "l" || !o.some(
    (a) => "ATS".includes(a.nr) || a.oi !== void 0
  )) {
    o.forEach(A);
    return;
  }
  const n = [], r = [], l = [];
  let s = !0;
  o.forEach((a, p) => {
    const h = a.oi, x = a.nr;
    x === "S" ? l.push(a) : x !== "A" && h !== void 0 && (h < r[r.length - 1] && (s = !1), n.push(p), r.push(h));
  });
  let c;
  if (!s) {
    const a = c = [];
    ce(r).forEach((p) => a[n[p]] = !0), n.forEach(
      (p) => a[p] || (a[p] = !1, l.push(o[p]))
    );
  }
  const i = [];
  let f = 0;
  l.forEach((a) => O.add(a));
  try {
    o.forEach((a, p) => {
      const h = a.nr;
      h === "A" || h === "S" ? (h === "S" && X(a), i[p] = L(a), f++) : A(a);
    });
  } finally {
    l.forEach((a) => O.delete(a));
  }
  const y = S(t), v = t.isRoot ? t.ae : Z(t, b(t));
  let u = o.length;
  for (; u > 0 && i[u - 1] !== void 0; )
    u--;
  for (let a = u; a < o.length; a++) {
    const p = i[a];
    p && y && o[a].tag !== "portal" && y.insertBefore(p, v || null);
  }
  if (c || f > o.length - u) {
    let a = H(o.slice(u)) || v;
    for (let p = u - 1; p >= 0; p--) {
      const h = o[p], x = i[p] !== void 0, Ot = !!c && c[p] === !1;
      if ((x || Ot) && y && h.tag !== "portal") {
        const nt = x ? i[p] : Rt(h);
        nt && y.insertBefore(nt, a || null);
      }
      const ot = H([h]);
      ot && (a = ot);
    }
  }
  o.forEach(G), k();
}, G = (t) => {
  t.oi = t.oc = t.op = void 0, t.nr = "N";
}, ce = (t) => {
  const e = [], o = [];
  t.forEach((l, s) => {
    let c = 0, i = e.length;
    if (i && t[e[i - 1]] < l)
      c = i;
    else
      for (; c < i; ) {
        const f = c + i >> 1;
        t[e[f]] < l ? c = f + 1 : i = f;
      }
    o[s] = c ? e[c - 1] : -1, e[c] = s;
  });
  let n = e.length, r = e[n - 1];
  for (; n-- > 0; )
    e[n] = r, r = o[r];
  return e;
}, A = (t) => {
  const { nr: e } = t;
  e && e !== "N" && (ae[e](t), G(t));
}, ae = {
  A: Pt,
  D: X,
  R: le,
  U: pt,
  S: xt,
  // A keyed item reaches here only as a component redrawing itself: it has
  // not moved, so it is updated in place. Re-inserting its nodes would blur a
  // focused input inside it or reload an iframe. Moves within a list are
  // placed by updateChildren.
  T: pt
}, ie = (t) => {
  t.el && (t.el.nodeValue = String(t.text));
}, Tt = (t, e, o) => {
  const n = o || {};
  for (const r in t) {
    const l = t[r];
    l !== n[r] && (Q(r) ? dt(
      e,
      r,
      l,
      n[r]
    ) : r === "key" || r === "portal" && U(l) || (r === "innerHTML" && typeof l == "string" ? e.innerHTML = l : st(r, l) ? ue(
      l,
      st(r, n.style) ? n.style : {},
      e
    ) : Vt(r, l) ? l.value = e : r && (r !== "type" && at(e, r) ? e[r] = l : (pe(
      r === "className" ? "class" : r,
      e,
      l
    ), it(e) && !(r in HTMLElement.prototype) && (e[r] = l)))));
  }
  for (const r in n)
    if (!(t && mt(t, r))) {
      if (Q(r)) {
        dt(
          e,
          r,
          void 0,
          n[r]
        );
        continue;
      }
      e.removeAttribute(r), it(e) ? delete e[r] : e.localName.includes("-") && at(e, r) && (e[r] = void 0);
    }
}, pe = (t, e, o) => P.value && t !== "xmlns" ? e.setAttributeNS(null, t, o) : e.setAttribute(t, o), L = (t, e) => {
  let o;
  const { type: n, tag: r, text: l, props: s, children: c = [] } = t, i = M(n);
  if (Zt(t), r === "svg" && (P.value = String(s && s.xmlns)), !e) {
    if (!n || i)
      o = Ct();
    else if (n === "e" && r)
      r === "portal" && s && s.portal ? o = s.portal : o = P.value ? document.createElementNS(P.value, r) : ee(r);
    else if (n === "t" && B(l))
      o = document.createTextNode(String(l));
    else
      throw Error("Invalid wDom");
    t.el = o;
  }
  return de(t, c, o, e), Tt(s, o, null), Xt(t), r === "svg" && (P.value = ""), o;
}, de = (t, e, o, n) => {
  const r = K(t);
  e.forEach((l, s) => {
    if (l.nr === "N" && !n) {
      const c = Dt(l);
      l = e[s] = "resolve" in c ? c.resolve() : c;
    }
    if (l.getParent = r, l.nr = "N", l.type) {
      const c = L(l, n);
      l.tag !== "portal" && !n && o && o.appendChild(c);
    }
  });
}, dt = (t, e, o, n) => {
  const r = e.slice(2).toLowerCase();
  n !== o && (n && t.removeEventListener(r, n), o && t.addEventListener(r, o));
}, ue = (t, e, o) => {
  const n = { ...e };
  if (!(o instanceof HTMLElement)) return;
  const r = o.style;
  for (const l in t)
    r[l] = t[l], delete n[l];
  for (const l in n)
    r[l] = "";
}, S = (t) => M(t.type) ? t.isRoot ? t.we : S(b(t)) : t.el, q = (t, e) => (t !== e && t.nr && (t = Dt(t)), he(
  t,
  !!e && Gt[_t(t)](t, e),
  e
)), he = (t, e, o) => {
  const n = me(t, e, o), r = ve(
    n,
    e,
    o
  ), l = r === "N";
  return l || (n.children = we(
    n,
    e,
    o
  )), n.nr = r, fe(n, o, r), !l && o && (o.il = !0, o.ctor && (o.children = void 0)), o && o.tag === "portal" && (n.tag = "portal"), n;
}, fe = (t, e, o) => {
  o !== "A" && e && (t.el = e.el), (o === "D" || o === "R" || o === "S") && (e && z(e), t.oc = e && e.children), t.op = e && e.props;
}, ve = (t, e, o) => {
  if (Qt(t)) return "D";
  if (t === o || e && t.type === "t" && t.text === o.text)
    return "N";
  if (!(o && o.type)) return "A";
  const n = b(o), r = !t.isRoot && n && n.type === "l" && J(t);
  return e ? r ? "T" : "U" : r ? "S" : "R";
}, ye = (t, e) => {
  t && e !== t && (e = e || {}, rt(t).forEach(
    (o) => gt(e, o) || delete t[o]
  ), rt(e).forEach((o) => t[o] = e[o]));
}, ge = (t, e) => {
  const { compProps: o, compChild: n } = t, { props: r, children: l } = e;
  return o && ye(o, r), n && l && n !== l && n.splice(0, n.length, ...l), t.reRender && t.reRender();
}, me = (t, e, o) => W(t) ? e && o ? ge(o, t) : (
  // Resolved before (children a component draws again somewhere else):
  // the first instance owns its props, which are also its key, so the
  // new instance is made from a copy.
  (t.rd ? tt(t) : (t.rd = !0, t)).resolve()
) : t, we = (t, e, o) => e && o ? Ee(t, o) : be(t), be = (t) => {
  const e = K(t);
  return (t.children || []).map((o) => {
    const n = q(o);
    return n.getParent = e, n;
  });
}, Ee = (t, e) => {
  if (t.type === "l" && V(t))
    return Ce(t, e);
  const o = e.children || [], n = K(t);
  return (t.children || []).map((r, l) => {
    const s = q(r, o[l]);
    return s.getParent = n, s;
  });
}, Ce = (t, e) => {
  const o = e.children || [], n = R.value, r = /* @__PURE__ */ new Map();
  o.forEach((y, v) => {
    const u = F(y);
    B(u) && !r.has(u) && r.set(u, v);
  });
  const l = [], s = K(t), c = t.children || [];
  let i = c.length === o.length;
  const f = c.map((y, v) => {
    const u = F(y), a = B(u) ? r.get(u) : v < o.length && !J(o[v]) ? v : void 0;
    let p;
    a !== void 0 && (r.delete(u), l[a] = !0, p = o[a]);
    const h = q(y, p);
    return p && (h.oi = a), h.getParent = s, i = i && a === v && (h.nr === "N" || h.nr === "U" || h.nr === "T") && h.tag !== "portal", h;
  });
  return re(
    o.filter((y, v) => !l[v]),
    e
  ), i && n && !n.invalid && n.proofs.set(t, f), f;
}, D = /* @__PURE__ */ new Map();
let j = !1;
const ke = (t, e) => {
  D.set(t, e), j || (j = !0, queueMicrotask(Mt));
}, Se = (t, e) => {
  const o = m.get(t);
  o && (o.up = () => {
    const n = o.vd.value;
    ke(t, () => e(n));
  });
}, xe = (t) => () => {
  const e = m.get(t), o = e && e.up;
  return o ? (o(), !0) : !1;
}, Mt = () => {
  try {
    D.forEach((t, e) => {
      D.delete(e), t();
    });
  } finally {
    j = !!D.size, j && queueMicrotask(Mt);
  }
}, C = (t, e, o, n, r, l) => ({
  type: t,
  nr: void 0,
  tag: e,
  props: o,
  text: n,
  children: r,
  getParent: l,
  el: void 0,
  oi: void 0,
  oc: void 0,
  op: void 0,
  il: void 0,
  [Ht]: !0
}), Pe = () => {
  const t = yt(), e = t && t.upR;
  e && e.length && e.forEach((o) => o());
}, I = (t, ...e) => C("f", void 0, void 0, void 0, e), d = (t, e, ...o) => {
  const n = { value: void 0 }, r = Nt(n, o), l = Me(t, e || {}, r);
  return W(l) || (n.value = l), l;
}, Lt = (t) => (e, o) => t, Re = (t, e, o) => {
  const n = (r, l) => {
    if (!(!r || l.has(r))) {
      if (l.add(r), r.compChild) {
        const s = r.compChild.indexOf(e);
        s !== -1 && r.compChild.splice(s, 1, o);
      }
      n(r.getParent ? r.getParent() : void 0, l);
    }
  };
  n(t, /* @__PURE__ */ new Set());
}, Te = (t, e, o, n) => {
  if (n.il)
    return;
  const r = R.value;
  r && (r.invalid = !0);
  const l = {
    proofs: /* @__PURE__ */ new WeakMap(),
    ready: !1,
    invalid: !1
  };
  R.value = l;
  try {
    E.value = !0;
    let s;
    try {
      const c = et(t, e, o);
      s = q(c, n);
      const { isRoot: i, getParent: f, we: y, ae: v } = n;
      if (s.getParent = f, !i && f) {
        const u = f(), a = u && u.children || [], p = a.indexOf(n);
        p !== -1 && a.splice(p, 1, s), Re(u, n, s);
      } else
        s.isRoot = !0, s.we = y, s.ae = v;
    } finally {
      E.value = !1;
    }
    l.ready = !0, A(s);
  } finally {
    R.value = r;
  }
}, Me = (t, e, o) => {
  if (wt(t))
    return I(e, ...o);
  if (W(t)) {
    const n = et(t, e, o);
    if (E.value)
      return n;
    const r = tt(n).resolve();
    return r.rs = n, r;
  }
  return C("e", t, e, void 0, o);
}, Nt = (t, e) => {
  const o = () => t.value;
  return e.map((n) => {
    const r = At(n);
    return r.getParent = o, r;
  });
}, At = (t) => {
  if (t == null || typeof t == "boolean")
    return C(null);
  if (Array.isArray(t)) {
    const e = { value: void 0 }, o = Nt(e, t), n = C("l", void 0, void 0, void 0, o);
    return e.value = n, n;
  } else if (typeof t == "string" || typeof t == "number")
    return C("t", void 0, void 0, t);
  return t;
}, Le = (t, e, o) => (n = e) => {
  const r = E.value, l = w.value;
  E.value = !1;
  try {
    Wt(n, t);
    const s = t(e, o);
    let c;
    if (typeof s == "function") {
      const i = s;
      c = jt.has(i) ? i(e, o) : i(xe(n), e, o);
    } else {
      let i = !0;
      c = (f) => i ? (i = !1, s) : t(f, o);
    }
    return Ne(
      c,
      n,
      t,
      e,
      o
    );
  } finally {
    w.value = l, E.value = r;
  }
}, Dt = (t) => t.ctor ? tt(
  t.rs || {
    ctor: t.ctor,
    props: t.compProps,
    children: t.compChild
  }
) : C(
  t.type,
  t.tag,
  t.props,
  t.text,
  t.children && [...t.children],
  t.getParent
), tt = ({
  ctor: t,
  props: e,
  children: o
}) => et(t, { ...e }, [...o || []]), et = (t, e, o) => ({
  ctor: t,
  props: e,
  children: o,
  resolve: Le(t, e, o)
}), Ne = (t, e, o, n, r) => {
  const l = De(t), s = l(n), c = Ae(
    l,
    e,
    o,
    n,
    r
  );
  return Bt(s, e, o, n, r, c), Se(
    e,
    (i) => Te(
      o,
      i.compProps || n,
      i.compChild || r,
      i
    )
  ), s;
}, Ae = (t, e, o, n, r) => {
  const l = () => {
    const s = w.value;
    try {
      Ut(e), Pe();
      const c = t(n);
      return Bt(c, e, o, n, r, l), c;
    } finally {
      w.value = s;
    }
  };
  return l;
}, De = (t) => (e) => {
  const o = At(t(e)), n = I({}, o);
  return o.getParent = () => n, n;
}, Bt = (t, e, o, n, r, l) => {
  t.compProps = n, t.compChild = r, t.ctor = o, t.compKey = e, t.reRender = l;
  const s = m.get(e);
  s && (s.vd.value = t);
}, Be = (t, e) => {
  let o = [], n = null;
  return (r) => {
    const l = t(), s = o.length === l.length && o.every((i, f) => i === l[f]);
    if (o = l, s && n)
      return n;
    const c = e(r);
    return n = c, c;
  };
}, ut = [
  "pretty",
  "large",
  "big",
  "small",
  "tall",
  "short",
  "long",
  "handsome",
  "plain",
  "quaint",
  "clean",
  "elegant",
  "easy",
  "angry",
  "crazy",
  "helpful",
  "mushy",
  "odd",
  "unsightly",
  "adorable",
  "important",
  "inexpensive",
  "cheap",
  "expensive",
  "fancy"
], ht = [
  "red",
  "yellow",
  "blue",
  "green",
  "pink",
  "brown",
  "purple",
  "brown",
  "white",
  "black",
  "orange"
], ft = [
  "table",
  "chair",
  "house",
  "bbq",
  "desk",
  "car",
  "pony",
  "cookie",
  "sandwich",
  "burger",
  "pizza",
  "mouse",
  "keyboard"
], $ = (t) => Math.round(Math.random() * 1e3) % t, Oe = () => `${ut[$(ut.length)]} ${ht[$(ht.length)]} ${ft[$(ft.length)]}`;
let vt = 1;
const g = {
  state: { rows: [], selected: null },
  buildData(t) {
    const e = new Array(t);
    for (let o = 0; o < t; o += 1)
      e[o] = He(vt, Oe()), vt += 1;
    return e;
  },
  run() {
    this.state.rows = this.buildData(1e3);
  },
  runLots() {
    this.state.rows = this.buildData(1e4);
  },
  add() {
    this.state.rows = this.state.rows.concat(this.buildData(1e3));
  },
  update() {
    const { rows: t } = this.state;
    for (let e = 0; e < t.length; e += 10)
      t[e].label += " !!!";
  },
  clear() {
    this.state.rows = [], this.state.selected = null;
  },
  swapRows() {
    const { rows: t } = this.state;
    if (t.length > 998) {
      const e = t[1];
      t[1] = t[998], t[998] = e;
    }
  },
  remove(t) {
    this.state.rows = this.state.rows.filter((e) => e.id !== t);
  },
  select(t) {
    this.state.selected = t;
  }
};
let T = () => {
};
function He(t, e) {
  const o = () => {
    g.select(t), T();
  }, n = () => {
    g.remove(t), T();
  }, r = {
    id: t,
    label: e,
    view: Be(
      () => [r.label, g.state.selected === t],
      () => /* @__PURE__ */ d("tr", { key: t, class: g.state.selected === t ? "danger" : void 0 }, /* @__PURE__ */ d("td", { class: "col-md-1" }, t), /* @__PURE__ */ d("td", { class: "col-md-4" }, /* @__PURE__ */ d("a", { onClick: o }, r.label)), /* @__PURE__ */ d("td", { class: "col-md-1" }, /* @__PURE__ */ d("a", { onClick: n }, /* @__PURE__ */ d("span", { class: "glyphicon glyphicon-remove", "aria-hidden": "true" }))), /* @__PURE__ */ d("td", { class: "col-md-6" }))
    )
  };
  return r;
}
const je = Lt((t) => (T = t, () => /* @__PURE__ */ d(I, null, g.state.rows.map((e) => e.view(e))))), Ke = Lt(() => {
  const t = (o) => () => {
    o(), T();
  }, e = [
    {
      id: "run",
      text: "Create 1,000 rows",
      onClick: t(() => g.run())
    },
    {
      id: "runlots",
      text: "Create 10,000 rows",
      onClick: t(() => g.runLots())
    },
    {
      id: "add",
      text: "Append 1,000 rows",
      onClick: t(() => g.add())
    },
    {
      id: "update",
      text: "Update every 10th row",
      onClick: t(() => g.update())
    },
    { id: "clear", text: "Clear", onClick: t(() => g.clear()) },
    {
      id: "swaprows",
      text: "Swap Rows",
      onClick: t(() => g.swapRows())
    }
  ];
  return () => /* @__PURE__ */ d("div", { class: "container" }, /* @__PURE__ */ d("div", { class: "jumbotron" }, /* @__PURE__ */ d("div", { class: "row" }, /* @__PURE__ */ d("div", { class: "col-md-6" }, /* @__PURE__ */ d("h1", null, 'Lithent-"keyed"')), /* @__PURE__ */ d("div", { class: "col-md-6" }, /* @__PURE__ */ d("div", { class: "row" }, e.map(({ id: o, text: n, onClick: r }) => /* @__PURE__ */ d("div", { key: o, class: "col-sm-6 smallpad" }, /* @__PURE__ */ d(
    "button",
    {
      type: "button",
      class: "btn btn-primary btn-block",
      id: o,
      onClick: r
    },
    n
  ))))))), /* @__PURE__ */ d("table", { class: "table table-hover table-striped test-data" }, /* @__PURE__ */ d("tbody", { id: "tbody" }, /* @__PURE__ */ d(je, null))), /* @__PURE__ */ d("span", { class: "preloadicon glyphicon glyphicon-remove", "aria-hidden": "true" }));
});
let N = oe(/* @__PURE__ */ d(Ke, null), document.getElementById("main"));
const Ue = () => {
  N == null || N(), N = void 0;
}, We = () => {
  g.clear(), T = () => {
  };
};
export {
  Ue as disposeRoot,
  We as releaseAppState
};
//# sourceMappingURL=main.mjs.map
