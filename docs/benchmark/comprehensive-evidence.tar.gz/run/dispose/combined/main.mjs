const Wt = Symbol.for("lithentWDomSymbol"), P = { value: "" }, w = { value: null }, E = { value: !1 }, m = /* @__PURE__ */ new WeakMap(), zt = /* @__PURE__ */ new WeakSet(), It = (t, e) => {
  m.set(t, {
    ctor: e,
    vd: { value: null },
    up: () => {
    },
    upR: [],
    upS: { value: 0 },
    upD: [],
    upCB: [],
    mts: [],
    umts: [],
    wdCB: []
    // WDom creation callback queue
  });
}, wt = () => m.get(w.value), qt = (t) => {
  w.value = t;
}, $t = (t, e) => {
  w.value = t, It(t, e);
}, Ft = (t) => {
  const e = m.get(t);
  e && (e.umts.forEach((o) => o()), e.umts = []);
}, b = (t) => t.getParent && t.getParent(), U = (t) => () => t, ct = Object.keys, bt = (t, e) => Object.prototype.propertyIsEnumerable.call(t, e), Et = (t, e) => {
  if (bt(t, e)) return !0;
  const o = Object.getPrototypeOf(t);
  return !Object.prototype.hasOwnProperty.call(t, e) && !!o && Et(o, e);
}, W = (t) => typeof t == "object" && t !== null, Vt = (t, e) => "ctor" in t ? t.ctor === (e && e.ctor) : t === (e && e.ctor), Gt = (t, e) => e.type === "f" && // A component's node is a one-child fragment too: never update it in
// place as a plain fragment, or the component is never unmounted, nor
// update a plain fragment with one (a hoisted <Comp /> first drawn by a
// redraw), or it is never mounted.
!e.ctor && !t.ctor && !!e.children && e.children.length === (t.children && t.children.length), Jt = (t, e) => e.type === "e" && e.tag === t.tag && !!e.children && e.children.length === (t.children && t.children.length), at = (t, e) => e.type === t.type, Qt = (t, e) => e.type === t.type && (Q(t) && Q(e) || !!e.children && e.children.length === (t.children && t.children.length)), G = (t) => (t && t.compProps && t.compProps.key) ?? (t && t.props && t.props.key), T = (t) => t === "f" || t === "l", z = (t) => typeof t == "function" && !Ct(t) || W(t) && "resolve" in t, Ct = (t) => t === $, Xt = (t) => !t.type, J = (t) => t[0] === "o" && t[1] === "n", _ = (t) => O(G(t)), Q = (t) => !!t && !!t.children && t.children.some(_), O = (t) => t != null, it = (t, e) => t === "style" && W(e), Yt = (t, e) => t === "ref" && W(e), dt = /* @__PURE__ */ new WeakMap(), pt = (t, e) => {
  const o = t.constructor.prototype;
  let n = dt.get(o);
  n || dt.set(o, n = /* @__PURE__ */ new Map());
  let r = n.get(e);
  if (r === void 0) {
    const l = Object.getOwnPropertyDescriptor(o, e);
    r = !!(l && l.get && l.set), n.set(e, r);
  }
  return r;
}, ut = (t) => t.localName.includes("-") && t.constructor === HTMLElement, Zt = (t) => z(t) ? "c" : t.type || "et", _t = {
  c: Vt,
  l: Qt,
  t: at,
  e: Jt,
  f: Gt,
  et: at
}, B = Symbol(), F = Symbol();
function X(t) {
  var e;
  const o = (e = this[B]) == null ? void 0 : e["on" + t.type];
  typeof o == "function" ? o.call(this, t) : o && o.handleEvent(t);
}
const St = (t, e, o) => {
  const n = e.slice(2).toLowerCase(), r = "on" + n, l = t[B];
  l && l[r] === o ? (delete l[r], t.removeEventListener(n, X)) : t.removeEventListener(n, o);
}, ht = (t, e, o, n) => {
  var r;
  if (n === o) return;
  const l = e.slice(2).toLowerCase(), s = "on" + l, c = t[B] || (t[B] = {}), a = c[s];
  (r = c[F]) != null && r.has(s) ? (n && St(t, e, n), o && o !== c[s] && t.addEventListener(l, o)) : o ? a && a !== n && a !== o ? ((c[F] || (c[F] = /* @__PURE__ */ new Set())).add(s), t.addEventListener(l, o)) : (c[s] = o, a || t.addEventListener(l, X)) : a && a === n && (delete c[s], t.removeEventListener(l, X));
}, kt = (t) => {
  const e = wt();
  e && e.umts.push(t);
}, I = (t) => {
  const { compKey: e } = t;
  e && (t.il = !0, te(e)), xt(t);
}, xt = (t) => {
  if (t.tag === "portal" && t.el)
    for (const e in t.props)
      J(e) && St(
        t.el,
        e,
        t.props[e]
      );
  (t.children || []).forEach((e) => {
    e.compKey ? I(e) : xt(e);
  });
}, te = (t) => {
  Ft(t), m.delete(t);
};
let Y = [];
const ee = (t) => {
  t.compKey && Y.push(t);
}, S = () => {
  Y.forEach(oe), Y = [];
}, oe = (t) => {
  const { compKey: e } = t, o = e && m.get(e);
  if (o) {
    const n = o.mts;
    w.value = e, o.upS.value = 0, o.mts = [], n.forEach((r) => {
      const l = r();
      l && kt(l);
    });
  }
}, ne = (t) => {
  const { compKey: e } = t;
  if (e) {
    const o = m.get(e), n = o && o.wdCB;
    w.value = e, n && n.length > 0 && (o.wdCB = [], n.forEach((r) => {
      const l = r();
      typeof l == "function" && kt(l);
    }));
  }
}, re = (t) => {
  const { compKey: e } = t, o = e && m.get(e);
  if (o) {
    const n = o.upCB;
    w.value = e, o.upS.value = 0, t.ctor && (o.upCB = [], n.forEach((r) => r()));
  }
}, R = {}, Pt = () => new DocumentFragment(), Rt = (t, e, o) => o ? t.insertBefore(e, o) : t.tagName === "HTML" ? t.replaceWith(e) : t.appendChild(e), le = (t) => document.createElement(t), se = (t, e, o, n) => {
  t.isRoot = !0, e = e || document.body, t.we = e;
  const r = M(t, n);
  return t.ae = o, Rt(e, r, o), S(), () => {
    const l = m.get(t.compProps), s = l && l.vd.value || t;
    I(s), ce(s);
  };
}, ce = (t) => et(t, t.we), tt = (t) => {
  const e = b(t);
  et(
    t,
    t.isRoot ? t.we : e && k(e)
  );
}, et = (t, e) => {
  if (e && t.el) {
    const o = t.el.nodeType;
    o === 11 || t.tag === "portal" ? Lt(t, e) : (o === 1 || o === 3) && e.removeChild(t.el), t.el = void 0;
  }
}, Lt = (t, e) => {
  const o = t.oc || t.children || [];
  if (o.length > 1 && o.every((n) => {
    const r = n.el && n.el.nodeType;
    return (r === 1 || r === 3) && n.el.tagName !== "HTML" && n.tag !== "portal";
  })) {
    let n = 0;
    for (let r = e.firstChild; r && n <= o.length; r = r.nextSibling)
      n++;
    if (n === o.length) {
      e.textContent = "", o.forEach((r) => r.el = void 0);
      return;
    }
  }
  o.forEach((n) => {
    const r = n.el && n.el.nodeType;
    if (r)
      if (r === 1 || r === 3) {
        const l = n.el;
        l.tagName === "HTML" ? l.innerHTML = "" : l.remove();
      } else r === 11 && Lt(n, e);
  });
}, ae = (t, e) => {
  const o = k(e);
  t.forEach((n) => {
    I(n), et(n, o);
  });
}, Tt = (t) => {
  tt(t), Mt(t);
}, Mt = (t, e) => {
  e = e || M(t);
  const o = b(t);
  if (!o || !o.type) {
    t.isRoot && t.we && t.tag !== "portal" && (Rt(t.we, e, t.ae), S());
    return;
  }
  const n = k(o), r = ot(t, o);
  n && (t.tag !== "portal" && n.insertBefore(e, r || null), S());
}, Nt = (t) => T(t.type) ? (t.children || []).reduce((e, o) => {
  const n = Nt(o);
  return n && e.appendChild(n), e;
}, Pt()) : t.el, ot = (t, e) => {
  const o = e.children || [];
  return j(o.slice(o.indexOf(t) + 1)) || (T(e.type) ? e.isRoot ? e.ae : ot(e, b(e)) : void 0);
}, H = /* @__PURE__ */ new Set(), j = (t) => t.reduce(
  (e, o) => {
    if (e || H.size && H.has(o)) return e;
    const { type: n, el: r } = o;
    if (n && T(n)) {
      const l = j(o.children || []);
      if (l) return l;
    }
    return r && r.nodeType !== 11 ? r : e;
  },
  void 0
), ie = (t) => {
  const e = b(t), o = t.el;
  if (o && (e ? e.type : t.isRoot))
    if (!e || o.nodeType === 11)
      Tt(t);
    else {
      const n = k(e), r = M(t);
      n && t.tag !== "portal" && n.replaceChild(r, o), S();
    }
}, ft = (t) => {
  if (t.type === "t") {
    he(t);
    return;
  }
  let e = !1;
  if (t.type === "l") {
    const o = R.value, n = o && o.proofs.get(t);
    o && o.proofs.delete(t), e = !!(o && o.ready && !o.invalid && n && n === t.children);
  }
  if (t.el) {
    const { op: o, props: n } = t;
    At(n, t.el, o), t.tag === "input" && (t.el.value = String(
      n && n.value || ""
    ));
  }
  de(t, e), re(t);
}, de = (t, e) => {
  const o = t.children || [];
  if (e) {
    o.forEach(A), o.forEach(Z), S();
    return;
  }
  if (t.type !== "l" || !o.some(
    (i) => "ATS".includes(i.nr) || i.oi !== void 0
  )) {
    o.forEach(A);
    return;
  }
  const n = [], r = [], l = [];
  let s = !0;
  o.forEach((i, d) => {
    const h = i.oi, x = i.nr;
    x === "S" ? l.push(i) : x !== "A" && h !== void 0 && (h < r[r.length - 1] && (s = !1), n.push(d), r.push(h));
  });
  let c;
  if (!s) {
    const i = c = [];
    pe(r).forEach((d) => i[n[d]] = !0), n.forEach(
      (d) => i[d] || (i[d] = !1, l.push(o[d]))
    );
  }
  const a = [];
  let f = 0;
  l.forEach((i) => H.add(i));
  try {
    o.forEach((i, d) => {
      const h = i.nr;
      h === "A" || h === "S" ? (h === "S" && tt(i), a[d] = M(i), f++) : A(i);
    });
  } finally {
    l.forEach((i) => H.delete(i));
  }
  const y = k(t), v = t.isRoot ? t.ae : ot(t, b(t));
  let u = o.length;
  for (; u > 0 && a[u - 1] !== void 0; )
    u--;
  for (let i = u; i < o.length; i++) {
    const d = a[i];
    d && y && o[i].tag !== "portal" && y.insertBefore(d, v || null);
  }
  if (c || f > o.length - u) {
    let i = j(o.slice(u)) || v;
    for (let d = u - 1; d >= 0; d--) {
      const h = o[d], x = a[d] !== void 0, Ut = !!c && c[d] === !1;
      if ((x || Ut) && y && h.tag !== "portal") {
        const st = x ? a[d] : Nt(h);
        st && y.insertBefore(st, i || null);
      }
      const lt = j([h]);
      lt && (i = lt);
    }
  }
  o.forEach(Z), S();
}, Z = (t) => {
  t.oi = t.oc = t.op = void 0, t.nr = "N";
}, pe = (t) => {
  const e = [], o = [];
  t.forEach((l, s) => {
    let c = 0, a = e.length;
    if (a && t[e[a - 1]] < l)
      c = a;
    else
      for (; c < a; ) {
        const f = c + a >> 1;
        t[e[f]] < l ? c = f + 1 : a = f;
      }
    o[s] = c ? e[c - 1] : -1, e[c] = s;
  });
  let n = e.length, r = e[n - 1];
  for (; n-- > 0; )
    e[n] = r, r = o[r];
  return e;
}, A = (t) => {
  const { nr: e } = t;
  e && e !== "N" && (ue[e](t), Z(t));
}, ue = {
  A: Mt,
  D: tt,
  R: ie,
  U: ft,
  S: Tt,
  // A keyed item reaches here only as a component redrawing itself: it has
  // not moved, so it is updated in place. Re-inserting its nodes would blur a
  // focused input inside it or reload an iframe. Moves within a list are
  // placed by updateChildren.
  T: ft
}, he = (t) => {
  t.el && (t.el.nodeValue = String(t.text));
}, At = (t, e, o) => {
  const n = o || {};
  for (const r in t) {
    const l = t[r];
    l !== n[r] && (J(r) ? ht(
      e,
      r,
      l,
      n[r]
    ) : r === "key" || r === "portal" && W(l) || (r === "innerHTML" && typeof l == "string" ? e.innerHTML = l : it(r, l) ? ye(
      l,
      it(r, n.style) ? n.style : {},
      e
    ) : Yt(r, l) ? l.value = e : r && (r !== "type" && pt(e, r) ? e[r] = l : (fe(
      r === "className" ? "class" : r,
      e,
      l
    ), ut(e) && !(r in HTMLElement.prototype) && (e[r] = l)))));
  }
  for (const r in n)
    if (!(t && Et(t, r))) {
      if (J(r)) {
        ht(
          e,
          r,
          void 0,
          n[r]
        );
        continue;
      }
      e.removeAttribute(r), ut(e) ? delete e[r] : e.localName.includes("-") && pt(e, r) && (e[r] = void 0);
    }
}, fe = (t, e, o) => P.value && t !== "xmlns" ? e.setAttributeNS(null, t, o) : e.setAttribute(t, o), M = (t, e) => {
  let o;
  const { type: n, tag: r, text: l, props: s, children: c = [] } = t, a = T(n);
  if (ne(t), r === "svg" && (P.value = String(s && s.xmlns)), !e) {
    if (!n || a)
      o = Pt();
    else if (n === "e" && r)
      r === "portal" && s && s.portal ? o = s.portal : o = P.value ? document.createElementNS(P.value, r) : le(r);
    else if (n === "t" && O(l))
      o = document.createTextNode(String(l));
    else
      throw Error("Invalid wDom");
    t.el = o;
  }
  return ve(t, c, o, e), At(s, o, null), ee(t), r === "svg" && (P.value = ""), o;
}, ve = (t, e, o, n) => {
  const r = U(t);
  e.forEach((l, s) => {
    if (l.nr === "N" && !n) {
      const c = jt(l);
      l = e[s] = "resolve" in c ? c.resolve() : c;
    }
    if (l.getParent = r, l.nr = "N", l.type) {
      const c = M(l, n);
      l.tag !== "portal" && !n && o && o.appendChild(c);
    }
  });
}, ye = (t, e, o) => {
  const n = { ...e };
  if (!(o instanceof HTMLElement)) return;
  const r = o.style;
  for (const l in t)
    r[l] = t[l], delete n[l];
  for (const l in n)
    r[l] = "";
}, k = (t) => T(t.type) ? t.isRoot ? t.we : k(b(t)) : t.el, q = (t, e) => (t !== e && t.nr && (t = jt(t)), ge(
  t,
  !!e && _t[Zt(t)](t, e),
  e
)), ge = (t, e, o) => {
  const n = Ce(t, e, o), r = we(
    n,
    e,
    o
  ), l = r === "N";
  return l || (n.children = Se(
    n,
    e,
    o
  )), n.nr = r, me(n, o, r), !l && o && (o.il = !0, o.ctor && (o.children = void 0)), o && o.tag === "portal" && (n.tag = "portal"), n;
}, me = (t, e, o) => {
  o !== "A" && e && (t.el = e.el), (o === "D" || o === "R" || o === "S") && (e && I(e), t.oc = e && e.children), t.op = e && e.props;
}, we = (t, e, o) => {
  if (Xt(t)) return "D";
  if (t === o || e && t.type === "t" && t.text === o.text)
    return "N";
  if (!(o && o.type)) return "A";
  const n = b(o), r = !t.isRoot && n && n.type === "l" && _(t);
  return e ? r ? "T" : "U" : r ? "S" : "R";
}, be = (t, e) => {
  t && e !== t && (e = e || {}, ct(t).forEach(
    (o) => bt(e, o) || delete t[o]
  ), ct(e).forEach((o) => t[o] = e[o]));
}, Ee = (t, e) => {
  const { compProps: o, compChild: n } = t, { props: r, children: l } = e;
  return o && be(o, r), n && l && n !== l && n.splice(0, n.length, ...l), t.reRender && t.reRender();
}, Ce = (t, e, o) => z(t) ? e && o ? Ee(o, t) : (
  // Resolved before (children a component draws again somewhere else):
  // the first instance owns its props, which are also its key, so the
  // new instance is made from a copy.
  (t.rd ? nt(t) : (t.rd = !0, t)).resolve()
) : t, Se = (t, e, o) => e && o ? xe(t, o) : ke(t), ke = (t) => {
  const e = U(t);
  return (t.children || []).map((o) => {
    const n = q(o);
    return n.getParent = e, n;
  });
}, xe = (t, e) => {
  if (t.type === "l" && Q(t))
    return Pe(t, e);
  const o = e.children || [], n = U(t);
  return (t.children || []).map((r, l) => {
    const s = q(r, o[l]);
    return s.getParent = n, s;
  });
}, Pe = (t, e) => {
  const o = e.children || [], n = R.value, r = /* @__PURE__ */ new Map();
  o.forEach((y, v) => {
    const u = G(y);
    O(u) && !r.has(u) && r.set(u, v);
  });
  const l = [], s = U(t), c = t.children || [];
  let a = c.length === o.length;
  const f = c.map((y, v) => {
    const u = G(y), i = O(u) ? r.get(u) : v < o.length && !_(o[v]) ? v : void 0;
    let d;
    i !== void 0 && (r.delete(u), l[i] = !0, d = o[i]);
    const h = q(y, d);
    return d && (h.oi = i), h.getParent = s, a = a && i === v && (h.nr === "N" || h.nr === "U" || h.nr === "T") && h.tag !== "portal", h;
  });
  return ae(
    o.filter((y, v) => !l[v]),
    e
  ), a && n && !n.invalid && n.proofs.set(t, f), f;
}, D = /* @__PURE__ */ new Map();
let K = !1;
const Re = (t, e) => {
  D.set(t, e), K || (K = !0, queueMicrotask(Dt));
}, Le = (t, e) => {
  const o = m.get(t);
  o && (o.up = () => {
    const n = o.vd.value;
    Re(t, () => e(n));
  });
}, Te = (t) => () => {
  const e = m.get(t), o = e && e.up;
  return o ? (o(), !0) : !1;
}, Dt = () => {
  try {
    D.forEach((t, e) => {
      D.delete(e), t();
    });
  } finally {
    K = !!D.size, K && queueMicrotask(Dt);
  }
}, C = (t, e, o, n, r, l) => ({
  type: t,
  nr: void 0,
  tag: e,
  props: o,
  text: n,
  children: r,
  getParent: l,
  el: void 0,
  oi: void 0,
  oc: void 0,
  op: void 0,
  il: void 0,
  [Wt]: !0
}), Me = () => {
  const t = wt(), e = t && t.upR;
  e && e.length && e.forEach((o) => o());
}, $ = (t, ...e) => C("f", void 0, void 0, void 0, e), p = (t, e, ...o) => {
  const n = { value: void 0 }, r = Bt(n, o), l = De(t, e || {}, r);
  return z(l) || (n.value = l), l;
}, Ot = (t) => (e, o) => t, Ne = (t, e, o) => {
  const n = (r, l) => {
    if (!(!r || l.has(r))) {
      if (l.add(r), r.compChild) {
        const s = r.compChild.indexOf(e);
        s !== -1 && r.compChild.splice(s, 1, o);
      }
      n(r.getParent ? r.getParent() : void 0, l);
    }
  };
  n(t, /* @__PURE__ */ new Set());
}, Ae = (t, e, o, n) => {
  if (n.il)
    return;
  const r = R.value;
  r && (r.invalid = !0);
  const l = {
    proofs: /* @__PURE__ */ new WeakMap(),
    ready: !1,
    invalid: !1
  };
  R.value = l;
  try {
    E.value = !0;
    let s;
    try {
      const c = rt(t, e, o);
      s = q(c, n);
      const { isRoot: a, getParent: f, we: y, ae: v } = n;
      if (s.getParent = f, !a && f) {
        const u = f(), i = u && u.children || [], d = i.indexOf(n);
        d !== -1 && i.splice(d, 1, s), Ne(u, n, s);
      } else
        s.isRoot = !0, s.we = y, s.ae = v;
    } finally {
      E.value = !1;
    }
    l.ready = !0, A(s);
  } finally {
    R.value = r;
  }
}, De = (t, e, o) => {
  if (Ct(t))
    return $(e, ...o);
  if (z(t)) {
    const n = rt(t, e, o);
    if (E.value)
      return n;
    const r = nt(n).resolve();
    return r.rs = n, r;
  }
  return C("e", t, e, void 0, o);
}, Bt = (t, e) => {
  const o = () => t.value;
  return e.map((n) => {
    const r = Ht(n);
    return r.getParent = o, r;
  });
}, Ht = (t) => {
  if (t == null || typeof t == "boolean")
    return C(null);
  if (Array.isArray(t)) {
    const e = { value: void 0 }, o = Bt(e, t), n = C("l", void 0, void 0, void 0, o);
    return e.value = n, n;
  } else if (typeof t == "string" || typeof t == "number")
    return C("t", void 0, void 0, t);
  return t;
}, Oe = (t, e, o) => (n = e) => {
  const r = E.value, l = w.value;
  E.value = !1;
  try {
    $t(n, t);
    const s = t(e, o);
    let c;
    if (typeof s == "function") {
      const a = s;
      c = zt.has(a) ? a(e, o) : a(Te(n), e, o);
    } else {
      let a = !0;
      c = (f) => a ? (a = !1, s) : t(f, o);
    }
    return Be(
      c,
      n,
      t,
      e,
      o
    );
  } finally {
    w.value = l, E.value = r;
  }
}, jt = (t) => t.ctor ? nt(
  t.rs || {
    ctor: t.ctor,
    props: t.compProps,
    children: t.compChild
  }
) : C(
  t.type,
  t.tag,
  t.props,
  t.text,
  t.children && [...t.children],
  t.getParent
), nt = ({
  ctor: t,
  props: e,
  children: o
}) => rt(t, { ...e }, [...o || []]), rt = (t, e, o) => ({
  ctor: t,
  props: e,
  children: o,
  resolve: Oe(t, e, o)
}), Be = (t, e, o, n, r) => {
  const l = je(t), s = l(n), c = He(
    l,
    e,
    o,
    n,
    r
  );
  return Kt(s, e, o, n, r, c), Le(
    e,
    (a) => Ae(
      o,
      a.compProps || n,
      a.compChild || r,
      a
    )
  ), s;
}, He = (t, e, o, n, r) => {
  const l = () => {
    const s = w.value;
    try {
      qt(e), Me();
      const c = t(n);
      return Kt(c, e, o, n, r, l), c;
    } finally {
      w.value = s;
    }
  };
  return l;
}, je = (t) => (e) => {
  const o = Ht(t(e)), n = $({}, o);
  return o.getParent = () => n, n;
}, Kt = (t, e, o, n, r, l) => {
  t.compProps = n, t.compChild = r, t.ctor = o, t.compKey = e, t.reRender = l;
  const s = m.get(e);
  s && (s.vd.value = t);
}, Ke = (t, e) => {
  let o = [], n = null;
  return (r) => {
    const l = t(), s = o.length === l.length && o.every((a, f) => a === l[f]);
    if (o = l, s && n)
      return n;
    const c = e(r);
    return n = c, c;
  };
}, vt = [
  "pretty",
  "large",
  "big",
  "small",
  "tall",
  "short",
  "long",
  "handsome",
  "plain",
  "quaint",
  "clean",
  "elegant",
  "easy",
  "angry",
  "crazy",
  "helpful",
  "mushy",
  "odd",
  "unsightly",
  "adorable",
  "important",
  "inexpensive",
  "cheap",
  "expensive",
  "fancy"
], yt = [
  "red",
  "yellow",
  "blue",
  "green",
  "pink",
  "brown",
  "purple",
  "brown",
  "white",
  "black",
  "orange"
], gt = [
  "table",
  "chair",
  "house",
  "bbq",
  "desk",
  "car",
  "pony",
  "cookie",
  "sandwich",
  "burger",
  "pizza",
  "mouse",
  "keyboard"
], V = (t) => Math.round(Math.random() * 1e3) % t, Ue = () => `${vt[V(vt.length)]} ${yt[V(yt.length)]} ${gt[V(gt.length)]}`;
let mt = 1;
const g = {
  state: { rows: [], selected: null },
  buildData(t) {
    const e = new Array(t);
    for (let o = 0; o < t; o += 1)
      e[o] = We(mt, Ue()), mt += 1;
    return e;
  },
  run() {
    this.state.rows = this.buildData(1e3);
  },
  runLots() {
    this.state.rows = this.buildData(1e4);
  },
  add() {
    this.state.rows = this.state.rows.concat(this.buildData(1e3));
  },
  update() {
    const { rows: t } = this.state;
    for (let e = 0; e < t.length; e += 10)
      t[e].label += " !!!";
  },
  clear() {
    this.state.rows = [], this.state.selected = null;
  },
  swapRows() {
    const { rows: t } = this.state;
    if (t.length > 998) {
      const e = t[1];
      t[1] = t[998], t[998] = e;
    }
  },
  remove(t) {
    this.state.rows = this.state.rows.filter((e) => e.id !== t);
  },
  select(t) {
    this.state.selected = t;
  }
};
let L = () => {
};
function We(t, e) {
  const o = () => {
    g.select(t), L();
  }, n = () => {
    g.remove(t), L();
  }, r = {
    id: t,
    label: e,
    view: Ke(
      () => [r.label, g.state.selected === t],
      () => /* @__PURE__ */ p("tr", { key: t, class: g.state.selected === t ? "danger" : void 0 }, /* @__PURE__ */ p("td", { class: "col-md-1" }, t), /* @__PURE__ */ p("td", { class: "col-md-4" }, /* @__PURE__ */ p("a", { onClick: o }, r.label)), /* @__PURE__ */ p("td", { class: "col-md-1" }, /* @__PURE__ */ p("a", { onClick: n }, /* @__PURE__ */ p("span", { class: "glyphicon glyphicon-remove", "aria-hidden": "true" }))), /* @__PURE__ */ p("td", { class: "col-md-6" }))
    )
  };
  return r;
}
const ze = Ot((t) => (L = t, () => /* @__PURE__ */ p($, null, g.state.rows.map((e) => e.view(e))))), Ie = Ot(() => {
  const t = (o) => () => {
    o(), L();
  }, e = [
    {
      id: "run",
      text: "Create 1,000 rows",
      onClick: t(() => g.run())
    },
    {
      id: "runlots",
      text: "Create 10,000 rows",
      onClick: t(() => g.runLots())
    },
    {
      id: "add",
      text: "Append 1,000 rows",
      onClick: t(() => g.add())
    },
    {
      id: "update",
      text: "Update every 10th row",
      onClick: t(() => g.update())
    },
    { id: "clear", text: "Clear", onClick: t(() => g.clear()) },
    {
      id: "swaprows",
      text: "Swap Rows",
      onClick: t(() => g.swapRows())
    }
  ];
  return () => /* @__PURE__ */ p("div", { class: "container" }, /* @__PURE__ */ p("div", { class: "jumbotron" }, /* @__PURE__ */ p("div", { class: "row" }, /* @__PURE__ */ p("div", { class: "col-md-6" }, /* @__PURE__ */ p("h1", null, 'Lithent-"keyed"')), /* @__PURE__ */ p("div", { class: "col-md-6" }, /* @__PURE__ */ p("div", { class: "row" }, e.map(({ id: o, text: n, onClick: r }) => /* @__PURE__ */ p("div", { key: o, class: "col-sm-6 smallpad" }, /* @__PURE__ */ p(
    "button",
    {
      type: "button",
      class: "btn btn-primary btn-block",
      id: o,
      onClick: r
    },
    n
  ))))))), /* @__PURE__ */ p("table", { class: "table table-hover table-striped test-data" }, /* @__PURE__ */ p("tbody", { id: "tbody" }, /* @__PURE__ */ p(ze, null))), /* @__PURE__ */ p("span", { class: "preloadicon glyphicon glyphicon-remove", "aria-hidden": "true" }));
});
let N = se(/* @__PURE__ */ p(Ie, null), document.getElementById("main"));
const qe = () => {
  N == null || N(), N = void 0;
}, $e = () => {
  g.clear(), L = () => {
  };
};
export {
  qe as disposeRoot,
  $e as releaseAppState
};
//# sourceMappingURL=main.mjs.map
