const ue = Symbol.for("lithentWDomSymbol"), M = { value: "" }, y = { value: null }, k = { value: !1 }, p = /* @__PURE__ */ new WeakMap(), ie = /* @__PURE__ */ new WeakSet();
let ae = !1;
const Oe = (e, t) => {
  p.set(e, {
    ctor: t,
    vd: { value: null },
    up: () => {
    },
    upR: [],
    upS: { value: 0 },
    upD: [],
    upCB: [],
    mts: [],
    umts: [],
    wdCB: []
    // WDom creation callback queue
  });
}, Ue = () => y.value, R = () => p.get(y.value), Ft = (e, t) => {
  const n = p.get(e);
  return n ? n[t] : null;
}, Be = (e) => {
  y.value = e;
}, Qe = (e, t) => {
  y.value = e, Oe(e, t);
}, At = (e) => {
  ae = e;
}, Ke = () => ae, fe = (e) => {
  const t = p.get(e);
  t && (t.umts.forEach((n) => n()), t.umts = []);
}, Ot = (e) => {
  fe(e), p.delete(e);
}, C = (e) => e.getParent && e.getParent(), Q = (e) => () => e, D = Object.keys, de = (e, t) => Object.prototype.propertyIsEnumerable.call(e, t), pe = (e, t) => {
  if (de(e, t)) return !0;
  const n = Object.getPrototypeOf(e);
  return !Object.prototype.hasOwnProperty.call(e, t) && !!n && pe(n, t);
}, x = (e) => typeof e == "object" && e !== null, Ut = (e) => x(e) && !Array.isArray(e) && !Object.getOwnPropertySymbols(e).includes(ue), je = (e, t) => "ctor" in e ? e.ctor === (t && t.ctor) : e === (t && t.ctor), _e = (e, t) => t.type === "f" && // A component's node is a one-child fragment too: never update it in
// place as a plain fragment, or the component is never unmounted, nor
// update a plain fragment with one (a hoisted <Comp /> first drawn by a
// redraw), or it is never mounted.
!t.ctor && !e.ctor && !!t.children && t.children.length === (e.children && e.children.length), Ve = (e, t) => t.type === "e" && t.tag === e.tag && !!t.children && t.children.length === (e.children && e.children.length), ee = (e, t) => t.type === e.type, qe = (e, t) => t.type === e.type && (z(e) && z(t) || !!t.children && t.children.length === (e.children && e.children.length)), V = (e) => (e && e.compProps && e.compProps.key) ?? (e && e.props && e.props.key), N = (e) => e === "f" || e === "l", K = (e) => typeof e == "function" && !he(e) || x(e) && "resolve" in e, he = (e) => e === $, ze = (e) => !e.type, q = (e) => e[0] === "o" && e[1] === "n", J = (e) => A(V(e)), z = (e) => !!e && !!e.children && e.children.some(J), A = (e) => e != null, te = (e, t) => e === "style" && x(t), Ge = (e, t) => e === "ref" && x(t), ne = /* @__PURE__ */ new WeakMap(), ce = (e, t) => {
  const n = e.constructor.prototype;
  let c = ne.get(n);
  c || ne.set(n, c = /* @__PURE__ */ new Map());
  let o = c.get(t);
  if (o === void 0) {
    const s = Object.getOwnPropertyDescriptor(n, t);
    o = !!(s && s.get && s.set), c.set(t, o);
  }
  return o;
}, oe = (e) => e.localName.includes("-") && e.constructor === HTMLElement, Ie = (e) => K(e) ? "c" : e.type || "et", Je = {
  c: je,
  l: qe,
  t: ee,
  e: Ve,
  f: _e,
  et: ee
}, S = Symbol();
function L(e) {
  var n;
  const t = (n = this[S]) == null ? void 0 : n["on" + e.type];
  typeof t == "function" ? t.call(this, e) : t && t !== !0 && t.handleEvent(e);
}
const Xe = (e, t, n) => {
  const c = t.slice(2).toLowerCase(), o = "on" + c, s = e[S];
  s && s[o] === n ? (delete s[o], e.removeEventListener(c, L)) : e.removeEventListener(c, n);
}, se = (e, t, n, c) => {
  if (c === n) return;
  const o = t.slice(2).toLowerCase(), s = "on" + o, l = e[S] || (e[S] = {}), r = l[s];
  r === !0 ? (c && e.removeEventListener(o, c), n && e.addEventListener(o, n)) : n ? r && r !== c && r !== n ? (e.removeEventListener(o, L), e.addEventListener(o, r), e.addEventListener(o, n), l[s] = !0) : (l[s] = n, r || e.addEventListener(o, L)) : r && r === c && (delete l[s], e.removeEventListener(o, L));
}, ve = (e) => {
  const t = R();
  t && t.umts.push(e);
}, j = (e) => {
  const { compKey: t } = e;
  t && (e.il = !0, Ye(t)), ye(e);
}, ye = (e) => {
  if (e.tag === "portal" && e.el)
    for (const t in e.props)
      q(t) && Xe(
        e.el,
        t,
        e.props[t]
      );
  (e.children || []).forEach((t) => {
    t.compKey ? j(t) : ye(t);
  });
}, Ye = (e) => {
  fe(e), Ke() || p.delete(e);
};
let G = [];
const Ze = (e) => {
  e.compKey && G.push(e);
}, b = () => {
  G.forEach($e), G = [];
}, Bt = (e) => {
  const t = R();
  t && t.mts.push(e);
}, $e = (e) => {
  const { compKey: t } = e, n = t && p.get(t);
  if (n) {
    const c = n.mts;
    y.value = t, n.upS.value = 0, n.mts = [], c.forEach((o) => {
      const s = o();
      s && ve(s);
    });
  }
}, Qt = (e) => {
  const t = R();
  t && t.wdCB.push(e);
}, He = (e) => {
  const { compKey: t } = e;
  if (t) {
    const n = p.get(t), c = n && n.wdCB;
    y.value = t, c && c.length > 0 && (n.wdCB = [], c.forEach((o) => {
      const s = o();
      typeof s == "function" && ve(s);
    }));
  }
}, re = (e, t = () => []) => {
  const n = R();
  if (!n) return;
  const { upD: c, upS: o } = n, s = c[o.value], l = t();
  if (s && we(s, l)) {
    const r = e();
    r && n.upCB.push(r);
  }
  c[o.value] = l, o.value += 1;
}, me = (e) => {
  const { compKey: t } = e, n = t && p.get(t);
  if (n) {
    const c = n.upCB;
    y.value = t, n.upS.value = 0, e.ctor && (n.upCB = [], c.forEach((o) => o()));
  }
}, we = (e, t) => e.length ? e.some((n, c) => n !== t[c]) : !0, Ce = () => new DocumentFragment(), ke = (e, t, n) => n ? e.insertBefore(t, n) : e.tagName === "HTML" ? e.replaceWith(t) : e.appendChild(t), We = (e) => document.createElement(e), Kt = (e, t, n, c) => {
  e.isRoot = !0, t = t || document.body, e.we = t;
  const o = T(e, c);
  return e.ae = n, (n || !c) && ke(t, o, n), b(), () => {
    const s = p.get(e.compProps), l = s && s.vd.value || e;
    j(l), De(l);
  };
}, De = (e) => Y(e, e.we), X = (e) => {
  const t = C(e);
  Y(
    e,
    e.isRoot ? e.we : t && P(t)
  );
}, Y = (e, t) => {
  if (t && e.el) {
    const n = e.el.nodeType;
    n === 11 || e.tag === "portal" ? Ee(e, t) : (n === 1 || n === 3) && t.removeChild(e.el), e.el = void 0;
  }
}, Ee = (e, t) => {
  const n = e.oc || e.children || [];
  if (n.length > 1 && n.every((c) => {
    const o = c.el && c.el.nodeType;
    return (o === 1 || o === 3) && c.el.tagName !== "HTML" && c.tag !== "portal";
  })) {
    let c = 0;
    for (let o = t.firstChild; o && c <= n.length; o = o.nextSibling)
      c++;
    if (c === n.length) {
      t.textContent = "", n.forEach((o) => o.el = void 0);
      return;
    }
  }
  n.forEach((c) => {
    const o = c.el && c.el.nodeType;
    if (o)
      if (o === 1 || o === 3) {
        const s = c.el;
        s.tagName === "HTML" ? s.innerHTML = "" : s.remove();
      } else o === 11 && Ee(c, t);
  });
}, et = (e, t) => {
  const n = P(t);
  e.forEach((c) => {
    j(c), Y(c, n);
  });
}, Re = (e) => {
  X(e), Pe(e);
}, Pe = (e, t) => {
  t = t || T(e);
  const n = C(e);
  if (!n || !n.type) {
    e.isRoot && e.we && e.tag !== "portal" && (ke(e.we, t, e.ae), b());
    return;
  }
  const c = P(n), o = Z(e, n);
  c && (e.tag !== "portal" && c.insertBefore(t, o || null), b());
}, ge = (e) => N(e.type) ? (e.children || []).reduce((t, n) => {
  const c = ge(n);
  return c && t.appendChild(c), t;
}, Ce()) : e.el, Z = (e, t) => {
  const n = t.children || [];
  return U(n.slice(n.indexOf(e) + 1)) || (N(t.type) ? t.isRoot ? t.ae : Z(t, C(t)) : void 0);
}, O = /* @__PURE__ */ new Set(), U = (e) => e.reduce(
  (t, n) => {
    if (t || O.size && O.has(n)) return t;
    const { type: c, el: o } = n;
    if (c && N(c)) {
      const s = U(n.children || []);
      if (s) return s;
    }
    return o && o.nodeType !== 11 ? o : t;
  },
  void 0
), tt = (e) => {
  const t = C(e), n = e.el;
  if (n && (t ? t.type : e.isRoot))
    if (!t || n.nodeType === 11)
      Re(e);
    else {
      const c = P(t), o = T(e);
      c && e.tag !== "portal" && c.replaceChild(o, n), b();
    }
}, le = (e) => {
  if (e.type === "t") {
    st(e);
    return;
  }
  if (e.el) {
    const { op: t, props: n } = e;
    Se(n, e.el, t), e.tag === "input" && (e.el.value = String(
      n && n.value || ""
    ));
  }
  nt(e), me(e);
}, nt = (e) => {
  const t = e.children || [];
  if (e.type !== "l" || !t.some(
    (u) => "ATS".includes(u.nr) || u.oi !== void 0
  )) {
    t.forEach(I);
    return;
  }
  const n = [], c = [], o = [];
  let s = !0;
  t.forEach((u, f) => {
    const v = u.oi, g = u.nr;
    g === "S" ? o.push(u) : g !== "A" && v !== void 0 && (v < c[c.length - 1] && (s = !1), n.push(f), c.push(v));
  });
  let l;
  if (!s) {
    const u = l = [];
    ct(c).forEach((f) => u[n[f]] = !0), n.forEach(
      (f) => u[f] || (u[f] = !1, o.push(t[f]))
    );
  }
  const r = [];
  let i = 0;
  o.forEach((u) => O.add(u));
  try {
    t.forEach((u, f) => {
      const v = u.nr;
      v === "A" || v === "S" ? (v === "S" && X(u), r[f] = T(u), i++) : I(u);
    });
  } finally {
    o.forEach((u) => O.delete(u));
  }
  const a = P(e), h = e.isRoot ? e.ae : Z(e, C(e));
  let d = t.length;
  for (; d > 0 && r[d - 1] !== void 0; )
    d--;
  for (let u = d; u < t.length; u++) {
    const f = r[u];
    f && a && t[u].tag !== "portal" && a.insertBefore(f, h || null);
  }
  if (l || i > t.length - d) {
    let u = U(t.slice(d)) || h;
    for (let f = d - 1; f >= 0; f--) {
      const v = t[f], g = r[f] !== void 0, Ae = !!l && l[f] === !1;
      if ((g || Ae) && a && v.tag !== "portal") {
        const W = g ? r[f] : ge(v);
        W && a.insertBefore(W, u || null);
      }
      const w = U([v]);
      w && (u = w);
    }
  }
  t.forEach(Me), b();
}, Me = (e) => {
  e.oi = e.oc = e.op = void 0, e.nr = "N";
}, ct = (e) => {
  const t = [], n = [];
  e.forEach((s, l) => {
    let r = 0, i = t.length;
    if (i && e[t[i - 1]] < s)
      r = i;
    else
      for (; r < i; ) {
        const a = r + i >> 1;
        e[t[a]] < s ? r = a + 1 : i = a;
      }
    n[l] = r ? t[r - 1] : -1, t[r] = l;
  });
  let c = t.length, o = t[c - 1];
  for (; c-- > 0; )
    t[c] = o, o = n[o];
  return t;
}, I = (e) => {
  const { nr: t } = e;
  t && t !== "N" && (ot[t](e), Me(e));
}, ot = {
  A: Pe,
  D: X,
  R: tt,
  U: le,
  S: Re,
  // A keyed item reaches here only as a component redrawing itself: it has
  // not moved, so it is updated in place. Re-inserting its nodes would blur a
  // focused input inside it or reload an iframe. Moves within a list are
  // placed by updateChildren.
  T: le
}, st = (e) => {
  e.el && (e.el.nodeValue = String(e.text));
}, Se = (e, t, n) => {
  const c = n || {};
  for (const o in e) {
    const s = e[o];
    s !== c[o] && (q(o) ? se(
      t,
      o,
      s,
      c[o]
    ) : o === "key" || o === "portal" && x(s) || (o === "innerHTML" && typeof s == "string" ? t.innerHTML = s : te(o, s) ? ut(
      s,
      te(o, c.style) ? c.style : {},
      t
    ) : Ge(o, s) ? s.value = t : o && (o !== "type" && ce(t, o) ? t[o] = s : (rt(
      o === "className" ? "class" : o,
      t,
      s
    ), oe(t) && !(o in HTMLElement.prototype) && (t[o] = s)))));
  }
  for (const o in c)
    if (!(e && pe(e, o))) {
      if (q(o)) {
        se(
          t,
          o,
          void 0,
          c[o]
        );
        continue;
      }
      t.removeAttribute(o), oe(t) ? delete t[o] : t.localName.includes("-") && ce(t, o) && (t[o] = void 0);
    }
}, rt = (e, t, n) => M.value && e !== "xmlns" ? t.setAttributeNS(null, e, n) : t.setAttribute(e, n), T = (e, t) => {
  let n;
  const { type: c, tag: o, text: s, props: l, children: r = [] } = e, i = N(c);
  if (He(e), o === "svg" && (M.value = String(l && l.xmlns)), t)
    n = e.el;
  else {
    if (!c || i)
      n = Ce();
    else if (c === "e" && o)
      o === "portal" && l && l.portal ? n = l.portal : n = M.value ? document.createElementNS(M.value, o) : We(o);
    else if (c === "t" && A(s))
      n = document.createTextNode(String(s));
    else
      throw Error("Invalid wDom");
    e.el = n;
  }
  return lt(e, r, n, t), Se(l, n, null), Ze(e), o === "svg" && (M.value = ""), n;
}, lt = (e, t, n, c) => {
  const o = Q(e);
  t.forEach((s, l) => {
    if (s.nr === "N" && !c) {
      const r = Le(s);
      s = t[l] = "resolve" in r ? r.resolve() : r;
    }
    if (s.getParent = o, s.nr = "N", s.type) {
      const r = T(s, c);
      s.tag !== "portal" && !c && n && n.appendChild(r);
    }
  });
}, ut = (e, t, n) => {
  const c = { ...t };
  if (!(n instanceof HTMLElement)) return;
  const o = n.style;
  for (const s in e)
    o[s] = e[s], delete c[s];
  for (const s in c)
    o[s] = "";
}, P = (e) => N(e.type) ? e.isRoot ? e.we : P(C(e)) : e.el, _ = (e, t) => (e !== t && e.nr && (e = Le(e)), it(
  e,
  !!t && Je[Ie(e)](e, t),
  t
)), it = (e, t, n) => {
  const c = ht(e, t, n), o = ft(
    c,
    t,
    n
  ), s = o === "N";
  return s || (c.children = vt(
    c,
    t,
    n
  )), c.nr = o, at(c, n, o), !s && n && (n.il = !0, n.ctor && (n.children = void 0)), n && n.tag === "portal" && (c.tag = "portal"), c;
}, at = (e, t, n) => {
  n !== "A" && t && (e.el = t.el), (n === "D" || n === "R" || n === "S") && (t && j(t), e.oc = t && t.children), e.op = t && t.props;
}, ft = (e, t, n) => {
  if (ze(e)) return "D";
  if (e === n || t && e.type === "t" && e.text === n.text)
    return "N";
  if (!(n && n.type)) return "A";
  const c = C(n), o = !e.isRoot && c && c.type === "l" && J(e);
  return t ? o ? "T" : "U" : o ? "S" : "R";
}, dt = (e, t) => {
  e && t !== e && (t = t || {}, D(e).forEach(
    (n) => de(t, n) || delete e[n]
  ), D(t).forEach((n) => e[n] = t[n]));
}, pt = (e, t) => {
  const { compProps: n, compChild: c } = e, { props: o, children: s } = t;
  return n && dt(n, o), c && s && c !== s && c.splice(0, c.length, ...s), e.reRender && e.reRender();
}, ht = (e, t, n) => K(e) ? t && n ? pt(n, e) : (
  // Resolved before (children a component draws again somewhere else):
  // the first instance owns its props, which are also its key, so the
  // new instance is made from a copy.
  (e.rd ? H(e) : (e.rd = !0, e)).resolve()
) : e, vt = (e, t, n) => t && n ? Ct(e, n) : yt(e), yt = (e) => {
  const t = Q(e);
  return (e.children || []).map((n) => {
    const c = _(n);
    return c.getParent = t, c;
  });
}, Ct = (e, t) => {
  if (e.type === "l" && z(e))
    return kt(e, t);
  const n = t.children || [], c = Q(e);
  return (e.children || []).map((o, s) => {
    const l = _(o, n[s]);
    return l.getParent = c, l;
  });
}, kt = (e, t) => {
  const n = t.children || [], c = /* @__PURE__ */ new Map();
  n.forEach((r, i) => {
    const a = V(r);
    A(a) && !c.has(a) && c.set(a, i);
  });
  const o = [], s = Q(e), l = (e.children || []).map((r, i) => {
    const a = V(r), h = A(a) ? c.get(a) : i < n.length && !J(n[i]) ? i : void 0;
    let d;
    h !== void 0 && (c.delete(a), o[h] = !0, d = n[h]);
    const u = _(r, d);
    return d && (u.oi = h), u.getParent = s, u;
  });
  return et(
    n.filter((r, i) => !o[i]),
    t
  ), l;
}, F = /* @__PURE__ */ new Map();
let B = !1;
const Et = (e, t) => {
  F.set(e, t), B || (B = !0, queueMicrotask(xe));
}, Rt = (e, t) => {
  const n = p.get(e);
  n && (n.up = () => {
    const c = n.vd.value;
    Et(e, () => t(c));
  });
}, be = (e) => () => {
  const t = p.get(e), n = t && t.up;
  return n ? (n(), !0) : !1;
}, xe = () => {
  try {
    F.forEach((e, t) => {
      F.delete(t), e();
    });
  } finally {
    B = !!F.size, B && queueMicrotask(xe);
  }
}, E = (e, t, n, c, o, s) => ({
  type: e,
  nr: void 0,
  tag: t,
  props: n,
  text: c,
  children: o,
  getParent: s,
  el: void 0,
  oi: void 0,
  oc: void 0,
  op: void 0,
  il: void 0,
  [ue]: !0
}), jt = (e, t = () => []) => {
  const n = R();
  n && (n.upR.push(() => re(e, t)), re(e, t));
}, Pt = () => {
  const e = R(), t = e && e.upR;
  t && t.length && t.forEach((n) => n());
}, $ = (e, ...t) => E("f", void 0, void 0, void 0, t), gt = (e, t, ...n) => {
  const c = { value: void 0 }, o = Ne(c, n), s = bt(e, t || {}, o);
  return K(s) || (c.value = s), s;
}, _t = (e, t) => gt("portal", { portal: t }, e), Vt = (e) => (t, n) => e, qt = (e) => (t, n) => (ie.add(e), e), Mt = (e, t, n) => {
  const c = (o, s) => {
    if (!(!o || s.has(o))) {
      if (s.add(o), o.compChild) {
        const l = o.compChild.indexOf(t);
        l !== -1 && o.compChild.splice(l, 1, n);
      }
      c(o.getParent ? o.getParent() : void 0, s);
    }
  };
  c(e, /* @__PURE__ */ new Set());
}, St = (e, t, n, c) => {
  if (c.il)
    return;
  k.value = !0;
  let o;
  try {
    const s = m(e, t, n);
    o = _(s, c);
    const { isRoot: l, getParent: r, we: i, ae: a } = c;
    if (o.getParent = r, !l && r) {
      const h = r(), d = h && h.children || [], u = d.indexOf(c);
      u !== -1 && d.splice(u, 1, o), Mt(h, c, o);
    } else
      o.isRoot = !0, o.we = i, o.ae = a;
  } finally {
    k.value = !1;
  }
  I(o);
}, bt = (e, t, n) => {
  if (he(e))
    return $(t, ...n);
  if (K(e)) {
    const c = m(e, t, n);
    if (k.value)
      return c;
    const o = H(c).resolve();
    return o.rs = c, o;
  }
  return E("e", e, t, void 0, n);
}, Ne = (e, t) => {
  const n = () => e.value;
  return t.map((c) => {
    const o = Te(c);
    return o.getParent = n, o;
  });
}, Te = (e) => {
  if (e == null || typeof e == "boolean")
    return E(null);
  if (Array.isArray(e)) {
    const t = { value: void 0 }, n = Ne(t, e), c = E("l", void 0, void 0, void 0, n);
    return t.value = c, c;
  } else if (typeof e == "string" || typeof e == "number")
    return E("t", void 0, void 0, e);
  return e;
}, xt = (e, t, n) => (c = t) => {
  const o = k.value, s = y.value;
  k.value = !1;
  try {
    Qe(c, e);
    const l = e(t, n);
    let r;
    if (typeof l == "function") {
      const i = l;
      r = ie.has(i) ? i(t, n) : i(be(c), t, n);
    } else {
      let i = !0;
      r = (a) => i ? (i = !1, l) : e(a, n);
    }
    return Nt(
      r,
      c,
      e,
      t,
      n
    );
  } finally {
    y.value = s, k.value = o;
  }
}, Le = (e) => e.ctor ? H(
  e.rs || {
    ctor: e.ctor,
    props: e.compProps,
    children: e.compChild
  }
) : E(
  e.type,
  e.tag,
  e.props,
  e.text,
  e.children && [...e.children],
  e.getParent
), H = ({
  ctor: e,
  props: t,
  children: n
}) => m(e, { ...t }, [...n || []]), m = (e, t, n) => ({
  ctor: e,
  props: t,
  children: n,
  resolve: xt(e, t, n)
}), Nt = (e, t, n, c, o) => {
  const s = Lt(e), l = s(c), r = Tt(
    s,
    t,
    n,
    c,
    o
  );
  return Fe(l, t, n, c, o, r), Rt(
    t,
    (i) => St(
      n,
      i.compProps || c,
      i.compChild || o,
      i
    )
  ), l;
}, Tt = (e, t, n, c, o) => {
  const s = () => {
    const l = y.value;
    try {
      Be(t), Pt();
      const r = e(c);
      return Fe(r, t, n, c, o, s), r;
    } finally {
      y.value = l;
    }
  };
  return s;
}, Lt = (e) => (t) => {
  const n = Te(e(t)), c = $({}, n);
  return n.getParent = () => c, c;
}, Fe = (e, t, n, c, o, s) => {
  e.compProps = c, e.compChild = o, e.ctor = n, e.compKey = t, e.reRender = s;
  const l = p.get(t);
  l && (l.vd.value = e);
}, zt = (e) => ({ value: e }), Gt = () => Promise.resolve(), It = () => {
  const e = Ue();
  return e ? be(e) : () => !1;
};
export {
  $ as Fragment,
  p as componentMap,
  be as componentUpdate,
  Ot as disposeComponentEntry,
  Ue as getComponentKey,
  Ft as getComponentSubInfo,
  gt as h,
  Ut as isPropType,
  qt as lmount,
  ie as lmountComponentSet,
  Vt as mount,
  Bt as mountCallback,
  Qt as mountReadyCallback,
  Gt as nextTick,
  _t as portal,
  zt as ref,
  Kt as render,
  St as replaceWDom,
  At as setComponentMapManualMode,
  jt as updateCallback,
  It as useRenew
};
//# sourceMappingURL=lithent.mjs.map
