declare const eventHandlers: unique symbol;
type Handler = EventListenerOrEventListenerObject;
type EventElement = HTMLElement & {
    [eventHandlers]?: Record<string, Handler | true | undefined>;
};
export declare const removeEvent: (element: EventElement, eventKey: string, handler: Handler) => void;
export declare const updateEvent: (element: EventElement, eventKey: string, newHandler: Handler | undefined, oldHandler?: Handler) => void;
export {};
