const wdomSymbol = Symbol.for("lithentWDomSymbol");
const xmlnsRef = { value: "" };
const compKeyRef = { value: null };
const needDiffRef = { value: false };
const componentMap = /* @__PURE__ */ new WeakMap();
const lmountComponentSet = /* @__PURE__ */ new WeakSet();
const setComponetRef = (compKey, ctor) => {
  componentMap.set(compKey, {
    ctor,
    vd: { value: null },
    up: () => {
    },
    upR: [],
    upS: { value: 0 },
    upD: [],
    upCB: [],
    mts: [],
    umts: [],
    wdCB: []
    // WDom creation callback queue
  });
};
const getCurrentComponent = () => componentMap.get(compKeyRef.value);
const initUpdateHookState = (compKey) => {
  compKeyRef.value = compKey;
};
const initMountHookState = (compKey, ctor) => {
  compKeyRef.value = compKey;
  setComponetRef(compKey, ctor);
};
const runUnmountEffects = (compKey) => {
  const subInfo = componentMap.get(compKey);
  if (subInfo) {
    subInfo.umts.forEach((effect) => effect());
    subInfo.umts = [];
  }
};
const getParent = (vDom) => vDom.getParent && vDom.getParent();
const makeParentGetter = (parent) => () => parent;
const keys = Object.keys;
const isEnumerableProp = (props, key) => Object.prototype.propertyIsEnumerable.call(props, key);
const hasEnumerableProp = (props, key) => {
  if (isEnumerableProp(props, key)) return true;
  const prototype = Object.getPrototypeOf(props);
  return !Object.prototype.hasOwnProperty.call(props, key) && !!prototype && hasEnumerableProp(prototype, key);
};
const isObject = (target) => typeof target === "object" && target !== null;
const checkSameCustomComponent = (newWDom, originalWDom) => "ctor" in newWDom ? newWDom.ctor === (originalWDom && originalWDom.ctor) : newWDom === (originalWDom && originalWDom.ctor);
const checkSameFragment = (newWDom, originalWDom) => originalWDom.type === "f" && // A component's node is a one-child fragment too: never update it in
// place as a plain fragment, or the component is never unmounted, nor
// update a plain fragment with one (a hoisted <Comp /> first drawn by a
// redraw), or it is never mounted.
!originalWDom.ctor && !newWDom.ctor && !!originalWDom.children && originalWDom.children.length === (newWDom.children && newWDom.children.length);
const checkSameTagElement = (newWDom, originalWDom) => originalWDom.type === "e" && originalWDom.tag === newWDom.tag && !!originalWDom.children && originalWDom.children.length === (newWDom.children && newWDom.children.length);
const checkNormalTypeElement = (newWDom, originalWDom) => originalWDom.type === newWDom.type;
const checkLoopTypeElement = (newWDom, originalWDom) => originalWDom.type === newWDom.type && (checkKeyedChildren(newWDom) && checkKeyedChildren(originalWDom) || !!originalWDom.children && originalWDom.children.length === (newWDom.children && newWDom.children.length));
const getKey = (target) => (target && target.compProps && target.compProps.key) ?? (target && target.props && target.props.key);
const checkVirtualType = (type) => type === "f" || type === "l";
const checkCustemComponentFunction = (target) => typeof target === "function" && !checkFragmentFunction(target) || isObject(target) && "resolve" in target;
const checkFragmentFunction = (target) => target === Fragment;
const checkEmptyElement = (wDom) => !wDom.type;
const checkEventKey = (key) => key[0] === "o" && key[1] === "n";
const checkExistyKey = (target) => checkExisty(getKey(target));
const checkKeyedChildren = (target) => !!target && !!target.children && target.children.some(checkExistyKey);
const checkExisty = (value) => value !== null && value !== void 0;
const checkStyleData = (dataKey, dataValue) => dataKey === "style" && isObject(dataValue);
const checkRefData = (dataKey, dataValue) => dataKey === "ref" && isObject(dataValue);
const accessorCache = /* @__PURE__ */ new WeakMap();
const hasAccessorMethods = (target, dataKey) => {
  const proto = target.constructor.prototype;
  let byKey = accessorCache.get(proto);
  if (!byKey) accessorCache.set(proto, byKey = /* @__PURE__ */ new Map());
  let result = byKey.get(dataKey);
  if (result === void 0) {
    const descriptor = Object.getOwnPropertyDescriptor(proto, dataKey);
    result = !!(descriptor && descriptor.get && descriptor.set);
    byKey.set(dataKey, result);
  }
  return result;
};
const isPendingCustomElement = (target) => target.localName.includes("-") && target.constructor === HTMLElement;
const getWDomType = (wDom) => checkCustemComponentFunction(wDom) ? "c" : wDom.type || "et";
const checkSameWDomWithOriginal = {
  c: checkSameCustomComponent,
  l: checkLoopTypeElement,
  t: checkNormalTypeElement,
  e: checkSameTagElement,
  f: checkSameFragment,
  et: checkNormalTypeElement
};
const unmount = (effectAction) => {
  const comp = getCurrentComponent();
  comp && comp.umts.push(effectAction);
};
const runUnmountQueueFromWDom = (newWDom) => {
  const { compKey } = newWDom;
  if (compKey) {
    newWDom.il = true;
    removeItem(compKey);
  }
  recursiveRunUnmount(newWDom);
};
const recursiveRunUnmount = (wDom) => {
  if (wDom.tag === "portal" && wDom.el) {
    for (const key in wDom.props) {
      if (checkEventKey(key)) {
        wDom.el.removeEventListener(
          key.slice(2).toLowerCase(),
          wDom.props[key]
        );
      }
    }
  }
  (wDom.children || []).forEach((item) => {
    const childComKey = item.compKey;
    if (childComKey) {
      runUnmountQueueFromWDom(item);
    } else {
      recursiveRunUnmount(item);
    }
  });
};
const removeItem = (compKey) => {
  runUnmountEffects(compKey);
  {
    componentMap.delete(compKey);
  }
};
let mountedQueue = [];
const addMountedQueue = (wDom) => {
  if (wDom.compKey) {
    mountedQueue.push(wDom);
  }
};
const execMountedQueue = () => {
  mountedQueue.forEach(runMountedQueueFromWDom);
  mountedQueue = [];
};
const runMountedQueueFromWDom = (newWDom) => {
  const { compKey } = newWDom;
  const component = compKey && componentMap.get(compKey);
  if (component) {
    const mountQueue = component.mts;
    compKeyRef.value = compKey;
    component.upS.value = 0;
    component.mts = [];
    mountQueue.forEach((effect) => {
      const callback = effect();
      if (callback) {
        unmount(callback);
      }
    });
  }
};
const runWDomCallbacksFromWDom = (newWDom) => {
  const { compKey } = newWDom;
  if (compKey) {
    const component = componentMap.get(compKey);
    const wdCBQueue = component && component.wdCB;
    compKeyRef.value = compKey;
    if (wdCBQueue && wdCBQueue.length > 0) {
      component.wdCB = [];
      wdCBQueue.forEach((effect) => {
        const cleanup = effect();
        if (typeof cleanup === "function") {
          unmount(cleanup);
        }
      });
    }
  }
};
const runUpdatedQueueFromWDom = (newWDom) => {
  const { compKey } = newWDom;
  const component = compKey && componentMap.get(compKey);
  if (component) {
    const queue = component.upCB;
    compKeyRef.value = compKey;
    component.upS.value = 0;
    if (newWDom.ctor) {
      component.upCB = [];
      queue.forEach((effect) => effect());
    }
  }
};
const childOrderRef = {};
function __hit$2(key, n = 1) {
  const c = globalThis.__c2Counts;
  if (c) c[key] = (c[key] || 0) + n;
}
const DF = () => new DocumentFragment();
const insertRoot = (wrapElement, element, afterElement) => afterElement ? wrapElement.insertBefore(element, afterElement) : wrapElement.tagName === "HTML" ? wrapElement.replaceWith(element) : wrapElement.appendChild(element);
const CE = (t) => document.createElement(t);
const render = (wDom, wrapElement, afterElement, isHydration) => {
  wDom.isRoot = true;
  wrapElement = wrapElement || document.body;
  wDom.we = wrapElement;
  const Dom = wDomToDom(wDom, isHydration);
  wDom.ae = afterElement;
  {
    insertRoot(wrapElement, Dom, afterElement);
  }
  execMountedQueue();
  return () => {
    const compData = componentMap.get(wDom.compProps);
    const comp = compData && compData.vd.value || wDom;
    runUnmountQueueFromWDom(comp);
    rootDelete(comp);
  };
};
const rootDelete = (newWDom) => deleteRealDom(newWDom, newWDom.we);
const typeDelete = (newWDom) => {
  const parentWDom = getParent(newWDom);
  deleteRealDom(
    newWDom,
    newWDom.isRoot ? newWDom.we : parentWDom && findRealParentElement(parentWDom)
  );
};
const deleteRealDom = (newWDom, parent) => {
  if (parent && newWDom.el) {
    const nt = newWDom.el.nodeType;
    if (nt === 11 || newWDom.tag === "portal") {
      findChildWithRemoveElement(newWDom, parent);
    } else if (nt === 1 || nt === 3) {
      parent.removeChild(newWDom.el);
    }
    newWDom.el = void 0;
  }
};
const findChildWithRemoveElement = (newWDom, parent) => {
  const items = newWDom.oc || newWDom.children || [];
  if (items.length > 1 && items.every((item) => {
    const nt = item.el && item.el.nodeType;
    return (nt === 1 || nt === 3) && item.el.tagName !== "HTML" && item.tag !== "portal";
  })) {
    let count = 0;
    for (let node = parent.firstChild; node && count <= items.length; node = node.nextSibling) {
      count++;
    }
    if (count === items.length) {
      parent.textContent = "";
      items.forEach((item) => item.el = void 0);
      return;
    }
  }
  items.forEach((item) => {
    const nt = item.el && item.el.nodeType;
    if (nt) {
      if (nt === 1 || nt === 3) {
        const el = item.el;
        el.tagName === "HTML" ? el.innerHTML = "" : el.remove();
      } else if (nt === 11) {
        findChildWithRemoveElement(item, parent);
      }
    }
  });
};
const typeDeleteUnused = (items, list) => {
  const parentElement = findRealParentElement(list);
  items.forEach((item) => {
    runUnmountQueueFromWDom(item);
    deleteRealDom(item, parentElement);
  });
};
const typeSortedReplace = (newWDom) => {
  typeDelete(newWDom);
  typeAdd(newWDom);
};
const typeAdd = (newWDom, newElement) => {
  newElement = newElement || wDomToDom(newWDom);
  const parentWDom = getParent(newWDom);
  if (!parentWDom || !parentWDom.type) {
    if (newWDom.isRoot && newWDom.we && newWDom.tag !== "portal") {
      insertRoot(newWDom.we, newElement, newWDom.ae);
      execMountedQueue();
    }
    return;
  }
  const parentEl = findRealParentElement(parentWDom);
  const nextEl = startFindNextBrotherElement(newWDom, parentWDom);
  if (parentEl) {
    if (newWDom.tag !== "portal") {
      parentEl.insertBefore(newElement, nextEl || null);
    }
    execMountedQueue();
  }
};
const getElementFromFragment = (newWDom) => {
  if (checkVirtualType(newWDom.type)) {
    return (newWDom.children || []).reduce((acc, item) => {
      const element = getElementFromFragment(item);
      if (element) {
        acc.appendChild(element);
      }
      return acc;
    }, DF());
  }
  return newWDom.el;
};
const startFindNextBrotherElement = (wDom, parentWDom) => {
  const brothers = parentWDom.children || [];
  return findChildFragmentNextElement(brothers.slice(brothers.indexOf(wDom) + 1)) || (checkVirtualType(parentWDom.type) ? parentWDom.isRoot ? parentWDom.ae : startFindNextBrotherElement(parentWDom, getParent(parentWDom)) : void 0);
};
const moving = /* @__PURE__ */ new Set();
const findChildFragmentNextElement = (candidiateBrothers) => candidiateBrothers.reduce(
  (targetEl, bItem) => {
    if (targetEl || moving.size && moving.has(bItem)) return targetEl;
    const { type, el } = bItem;
    if (type && checkVirtualType(type)) {
      const found = findChildFragmentNextElement(bItem.children || []);
      if (found) return found;
    }
    if (el && el.nodeType !== 11) return el;
    return targetEl;
  },
  void 0
);
const typeReplace = (newWDom) => {
  const parentWDom = getParent(newWDom);
  const orignalElement = newWDom.el;
  if (orignalElement && (parentWDom ? parentWDom.type : newWDom.isRoot)) {
    if (!parentWDom || orignalElement.nodeType === 11) {
      typeSortedReplace(newWDom);
    } else {
      const parentElement = findRealParentElement(parentWDom);
      const newElement = wDomToDom(newWDom);
      if (parentElement && newWDom.tag !== "portal") {
        parentElement.replaceChild(newElement, orignalElement);
      }
      execMountedQueue();
    }
  }
};
const typeUpdate = (newWDom) => {
  if (newWDom.type === "t") {
    updateText(newWDom);
    return;
  }
  let sameOrder = false;
  if (newWDom.type === "l") {
    const frame = childOrderRef.value;
    if (frame) __hit$2("proofReads");
    const children = frame && frame.proofs.get(newWDom);
    if (frame) {
      __hit$2("proofDeletes");
      frame.proofs.delete(newWDom);
    }
    sameOrder = !!(frame && frame.ready && !frame.invalid && children && children === newWDom.children);
  }
  if (newWDom.el) {
    const { op: oldProps, props } = newWDom;
    updateProps(props, newWDom.el, oldProps);
    if (newWDom.tag === "input") {
      newWDom.el.value = String(
        props && props.value || ""
      );
    }
  }
  updateChildren(newWDom, sameOrder);
  runUpdatedQueueFromWDom(newWDom);
};
const updateChildren = (newWDom, sameOrder) => {
  __hit$2("updateChildren");
  const children = newWDom.children || [];
  if (sameOrder) {
    __hit$2("fastLoops");
    __hit$2("fastChildren", children.length);
    children.forEach(wDomUpdate);
    children.forEach(clearDiffMeta);
    execMountedQueue();
    return;
  }
  if (newWDom.type !== "l" || !children.some(
    (item) => (__hit$2("placementProbeVisits"), "ATS".includes(item.nr) || item.oi !== void 0)
  )) {
    children.forEach(wDomUpdate);
    return;
  }
  __hit$2("matchedArrays");
  const matchedIndexes = [];
  __hit$2("oiArrays");
  const oiSeq = [];
  __hit$2("moverArrays");
  const movers = [];
  let ordered = true;
  children.forEach((item, index) => {
    __hit$2("matchAnalysisVisits");
    const oi = item.oi;
    const nr = item.nr;
    if (nr === "S") {
      movers.push(item);
    } else if (nr !== "A" && oi !== void 0) {
      if (oi < oiSeq[oiSeq.length - 1]) {
        ordered = false;
      }
      matchedIndexes.push(index);
      oiSeq.push(oi);
    }
  });
  let keep;
  if (!ordered) {
    const lis = keep = [];
    getLisPositions(oiSeq).forEach((pos) => lis[matchedIndexes[pos]] = true);
    matchedIndexes.forEach(
      (i) => lis[i] || (lis[i] = false, movers.push(children[i]))
    );
  }
  const created = [];
  __hit$2("createdArrays");
  let createdCount = 0;
  movers.forEach((item) => moving.add(item));
  try {
    children.forEach((item, index) => {
      const nr = item.nr;
      if (nr === "A" || nr === "S") {
        if (nr === "S") {
          typeDelete(item);
        }
        created[index] = wDomToDom(item);
        createdCount++;
      } else {
        wDomUpdate(item);
      }
    });
  } finally {
    movers.forEach((item) => moving.delete(item));
  }
  const parentEl = findRealParentElement(newWDom);
  const baseAnchor = newWDom.isRoot ? newWDom.ae : startFindNextBrotherElement(newWDom, getParent(newWDom));
  let tail = children.length;
  while (tail > 0 && created[tail - 1] !== void 0) {
    tail--;
  }
  for (let i = tail; i < children.length; i++) {
    const el = created[i];
    if (el && parentEl && children[i].tag !== "portal") {
      parentEl.insertBefore(el, baseAnchor || null);
    }
  }
  if (keep || createdCount > children.length - tail) {
    let anchor = findChildFragmentNextElement(children.slice(tail)) || baseAnchor;
    for (let i = tail - 1; i >= 0; i--) {
      const item = children[i];
      const isNew = created[i] !== void 0;
      const needMove = !!keep && keep[i] === false;
      if ((isNew || needMove) && parentEl && item.tag !== "portal") {
        const el = isNew ? created[i] : getElementFromFragment(item);
        if (el) {
          parentEl.insertBefore(el, anchor || null);
        }
      }
      const first = findChildFragmentNextElement([item]);
      if (first) {
        anchor = first;
      }
    }
  }
  children.forEach(clearDiffMeta);
  execMountedQueue();
};
const clearDiffMeta = (item) => {
  __hit$2("clearDiffMeta");
  item.oi = item.oc = item.op = void 0;
  item.nr = "N";
};
const getLisPositions = (seq) => {
  const tails = [];
  const prev = [];
  seq.forEach((value, i2) => {
    let lo = 0;
    let hi = tails.length;
    if (hi && seq[tails[hi - 1]] < value) {
      lo = hi;
    } else {
      while (lo < hi) {
        const mid = lo + hi >> 1;
        if (seq[tails[mid]] < value) {
          lo = mid + 1;
        } else {
          hi = mid;
        }
      }
    }
    prev[i2] = lo ? tails[lo - 1] : -1;
    tails[lo] = i2;
  });
  let i = tails.length;
  let last = tails[i - 1];
  while (i-- > 0) {
    tails[i] = last;
    last = prev[last];
  }
  return tails;
};
const wDomUpdate = (newWDomTree) => {
  __hit$2("wDomUpdate");
  const { nr: needRerender } = newWDomTree;
  if (needRerender && needRerender !== "N") {
    renderHandlers[needRerender](newWDomTree);
    clearDiffMeta(newWDomTree);
  }
};
const renderHandlers = {
  A: typeAdd,
  D: typeDelete,
  R: typeReplace,
  U: typeUpdate,
  S: typeSortedReplace,
  // A keyed item reaches here only as a component redrawing itself: it has
  // not moved, so it is updated in place. Re-inserting its nodes would blur a
  // focused input inside it or reload an iframe. Moves within a list are
  // placed by updateChildren.
  T: typeUpdate
};
const updateText = (newWDom) => {
  if (newWDom.el) {
    newWDom.el.nodeValue = String(newWDom.text);
  }
};
const updateProps = (props, element, oldProps) => {
  const originalProps = oldProps || {};
  for (const dataKey in props) {
    const dataValue = props[dataKey];
    if (dataValue === originalProps[dataKey]) {
      continue;
    }
    if (checkEventKey(dataKey)) {
      updateEvent(
        element,
        dataKey,
        dataValue,
        originalProps[dataKey]
      );
    } else {
      if (dataKey === "key") ;
      else if (dataKey === "portal" && isObject(dataValue)) ;
      else if (dataKey === "innerHTML" && typeof dataValue === "string") {
        element.innerHTML = dataValue;
      } else if (checkStyleData(dataKey, dataValue)) {
        updateStyle(
          dataValue,
          checkStyleData(dataKey, originalProps.style) ? originalProps.style : {},
          element
        );
      } else if (checkRefData(dataKey, dataValue)) {
        dataValue.value = element;
      } else if (dataKey) {
        if (dataKey !== "type" && hasAccessorMethods(element, dataKey)) {
          element[dataKey] = dataValue;
        } else {
          setAttr(
            dataKey === "className" ? "class" : dataKey,
            element,
            dataValue
          );
          if (isPendingCustomElement(element) && !(dataKey in HTMLElement.prototype)) {
            element[dataKey] = dataValue;
          }
        }
      }
    }
  }
  for (const dataKey in originalProps) {
    if (props && hasEnumerableProp(props, dataKey)) {
      continue;
    }
    if (checkEventKey(dataKey)) {
      updateEvent(
        element,
        dataKey,
        void 0,
        originalProps[dataKey]
      );
      continue;
    }
    element.removeAttribute(dataKey);
    if (isPendingCustomElement(element)) {
      delete element[dataKey];
    } else if (element.localName.includes("-") && hasAccessorMethods(element, dataKey)) {
      element[dataKey] = void 0;
    }
  }
};
const setAttr = (k, el, v) => xmlnsRef.value && k !== "xmlns" ? el.setAttributeNS(null, k, v) : el.setAttribute(k, v);
const wDomToDom = (wDom, isHydration) => {
  let element;
  const { type, tag, text, props, children = [] } = wDom;
  const isVirtualType = checkVirtualType(type);
  runWDomCallbacksFromWDom(wDom);
  if (tag === "svg") {
    xmlnsRef.value = String(props && props.xmlns);
  }
  {
    if (!type || isVirtualType) {
      element = DF();
    } else if (type === "e" && tag) {
      if (tag === "portal" && props && props.portal) {
        element = props.portal;
      } else {
        element = xmlnsRef.value ? document.createElementNS(xmlnsRef.value, tag) : CE(tag);
      }
    } else if (type === "t" && checkExisty(text)) {
      element = document.createTextNode(String(text));
    } else {
      throw Error("Invalid wDom");
    }
    wDom.el = element;
  }
  wDomChildrenToDom(wDom, children, element, isHydration);
  updateProps(props, element, null);
  addMountedQueue(wDom);
  if (tag === "svg") {
    xmlnsRef.value = "";
  }
  return element;
};
const wDomChildrenToDom = (wDom, children, parentElement, isHydration) => {
  const getParent2 = makeParentGetter(wDom);
  children.forEach((childItem, index) => {
    if (childItem.nr === "N" && !isHydration) {
      const copy = cloneWDom(childItem);
      childItem = children[index] = "resolve" in copy ? copy.resolve() : copy;
    }
    childItem.getParent = getParent2;
    childItem.nr = "N";
    if (childItem.type) {
      const childElement = wDomToDom(childItem, isHydration);
      if (childItem.tag !== "portal" && !isHydration && parentElement) {
        parentElement.appendChild(childElement);
      }
    }
  });
};
const updateEvent = (element, eventKey, newEventHandler, oldEventHandler) => {
  const eventName = eventKey.slice(2).toLowerCase();
  if (oldEventHandler !== newEventHandler) {
    if (oldEventHandler) {
      element.removeEventListener(eventName, oldEventHandler);
    }
    if (newEventHandler) {
      element.addEventListener(eventName, newEventHandler);
    }
  }
};
const updateStyle = (style, oldStyle, element) => {
  const orig = { ...oldStyle };
  if (!(element instanceof HTMLElement)) return;
  const styleProxy = element.style;
  for (const k in style) {
    styleProxy[k] = style[k];
    delete orig[k];
  }
  for (const k in orig) {
    styleProxy[k] = "";
  }
};
const findRealParentElement = (vDom) => checkVirtualType(vDom.type) ? vDom.isRoot ? vDom.we : findRealParentElement(getParent(vDom)) : vDom.el;
function __hit$1(key, n = 1) {
  const c = globalThis.__c2Counts;
  if (c) c[key] = (c[key] || 0) + n;
}
const makeNewWDomTree = (newWDom, originalWDom) => {
  if (newWDom !== originalWDom && newWDom.nr) {
    newWDom = cloneWDom(newWDom);
  }
  return remakeNewWDom(
    newWDom,
    !!originalWDom && checkSameWDomWithOriginal[getWDomType(newWDom)](newWDom, originalWDom),
    originalWDom
  );
};
const remakeNewWDom = (newWDom, isSameType, originalWDom) => {
  const remakeWDom = generalize(newWDom, isSameType, originalWDom);
  const needRerender = addReRenderTypeProperty(
    remakeWDom,
    isSameType,
    originalWDom
  );
  const isNoting = needRerender === "N";
  if (!isNoting) {
    remakeWDom.children = remakeChildrenForDiff(
      remakeWDom,
      isSameType,
      originalWDom
    );
  }
  remakeWDom.nr = needRerender;
  inheritPropForRender(remakeWDom, originalWDom, needRerender);
  if (!isNoting && originalWDom) {
    originalWDom.il = true;
    if (originalWDom.ctor) {
      originalWDom.children = void 0;
    }
  }
  if (originalWDom && originalWDom.tag === "portal") {
    remakeWDom.tag = "portal";
  }
  return remakeWDom;
};
const inheritPropForRender = (remakeWDom, originalWDom, needRerender) => {
  if (needRerender !== "A" && originalWDom) {
    remakeWDom.el = originalWDom.el;
  }
  if (needRerender === "D" || needRerender === "R" || needRerender === "S") {
    if (originalWDom) {
      runUnmountQueueFromWDom(originalWDom);
    }
    remakeWDom.oc = originalWDom && originalWDom.children;
  }
  remakeWDom.op = originalWDom && originalWDom.props;
};
const addReRenderTypeProperty = (newWDom, isSameType, originalWDom) => {
  if (checkEmptyElement(newWDom)) return "D";
  if (newWDom === originalWDom || isSameType && newWDom.type === "t" && newWDom.text === originalWDom.text) {
    return "N";
  }
  if (!(originalWDom && originalWDom.type)) return "A";
  const parent = getParent(originalWDom);
  const isKeyChecked = !newWDom.isRoot && parent && parent.type === "l" && checkExistyKey(newWDom);
  return isSameType ? isKeyChecked ? "T" : "U" : isKeyChecked ? "S" : "R";
};
const syncResolverProps = (props, infoProps) => {
  if (props && infoProps !== props) {
    infoProps = infoProps || {};
    keys(props).forEach(
      (key) => isEnumerableProp(infoProps, key) || delete props[key]
    );
    keys(infoProps).forEach((key) => props[key] = infoProps[key]);
  }
};
const runUpdate = (vDom, infoVdom) => {
  const { compProps: props, compChild: children } = vDom;
  const { props: infoProps, children: infoChidren } = infoVdom;
  if (props) {
    syncResolverProps(props, infoProps);
  }
  if (children && infoChidren && children !== infoChidren) {
    children.splice(0, children.length, ...infoChidren);
  }
  return vDom.reRender && vDom.reRender();
};
const generalize = (newWDom, isSameType, originalWDom) => {
  return checkCustemComponentFunction(newWDom) ? isSameType && originalWDom ? runUpdate(originalWDom, newWDom) : (
    // Resolved before (children a component draws again somewhere else):
    // the first instance owns its props, which are also its key, so the
    // new instance is made from a copy.
    (newWDom.rd ? copyResolver(newWDom) : (newWDom.rd = true, newWDom)).resolve()
  ) : newWDom;
};
const remakeChildrenForDiff = (newWDom, isSameType, originalWDom) => isSameType && originalWDom ? remakeChildrenForUpdate(newWDom, originalWDom) : remakeChildrenForAdd(newWDom);
const remakeChildrenForAdd = (newWDom) => {
  const getParent2 = makeParentGetter(newWDom);
  return (newWDom.children || []).map((item) => {
    const child = makeNewWDomTree(item);
    child.getParent = getParent2;
    return child;
  });
};
const remakeChildrenForUpdate = (newWDom, originalWDom) => {
  if (newWDom.type === "l" && checkKeyedChildren(newWDom)) {
    return diffLoopChildren(newWDom, originalWDom);
  }
  const origChildren = originalWDom.children || [];
  const getParent2 = makeParentGetter(newWDom);
  return (newWDom.children || []).map((item, index) => {
    const child = makeNewWDomTree(item, origChildren[index]);
    child.getParent = getParent2;
    return child;
  });
};
const diffLoopChildren = (newWDom, originalWDom) => {
  __hit$1("diffLoopChildren");
  const origChildren = originalWDom.children || [];
  const frame = childOrderRef.value;
  const keyMap = /* @__PURE__ */ new Map();
  origChildren.forEach((item, index) => {
    __hit$1("mapBuildVisits");
    __hit$1("diffKeyReads");
    const key = getKey(item);
    if (checkExisty(key) && !(__hit$1("mapHas"), keyMap.has(key))) {
      __hit$1("mapSet"), keyMap.set(key, index);
    }
  });
  const used = [];
  const getParent2 = makeParentGetter(newWDom);
  const children = newWDom.children || [];
  let sameOrder = children.length === origChildren.length;
  const remaked = children.map((item, index) => {
    __hit$1("diffKeyReads");
    const key = getKey(item);
    const origIndex = checkExisty(key) ? (__hit$1("mapGet"), keyMap.get(key)) : index < origChildren.length && !checkExistyKey(origChildren[index]) ? index : void 0;
    let original;
    if (origIndex !== void 0) {
      __hit$1("mapDelete"), keyMap.delete(key);
      used[origIndex] = true;
      original = origChildren[origIndex];
    }
    const child = makeNewWDomTree(item, original);
    if (original) {
      child.oi = origIndex;
    }
    child.getParent = getParent2;
    sameOrder = sameOrder && origIndex === index && (child.nr === "N" || child.nr === "U" || child.nr === "T") && child.tag !== "portal";
    return child;
  });
  typeDeleteUnused(
    origChildren.filter((_item, index) => (__hit$1("unusedVisits"), !used[index])),
    originalWDom
  );
  if (sameOrder && frame && !frame.invalid) {
    __hit$1("proofWrites");
    __hit$1("proofWriteChildren", remaked.length);
    frame.proofs.set(newWDom, remaked);
  }
  return remaked;
};
const redrawQueue = /* @__PURE__ */ new Map();
let redrawQueueTimeout = false;
const schedule = (compKey, exec) => {
  redrawQueue.set(compKey, exec);
  if (!redrawQueueTimeout) {
    redrawQueueTimeout = true;
    queueMicrotask(execRedrawQueue);
  }
};
const bindRedraw = (compKey, exec) => {
  const comp = componentMap.get(compKey);
  if (comp) {
    comp.up = () => {
      const wDom = comp.vd.value;
      schedule(compKey, () => exec(wDom));
    };
  }
};
const componentUpdate = (compKey) => () => {
  const comp = componentMap.get(compKey);
  const up = comp && comp.up;
  if (up) {
    up();
    return true;
  }
  return false;
};
const execRedrawQueue = () => {
  try {
    redrawQueue.forEach((item, compKey) => {
      redrawQueue.delete(compKey);
      item();
    });
  } finally {
    redrawQueueTimeout = !!redrawQueue.size;
    if (redrawQueueTimeout) queueMicrotask(execRedrawQueue);
  }
};
const createWDom = (type, tag, props, text, children, getParent2) => ({
  type,
  nr: void 0,
  tag,
  props,
  text,
  children,
  getParent: getParent2,
  el: void 0,
  oi: void 0,
  oc: void 0,
  op: void 0,
  il: void 0,
  [wdomSymbol]: true
});
const runUpdateCallback = () => {
  const comp = getCurrentComponent();
  const updateReqs = comp && comp.upR;
  if (updateReqs && updateReqs.length) {
    updateReqs.forEach((callback) => callback());
  }
};
function __hit(key, n = 1) {
  const c = globalThis.__c2Counts;
  if (c) c[key] = (c[key] || 0) + n;
}
const Fragment = (_props, ...children) => createWDom("f", void 0, void 0, void 0, children);
const h = (tag, props, ...children) => {
  const nodeParentPointer = { value: void 0 };
  const newChildren = remakeChildren(nodeParentPointer, children);
  const node = makeNode(tag, props || {}, newChildren);
  if (!checkCustemComponentFunction(node)) {
    nodeParentPointer.value = node;
  }
  return node;
};
const mount = (component) => (_props, _children) => component;
const syncAncestorComponentChildren = (parent, prevChild, nextChild) => {
  const walk = (node, visited) => {
    if (!node || visited.has(node)) {
      return;
    }
    visited.add(node);
    if (node.compChild) {
      const childIndex = node.compChild.indexOf(prevChild);
      if (childIndex !== -1) {
        node.compChild.splice(childIndex, 1, nextChild);
      }
    }
    walk(node.getParent ? node.getParent() : void 0, visited);
  };
  walk(parent, /* @__PURE__ */ new Set());
};
const replaceWDom = (tag, props, children, originalWDom) => {
  if (originalWDom.il) {
    return;
  }
  const previousFrame = childOrderRef.value;
  if (previousFrame) previousFrame.invalid = true;
  const frame = {
    proofs: /* @__PURE__ */ new WeakMap(),
    ready: false,
    invalid: false
  };
  __hit("frameStart");
  childOrderRef.value = frame;
  try {
    needDiffRef.value = true;
    let newWDomTree;
    try {
      const newWDom = makeWDomResolver(tag, props, children);
      newWDomTree = makeNewWDomTree(newWDom, originalWDom);
      const { isRoot, getParent: getParent2, we, ae } = originalWDom;
      newWDomTree.getParent = getParent2;
      if (!isRoot && getParent2) {
        const parent = getParent2();
        const brothers = parent && parent.children || [];
        const index = brothers.indexOf(originalWDom);
        if (index !== -1) {
          brothers.splice(index, 1, newWDomTree);
        }
        syncAncestorComponentChildren(parent, originalWDom, newWDomTree);
      } else {
        newWDomTree.isRoot = true;
        newWDomTree.we = we;
        newWDomTree.ae = ae;
      }
    } finally {
      needDiffRef.value = false;
    }
    frame.ready = true;
    wDomUpdate(newWDomTree);
  } finally {
    __hit("frameEnd");
    childOrderRef.value = previousFrame;
  }
};
const makeNode = (tag, props, children) => {
  if (checkFragmentFunction(tag)) {
    return Fragment(props, ...children);
  } else if (checkCustemComponentFunction(tag)) {
    const componetMakeResolver = makeWDomResolver(tag, props, children);
    if (needDiffRef.value) {
      return componetMakeResolver;
    }
    const node = copyResolver(componetMakeResolver).resolve();
    node.rs = componetMakeResolver;
    return node;
  }
  return createWDom("e", tag, props, void 0, children);
};
const remakeChildren = (nodeParentPointer, children) => {
  const getParent2 = () => nodeParentPointer.value;
  return children.map((item) => {
    const childItem = makeChildrenItem(item);
    childItem.getParent = getParent2;
    return childItem;
  });
};
const makeChildrenItem = (item) => {
  if (item === null || item === void 0 || typeof item === "boolean") {
    return createWDom(null);
  } else if (Array.isArray(item)) {
    const nodeParentPointer = { value: void 0 };
    const children = remakeChildren(nodeParentPointer, item);
    const node = createWDom("l", void 0, void 0, void 0, children);
    nodeParentPointer.value = node;
    return node;
  } else if (typeof item === "string" || typeof item === "number") {
    return createWDom("t", void 0, void 0, item);
  }
  return item;
};
const createComponentResolver = (tag, props, wrappedChildren) => {
  return (compKey = props) => {
    const prevNeedDiff = needDiffRef.value;
    const previousKey = compKeyRef.value;
    needDiffRef.value = false;
    try {
      initMountHookState(compKey, tag);
      const initialComponent = tag(props, wrappedChildren);
      let componentMaker;
      if (typeof initialComponent === "function") {
        const component = initialComponent;
        componentMaker = lmountComponentSet.has(component) ? component(props, wrappedChildren) : component(componentUpdate(compKey), props, wrappedChildren);
      } else {
        let firstRender = true;
        componentMaker = (nextProps) => {
          if (firstRender) {
            firstRender = false;
            return initialComponent;
          }
          return tag(nextProps, wrappedChildren);
        };
      }
      return makeCustomNode(
        componentMaker,
        compKey,
        tag,
        props,
        wrappedChildren
      );
    } finally {
      compKeyRef.value = previousKey;
      needDiffRef.value = prevNeedDiff;
    }
  };
};
const cloneWDom = (wDom) => wDom.ctor ? copyResolver(
  wDom.rs || {
    ctor: wDom.ctor,
    props: wDom.compProps,
    children: wDom.compChild
  }
) : createWDom(
  wDom.type,
  wDom.tag,
  wDom.props,
  wDom.text,
  wDom.children && [...wDom.children],
  wDom.getParent
);
const copyResolver = ({
  ctor,
  props,
  children
}) => makeWDomResolver(ctor, { ...props }, [...children || []]);
const makeWDomResolver = (tag, props, children) => ({
  ctor: tag,
  props,
  children,
  resolve: createComponentResolver(tag, props, children)
});
const makeCustomNode = (componentMaker, compKey, tag, props, children) => {
  const wrappedComponentMaker = wrapComponentMaker(componentMaker);
  const customNode = wrappedComponentMaker(props);
  const reRender = makeReRender(
    wrappedComponentMaker,
    compKey,
    tag,
    props,
    children
  );
  addComponentProps(customNode, compKey, tag, props, children, reRender);
  bindRedraw(
    compKey,
    (wDom) => replaceWDom(
      tag,
      wDom.compProps || props,
      wDom.compChild || children,
      wDom
    )
  );
  return customNode;
};
const makeReRender = (componentMaker, compKey, tag, props, children) => {
  const reRender = () => {
    const previousKey = compKeyRef.value;
    try {
      initUpdateHookState(compKey);
      runUpdateCallback();
      const customNode = componentMaker(props);
      addComponentProps(customNode, compKey, tag, props, children, reRender);
      return customNode;
    } finally {
      compKeyRef.value = previousKey;
    }
  };
  return reRender;
};
const wrapComponentMaker = (componentMaker) => (newProps) => {
  const next = makeChildrenItem(componentMaker(newProps));
  const wrapper = Fragment({}, next);
  next.getParent = () => wrapper;
  return wrapper;
};
const addComponentProps = (wDom, compKey, tag, props, children, reRender) => {
  wDom.compProps = props;
  wDom.compChild = children;
  wDom.ctor = tag;
  wDom.compKey = compKey;
  wDom.reRender = reRender;
  const comp = componentMap.get(compKey);
  if (comp) {
    comp.vd.value = wDom;
  }
};
const nextTick = () => Promise.resolve();
const cacheUpdate = (checkFunction, updater) => {
  let originalDefs = [];
  let originalUpdater = null;
  return (props) => {
    const newDefs = checkFunction();
    const isSame = originalDefs.length === newDefs.length && originalDefs.every((def, index) => def === newDefs[index]);
    originalDefs = newDefs;
    if (isSame && originalUpdater) {
      return originalUpdater;
    }
    const newUpdater = updater(props);
    originalUpdater = newUpdater;
    return newUpdater;
  };
};
const adjectives = [
  "pretty",
  "large",
  "big",
  "small",
  "tall",
  "short",
  "long",
  "handsome",
  "plain",
  "quaint",
  "clean",
  "elegant",
  "easy",
  "angry",
  "crazy",
  "helpful",
  "mushy",
  "odd",
  "unsightly",
  "adorable",
  "important",
  "inexpensive",
  "cheap",
  "expensive",
  "fancy"
];
const colours = [
  "red",
  "yellow",
  "blue",
  "green",
  "pink",
  "brown",
  "purple",
  "brown",
  "white",
  "black",
  "orange"
];
const nouns = [
  "table",
  "chair",
  "house",
  "bbq",
  "desk",
  "car",
  "pony",
  "cookie",
  "sandwich",
  "burger",
  "pizza",
  "mouse",
  "keyboard"
];
const random = (max) => Math.round(Math.random() * 1e3) % max;
const buildLabel = () => `${adjectives[random(adjectives.length)]} ${colours[random(colours.length)]} ${nouns[random(nouns.length)]}`;
let nextId = 1;
const store = {
  state: { rows: [], selected: null },
  buildData(count) {
    const data = new Array(count);
    for (let i = 0; i < count; i += 1) {
      data[i] = makeRow(nextId, buildLabel());
      nextId += 1;
    }
    return data;
  },
  run() {
    this.state.rows = this.buildData(1e3);
  },
  runLots() {
    this.state.rows = this.buildData(1e4);
  },
  add() {
    this.state.rows = this.state.rows.concat(this.buildData(1e3));
  },
  update() {
    const { rows } = this.state;
    for (let i = 0; i < rows.length; i += 10) {
      rows[i].label += " !!!";
    }
  },
  clear() {
    this.state.rows = [];
    this.state.selected = null;
  },
  swapRows() {
    const { rows } = this.state;
    if (rows.length > 998) {
      const tmp = rows[1];
      rows[1] = rows[998];
      rows[998] = tmp;
    }
  },
  remove(id) {
    this.state.rows = this.state.rows.filter((r) => r.id !== id);
  },
  select(id) {
    this.state.selected = id;
  }
};
let renewTable = () => {
};
function makeRow(id, label) {
  const onSelect = () => {
    store.select(id);
    renewTable();
  };
  const onRemove = () => {
    store.remove(id);
    renewTable();
  };
  const row = {
    id,
    label,
    view: cacheUpdate(
      () => [row.label, store.state.selected === id],
      () => /* @__PURE__ */ h("tr", { key: id, class: store.state.selected === id ? "danger" : void 0 }, /* @__PURE__ */ h("td", { class: "col-md-1" }, id), /* @__PURE__ */ h("td", { class: "col-md-4" }, /* @__PURE__ */ h("a", { onClick: onSelect }, row.label)), /* @__PURE__ */ h("td", { class: "col-md-1" }, /* @__PURE__ */ h("a", { onClick: onRemove }, /* @__PURE__ */ h("span", { class: "glyphicon glyphicon-remove", "aria-hidden": "true" }))), /* @__PURE__ */ h("td", { class: "col-md-6" }))
    )
  };
  return row;
}
const Table = mount((renew) => {
  renewTable = renew;
  return () => /* @__PURE__ */ h(Fragment, null, store.state.rows.map((row) => row.view(row)));
});
const App = mount(() => {
  const action = (run) => () => {
    run();
    renewTable();
  };
  const buttons = [
    {
      id: "run",
      text: "Create 1,000 rows",
      onClick: action(() => store.run())
    },
    {
      id: "runlots",
      text: "Create 10,000 rows",
      onClick: action(() => store.runLots())
    },
    {
      id: "add",
      text: "Append 1,000 rows",
      onClick: action(() => store.add())
    },
    {
      id: "update",
      text: "Update every 10th row",
      onClick: action(() => store.update())
    },
    { id: "clear", text: "Clear", onClick: action(() => store.clear()) },
    {
      id: "swaprows",
      text: "Swap Rows",
      onClick: action(() => store.swapRows())
    }
  ];
  return () => /* @__PURE__ */ h("div", { class: "container" }, /* @__PURE__ */ h("div", { class: "jumbotron" }, /* @__PURE__ */ h("div", { class: "row" }, /* @__PURE__ */ h("div", { class: "col-md-6" }, /* @__PURE__ */ h("h1", null, 'Lithent-"keyed"')), /* @__PURE__ */ h("div", { class: "col-md-6" }, /* @__PURE__ */ h("div", { class: "row" }, buttons.map(({ id, text, onClick }) => /* @__PURE__ */ h("div", { key: id, class: "col-sm-6 smallpad" }, /* @__PURE__ */ h(
    "button",
    {
      type: "button",
      class: "btn btn-primary btn-block",
      id,
      onClick
    },
    text
  ))))))), /* @__PURE__ */ h("table", { class: "table table-hover table-striped test-data" }, /* @__PURE__ */ h("tbody", { id: "tbody" }, /* @__PURE__ */ h(Table, null))), /* @__PURE__ */ h("span", { class: "preloadicon glyphicon glyphicon-remove", "aria-hidden": "true" }));
});
render(/* @__PURE__ */ h(App, null), document.getElementById("main"));
export {
  nextTick
};
