const Ot = Symbol.for("lithentWDomSymbol"), S = { value: "" }, m = { value: null }, b = { value: !1 }, y = /* @__PURE__ */ new WeakMap(), Bt = /* @__PURE__ */ new WeakSet(), Ht = (t, e) => {
  y.set(t, {
    ctor: e,
    vd: { value: null },
    up: () => {
    },
    upR: [],
    upS: { value: 0 },
    upD: [],
    upCB: [],
    mts: [],
    umts: [],
    wdCB: []
    // WDom creation callback queue
  });
}, ht = () => y.get(m.value), jt = (t) => {
  m.value = t;
}, Kt = (t, e) => {
  m.value = t, Ht(t, e);
}, Ut = (t) => {
  const e = y.get(t);
  e && (e.umts.forEach((o) => o()), e.umts = []);
}, w = (t) => t.getParent && t.getParent(), B = (t) => () => t, et = Object.keys, ft = (t, e) => Object.prototype.propertyIsEnumerable.call(t, e), vt = (t, e) => {
  if (ft(t, e)) return !0;
  const o = Object.getPrototypeOf(t);
  return !Object.prototype.hasOwnProperty.call(t, e) && !!o && vt(o, e);
}, H = (t) => typeof t == "object" && t !== null, zt = (t, e) => "ctor" in t ? t.ctor === (e && e.ctor) : t === (e && e.ctor), Wt = (t, e) => e.type === "f" && // A component's node is a one-child fragment too: never update it in
// place as a plain fragment, or the component is never unmounted, nor
// update a plain fragment with one (a hoisted <Comp /> first drawn by a
// redraw), or it is never mounted.
!e.ctor && !t.ctor && !!e.children && e.children.length === (t.children && t.children.length), qt = (t, e) => e.type === "e" && e.tag === t.tag && !!e.children && e.children.length === (t.children && t.children.length), ot = (t, e) => e.type === t.type, It = (t, e) => e.type === t.type && ($(t) && $(e) || !!e.children && e.children.length === (t.children && t.children.length)), q = (t) => (t && t.compProps && t.compProps.key) ?? (t && t.props && t.props.key), P = (t) => t === "f" || t === "l", j = (t) => typeof t == "function" && !gt(t) || H(t) && "resolve" in t, gt = (t) => t === z, $t = (t) => !t.type, I = (t) => t[0] === "o" && t[1] === "n", G = (t) => L(q(t)), $ = (t) => !!t && !!t.children && t.children.some(G), L = (t) => t != null, nt = (t, e) => t === "style" && H(e), Ft = (t, e) => t === "ref" && H(e), rt = /* @__PURE__ */ new WeakMap(), lt = (t, e) => {
  const o = t.constructor.prototype;
  let n = rt.get(o);
  n || rt.set(o, n = /* @__PURE__ */ new Map());
  let r = n.get(e);
  if (r === void 0) {
    const l = Object.getOwnPropertyDescriptor(o, e);
    r = !!(l && l.get && l.set), n.set(e, r);
  }
  return r;
}, st = (t) => t.localName.includes("-") && t.constructor === HTMLElement, Vt = (t) => j(t) ? "c" : t.type || "et", Gt = {
  c: zt,
  l: It,
  t: ot,
  e: qt,
  f: Wt,
  et: ot
}, yt = (t) => {
  const e = ht();
  e && e.umts.push(t);
}, K = (t) => {
  const { compKey: e } = t;
  e && (t.il = !0, Jt(e)), mt(t);
}, mt = (t) => {
  if (t.tag === "portal" && t.el)
    for (const e in t.props)
      I(e) && t.el.removeEventListener(
        e.slice(2).toLowerCase(),
        t.props[e]
      );
  (t.children || []).forEach((e) => {
    e.compKey ? K(e) : mt(e);
  });
}, Jt = (t) => {
  Ut(t), y.delete(t);
};
let F = [];
const Qt = (t) => {
  t.compKey && F.push(t);
}, x = () => {
  F.forEach(Xt), F = [];
}, Xt = (t) => {
  const { compKey: e } = t, o = e && y.get(e);
  if (o) {
    const n = o.mts;
    m.value = e, o.upS.value = 0, o.mts = [], n.forEach((r) => {
      const l = r();
      l && yt(l);
    });
  }
}, Yt = (t) => {
  const { compKey: e } = t;
  if (e) {
    const o = y.get(e), n = o && o.wdCB;
    m.value = e, n && n.length > 0 && (o.wdCB = [], n.forEach((r) => {
      const l = r();
      typeof l == "function" && yt(l);
    }));
  }
}, _t = (t) => {
  const { compKey: e } = t, o = e && y.get(e);
  if (o) {
    const n = o.upCB;
    m.value = e, o.upS.value = 0, t.ctor && (o.upCB = [], n.forEach((r) => r()));
  }
}, wt = () => new DocumentFragment(), bt = (t, e, o) => o ? t.insertBefore(e, o) : t.tagName === "HTML" ? t.replaceWith(e) : t.appendChild(e), Zt = (t) => document.createElement(t), te = (t, e, o, n) => {
  t.isRoot = !0, e = e || document.body, t.we = e;
  const r = R(t, n);
  return t.ae = o, bt(e, r, o), x(), () => {
    const l = y.get(t.compProps), s = l && l.vd.value || t;
    K(s), ee(s);
  };
}, ee = (t) => Q(t, t.we), J = (t) => {
  const e = w(t);
  Q(
    t,
    t.isRoot ? t.we : e && C(e)
  );
}, Q = (t, e) => {
  if (e && t.el) {
    const o = t.el.nodeType;
    o === 11 || t.tag === "portal" ? Et(t, e) : (o === 1 || o === 3) && e.removeChild(t.el), t.el = void 0;
  }
}, Et = (t, e) => {
  const o = t.oc || t.children || [];
  if (o.length > 1 && o.every((n) => {
    const r = n.el && n.el.nodeType;
    return (r === 1 || r === 3) && n.el.tagName !== "HTML" && n.tag !== "portal";
  })) {
    let n = 0;
    for (let r = e.firstChild; r && n <= o.length; r = r.nextSibling)
      n++;
    if (n === o.length) {
      e.textContent = "", o.forEach((r) => r.el = void 0);
      return;
    }
  }
  o.forEach((n) => {
    const r = n.el && n.el.nodeType;
    if (r)
      if (r === 1 || r === 3) {
        const l = n.el;
        l.tagName === "HTML" ? l.innerHTML = "" : l.remove();
      } else r === 11 && Et(n, e);
  });
}, oe = (t, e) => {
  const o = C(e);
  t.forEach((n) => {
    K(n), Q(n, o);
  });
}, Ct = (t) => {
  J(t), kt(t);
}, kt = (t, e) => {
  e = e || R(t);
  const o = w(t);
  if (!o || !o.type) {
    t.isRoot && t.we && t.tag !== "portal" && (bt(t.we, e, t.ae), x());
    return;
  }
  const n = C(o), r = X(t, o);
  n && (t.tag !== "portal" && n.insertBefore(e, r || null), x());
}, St = (t) => P(t.type) ? (t.children || []).reduce((e, o) => {
  const n = St(o);
  return n && e.appendChild(n), e;
}, wt()) : t.el, X = (t, e) => {
  const o = e.children || [];
  return A(o.slice(o.indexOf(t) + 1)) || (P(e.type) ? e.isRoot ? e.ae : X(e, w(e)) : void 0);
}, N = /* @__PURE__ */ new Set(), A = (t) => t.reduce(
  (e, o) => {
    if (e || N.size && N.has(o)) return e;
    const { type: n, el: r } = o;
    if (n && P(n)) {
      const l = A(o.children || []);
      if (l) return l;
    }
    return r && r.nodeType !== 11 ? r : e;
  },
  void 0
), ne = (t) => {
  const e = w(t), o = t.el;
  if (o && (e ? e.type : t.isRoot))
    if (!e || o.nodeType === 11)
      Ct(t);
    else {
      const n = C(e), r = R(t);
      n && t.tag !== "portal" && n.replaceChild(r, o), x();
    }
}, ct = (t) => {
  if (t.type === "t") {
    ce(t);
    return;
  }
  if (t.el) {
    const { op: e, props: o } = t;
    Pt(o, t.el, e), t.tag === "input" && (t.el.value = String(
      o && o.value || ""
    ));
  }
  re(t), _t(t);
}, re = (t) => {
  const e = t.children || [];
  if (t.type !== "l" || !e.some(
    (i) => "ATS".includes(i.nr) || i.oi !== void 0
  )) {
    e.forEach(V);
    return;
  }
  const o = [], n = [], r = [];
  let l = !0;
  e.forEach((i, u) => {
    const v = i.oi, k = i.nr;
    k === "S" ? r.push(i) : k !== "A" && v !== void 0 && (v < n[n.length - 1] && (l = !1), o.push(u), n.push(v));
  });
  let s;
  if (!l) {
    const i = s = [];
    le(n).forEach((u) => i[o[u]] = !0), o.forEach(
      (u) => i[u] || (i[u] = !1, r.push(e[u]))
    );
  }
  const c = [];
  let a = 0;
  r.forEach((i) => N.add(i));
  try {
    e.forEach((i, u) => {
      const v = i.nr;
      v === "A" || v === "S" ? (v === "S" && J(i), c[u] = R(i), a++) : V(i);
    });
  } finally {
    r.forEach((i) => N.delete(i));
  }
  const d = C(t), f = t.isRoot ? t.ae : X(t, w(t));
  let h = e.length;
  for (; h > 0 && c[h - 1] !== void 0; )
    h--;
  for (let i = h; i < e.length; i++) {
    const u = c[i];
    u && d && e[i].tag !== "portal" && d.insertBefore(u, f || null);
  }
  if (s || a > e.length - h) {
    let i = A(e.slice(h)) || f;
    for (let u = h - 1; u >= 0; u--) {
      const v = e[u], k = c[u] !== void 0, Dt = !!s && s[u] === !1;
      if ((k || Dt) && d && v.tag !== "portal") {
        const tt = k ? c[u] : St(v);
        tt && d.insertBefore(tt, i || null);
      }
      const Z = A([v]);
      Z && (i = Z);
    }
  }
  e.forEach(xt), x();
}, xt = (t) => {
  t.oi = t.oc = t.op = void 0, t.nr = "N";
}, le = (t) => {
  const e = [], o = [];
  t.forEach((l, s) => {
    let c = 0, a = e.length;
    if (a && t[e[a - 1]] < l)
      c = a;
    else
      for (; c < a; ) {
        const d = c + a >> 1;
        t[e[d]] < l ? c = d + 1 : a = d;
      }
    o[s] = c ? e[c - 1] : -1, e[c] = s;
  });
  let n = e.length, r = e[n - 1];
  for (; n-- > 0; )
    e[n] = r, r = o[r];
  return e;
}, V = (t) => {
  const { nr: e } = t;
  e && e !== "N" && (se[e](t), xt(t));
}, se = {
  A: kt,
  D: J,
  R: ne,
  U: ct,
  S: Ct,
  // A keyed item reaches here only as a component redrawing itself: it has
  // not moved, so it is updated in place. Re-inserting its nodes would blur a
  // focused input inside it or reload an iframe. Moves within a list are
  // placed by updateChildren.
  T: ct
}, ce = (t) => {
  t.el && (t.el.nodeValue = String(t.text));
}, Pt = (t, e, o) => {
  const n = o || {};
  for (const r in t) {
    const l = t[r];
    l !== n[r] && (I(r) ? at(
      e,
      r,
      l,
      n[r]
    ) : r === "key" || r === "portal" && H(l) || (r === "innerHTML" && typeof l == "string" ? e.innerHTML = l : nt(r, l) ? pe(
      l,
      nt(r, n.style) ? n.style : {},
      e
    ) : Ft(r, l) ? l.value = e : r && (r !== "type" && lt(e, r) ? e[r] = l : (ae(
      r === "className" ? "class" : r,
      e,
      l
    ), st(e) && !(r in HTMLElement.prototype) && (e[r] = l)))));
  }
  for (const r in n)
    if (!(t && vt(t, r))) {
      if (I(r)) {
        at(
          e,
          r,
          void 0,
          n[r]
        );
        continue;
      }
      e.removeAttribute(r), st(e) ? delete e[r] : e.localName.includes("-") && lt(e, r) && (e[r] = void 0);
    }
}, ae = (t, e, o) => S.value && t !== "xmlns" ? e.setAttributeNS(null, t, o) : e.setAttribute(t, o), R = (t, e) => {
  let o;
  const { type: n, tag: r, text: l, props: s, children: c = [] } = t, a = P(n);
  if (Yt(t), r === "svg" && (S.value = String(s && s.xmlns)), !e) {
    if (!n || a)
      o = wt();
    else if (n === "e" && r)
      r === "portal" && s && s.portal ? o = s.portal : o = S.value ? document.createElementNS(S.value, r) : Zt(r);
    else if (n === "t" && L(l))
      o = document.createTextNode(String(l));
    else
      throw Error("Invalid wDom");
    t.el = o;
  }
  return ie(t, c, o, e), Pt(s, o, null), Qt(t), r === "svg" && (S.value = ""), o;
}, ie = (t, e, o, n) => {
  const r = B(t);
  e.forEach((l, s) => {
    if (l.nr === "N" && !n) {
      const c = Nt(l);
      l = e[s] = "resolve" in c ? c.resolve() : c;
    }
    if (l.getParent = r, l.nr = "N", l.type) {
      const c = R(l, n);
      l.tag !== "portal" && !n && o && o.appendChild(c);
    }
  });
}, at = (t, e, o, n) => {
  const r = e.slice(2).toLowerCase();
  n !== o && (n && t.removeEventListener(r, n), o && t.addEventListener(r, o));
}, pe = (t, e, o) => {
  const n = { ...e };
  if (!(o instanceof HTMLElement)) return;
  const r = o.style;
  for (const l in t)
    r[l] = t[l], delete n[l];
  for (const l in n)
    r[l] = "";
}, C = (t) => P(t.type) ? t.isRoot ? t.we : C(w(t)) : t.el, U = (t, e) => (t !== e && t.nr && (t = Nt(t)), de(
  t,
  !!e && Gt[Vt(t)](t, e),
  e
)), de = (t, e, o) => {
  const n = ge(t, e, o), r = he(
    n,
    e,
    o
  ), l = r === "N";
  return l || (n.children = ye(
    n,
    e,
    o
  )), n.nr = r, ue(n, o, r), !l && o && (o.il = !0, o.ctor && (o.children = void 0)), o && o.tag === "portal" && (n.tag = "portal"), n;
}, ue = (t, e, o) => {
  o !== "A" && e && (t.el = e.el), (o === "D" || o === "R" || o === "S") && (e && K(e), t.oc = e && e.children), t.op = e && e.props;
}, he = (t, e, o) => {
  if ($t(t)) return "D";
  if (t === o || e && t.type === "t" && t.text === o.text)
    return "N";
  if (!(o && o.type)) return "A";
  const n = w(o), r = !t.isRoot && n && n.type === "l" && G(t);
  return e ? r ? "T" : "U" : r ? "S" : "R";
}, fe = (t, e) => {
  t && e !== t && (e = e || {}, et(t).forEach(
    (o) => ft(e, o) || delete t[o]
  ), et(e).forEach((o) => t[o] = e[o]));
}, ve = (t, e) => {
  const { compProps: o, compChild: n } = t, { props: r, children: l } = e;
  return o && fe(o, r), n && l && n !== l && n.splice(0, n.length, ...l), t.reRender && t.reRender();
}, ge = (t, e, o) => j(t) ? e && o ? ve(o, t) : (
  // Resolved before (children a component draws again somewhere else):
  // the first instance owns its props, which are also its key, so the
  // new instance is made from a copy.
  (t.rd ? Y(t) : (t.rd = !0, t)).resolve()
) : t, ye = (t, e, o) => e && o ? we(t, o) : me(t), me = (t) => {
  const e = B(t);
  return (t.children || []).map((o) => {
    const n = U(o);
    return n.getParent = e, n;
  });
}, we = (t, e) => {
  if (t.type === "l" && $(t))
    return be(t, e);
  const o = e.children || [], n = B(t);
  return (t.children || []).map((r, l) => {
    const s = U(r, o[l]);
    return s.getParent = n, s;
  });
}, be = (t, e) => {
  const o = e.children || [], n = /* @__PURE__ */ new Map();
  o.forEach((c, a) => {
    const d = q(c);
    L(d) && !n.has(d) && n.set(d, a);
  });
  const r = [], l = B(t), s = (t.children || []).map((c, a) => {
    const d = q(c), f = L(d) ? n.get(d) : a < o.length && !G(o[a]) ? a : void 0;
    let h;
    f !== void 0 && (n.delete(d), r[f] = !0, h = o[f]);
    const i = U(c, h);
    return h && (i.oi = f), i.getParent = l, i;
  });
  return oe(
    o.filter((c, a) => !r[a]),
    e
  ), s;
}, M = /* @__PURE__ */ new Map();
let D = !1;
const Ee = (t, e) => {
  M.set(t, e), D || (D = !0, queueMicrotask(Rt));
}, Ce = (t, e) => {
  const o = y.get(t);
  o && (o.up = () => {
    const n = o.vd.value;
    Ee(t, () => e(n));
  });
}, ke = (t) => () => {
  const e = y.get(t), o = e && e.up;
  return o ? (o(), !0) : !1;
}, Rt = () => {
  try {
    M.forEach((t, e) => {
      M.delete(e), t();
    });
  } finally {
    D = !!M.size, D && queueMicrotask(Rt);
  }
}, E = (t, e, o, n, r, l) => ({
  type: t,
  nr: void 0,
  tag: e,
  props: o,
  text: n,
  children: r,
  getParent: l,
  el: void 0,
  oi: void 0,
  oc: void 0,
  op: void 0,
  il: void 0,
  [Ot]: !0
}), Se = () => {
  const t = ht(), e = t && t.upR;
  e && e.length && e.forEach((o) => o());
}, z = (t, ...e) => E("f", void 0, void 0, void 0, e), p = (t, e, ...o) => {
  const n = { value: void 0 }, r = Mt(n, o), l = Re(t, e || {}, r);
  return j(l) || (n.value = l), l;
}, Tt = (t) => (e, o) => t, xe = (t, e, o) => {
  const n = (r, l) => {
    if (!(!r || l.has(r))) {
      if (l.add(r), r.compChild) {
        const s = r.compChild.indexOf(e);
        s !== -1 && r.compChild.splice(s, 1, o);
      }
      n(r.getParent ? r.getParent() : void 0, l);
    }
  };
  n(t, /* @__PURE__ */ new Set());
}, Pe = (t, e, o, n) => {
  if (n.il)
    return;
  b.value = !0;
  let r;
  try {
    const l = _(t, e, o);
    r = U(l, n);
    const { isRoot: s, getParent: c, we: a, ae: d } = n;
    if (r.getParent = c, !s && c) {
      const f = c(), h = f && f.children || [], i = h.indexOf(n);
      i !== -1 && h.splice(i, 1, r), xe(f, n, r);
    } else
      r.isRoot = !0, r.we = a, r.ae = d;
  } finally {
    b.value = !1;
  }
  V(r);
}, Re = (t, e, o) => {
  if (gt(t))
    return z(e, ...o);
  if (j(t)) {
    const n = _(t, e, o);
    if (b.value)
      return n;
    const r = Y(n).resolve();
    return r.rs = n, r;
  }
  return E("e", t, e, void 0, o);
}, Mt = (t, e) => {
  const o = () => t.value;
  return e.map((n) => {
    const r = Lt(n);
    return r.getParent = o, r;
  });
}, Lt = (t) => {
  if (t == null || typeof t == "boolean")
    return E(null);
  if (Array.isArray(t)) {
    const e = { value: void 0 }, o = Mt(e, t), n = E("l", void 0, void 0, void 0, o);
    return e.value = n, n;
  } else if (typeof t == "string" || typeof t == "number")
    return E("t", void 0, void 0, t);
  return t;
}, Te = (t, e, o) => (n = e) => {
  const r = b.value, l = m.value;
  b.value = !1;
  try {
    Kt(n, t);
    const s = t(e, o);
    let c;
    if (typeof s == "function") {
      const a = s;
      c = Bt.has(a) ? a(e, o) : a(ke(n), e, o);
    } else {
      let a = !0;
      c = (d) => a ? (a = !1, s) : t(d, o);
    }
    return Me(
      c,
      n,
      t,
      e,
      o
    );
  } finally {
    m.value = l, b.value = r;
  }
}, Nt = (t) => t.ctor ? Y(
  t.rs || {
    ctor: t.ctor,
    props: t.compProps,
    children: t.compChild
  }
) : E(
  t.type,
  t.tag,
  t.props,
  t.text,
  t.children && [...t.children],
  t.getParent
), Y = ({
  ctor: t,
  props: e,
  children: o
}) => _(t, { ...e }, [...o || []]), _ = (t, e, o) => ({
  ctor: t,
  props: e,
  children: o,
  resolve: Te(t, e, o)
}), Me = (t, e, o, n, r) => {
  const l = Ne(t), s = l(n), c = Le(
    l,
    e,
    o,
    n,
    r
  );
  return At(s, e, o, n, r, c), Ce(
    e,
    (a) => Pe(
      o,
      a.compProps || n,
      a.compChild || r,
      a
    )
  ), s;
}, Le = (t, e, o, n, r) => {
  const l = () => {
    const s = m.value;
    try {
      jt(e), Se();
      const c = t(n);
      return At(c, e, o, n, r, l), c;
    } finally {
      m.value = s;
    }
  };
  return l;
}, Ne = (t) => (e) => {
  const o = Lt(t(e)), n = z({}, o);
  return o.getParent = () => n, n;
}, At = (t, e, o, n, r, l) => {
  t.compProps = n, t.compChild = r, t.ctor = o, t.compKey = e, t.reRender = l;
  const s = y.get(e);
  s && (s.vd.value = t);
}, Ae = (t, e) => {
  let o = [], n = null;
  return (r) => {
    const l = t(), s = o.length === l.length && o.every((a, d) => a === l[d]);
    if (o = l, s && n)
      return n;
    const c = e(r);
    return n = c, c;
  };
}, it = [
  "pretty",
  "large",
  "big",
  "small",
  "tall",
  "short",
  "long",
  "handsome",
  "plain",
  "quaint",
  "clean",
  "elegant",
  "easy",
  "angry",
  "crazy",
  "helpful",
  "mushy",
  "odd",
  "unsightly",
  "adorable",
  "important",
  "inexpensive",
  "cheap",
  "expensive",
  "fancy"
], pt = [
  "red",
  "yellow",
  "blue",
  "green",
  "pink",
  "brown",
  "purple",
  "brown",
  "white",
  "black",
  "orange"
], dt = [
  "table",
  "chair",
  "house",
  "bbq",
  "desk",
  "car",
  "pony",
  "cookie",
  "sandwich",
  "burger",
  "pizza",
  "mouse",
  "keyboard"
], W = (t) => Math.round(Math.random() * 1e3) % t, De = () => `${it[W(it.length)]} ${pt[W(pt.length)]} ${dt[W(dt.length)]}`;
let ut = 1;
const g = {
  state: { rows: [], selected: null },
  buildData(t) {
    const e = new Array(t);
    for (let o = 0; o < t; o += 1)
      e[o] = Oe(ut, De()), ut += 1;
    return e;
  },
  run() {
    this.state.rows = this.buildData(1e3);
  },
  runLots() {
    this.state.rows = this.buildData(1e4);
  },
  add() {
    this.state.rows = this.state.rows.concat(this.buildData(1e3));
  },
  update() {
    const { rows: t } = this.state;
    for (let e = 0; e < t.length; e += 10)
      t[e].label += " !!!";
  },
  clear() {
    this.state.rows = [], this.state.selected = null;
  },
  swapRows() {
    const { rows: t } = this.state;
    if (t.length > 998) {
      const e = t[1];
      t[1] = t[998], t[998] = e;
    }
  },
  remove(t) {
    this.state.rows = this.state.rows.filter((e) => e.id !== t);
  },
  select(t) {
    this.state.selected = t;
  }
};
let O = () => {
};
function Oe(t, e) {
  const o = () => {
    g.select(t), O();
  }, n = () => {
    g.remove(t), O();
  }, r = {
    id: t,
    label: e,
    view: Ae(
      () => [r.label, g.state.selected === t],
      () => /* @__PURE__ */ p("tr", { key: t, class: g.state.selected === t ? "danger" : void 0 }, /* @__PURE__ */ p("td", { class: "col-md-1" }, t), /* @__PURE__ */ p("td", { class: "col-md-4" }, /* @__PURE__ */ p("a", { onClick: o }, r.label)), /* @__PURE__ */ p("td", { class: "col-md-1" }, /* @__PURE__ */ p("a", { onClick: n }, /* @__PURE__ */ p("span", { class: "glyphicon glyphicon-remove", "aria-hidden": "true" }))), /* @__PURE__ */ p("td", { class: "col-md-6" }))
    )
  };
  return r;
}
const Be = Tt((t) => (O = t, () => /* @__PURE__ */ p(z, null, g.state.rows.map((e) => e.view(e))))), He = Tt(() => {
  const t = (o) => () => {
    o(), O();
  }, e = [
    {
      id: "run",
      text: "Create 1,000 rows",
      onClick: t(() => g.run())
    },
    {
      id: "runlots",
      text: "Create 10,000 rows",
      onClick: t(() => g.runLots())
    },
    {
      id: "add",
      text: "Append 1,000 rows",
      onClick: t(() => g.add())
    },
    {
      id: "update",
      text: "Update every 10th row",
      onClick: t(() => g.update())
    },
    { id: "clear", text: "Clear", onClick: t(() => g.clear()) },
    {
      id: "swaprows",
      text: "Swap Rows",
      onClick: t(() => g.swapRows())
    }
  ];
  return () => /* @__PURE__ */ p("div", { class: "container" }, /* @__PURE__ */ p("div", { class: "jumbotron" }, /* @__PURE__ */ p("div", { class: "row" }, /* @__PURE__ */ p("div", { class: "col-md-6" }, /* @__PURE__ */ p("h1", null, 'Lithent-"keyed"')), /* @__PURE__ */ p("div", { class: "col-md-6" }, /* @__PURE__ */ p("div", { class: "row" }, e.map(({ id: o, text: n, onClick: r }) => /* @__PURE__ */ p("div", { key: o, class: "col-sm-6 smallpad" }, /* @__PURE__ */ p(
    "button",
    {
      type: "button",
      class: "btn btn-primary btn-block",
      id: o,
      onClick: r
    },
    n
  ))))))), /* @__PURE__ */ p("table", { class: "table table-hover table-striped test-data" }, /* @__PURE__ */ p("tbody", { id: "tbody" }, /* @__PURE__ */ p(Be, null))), /* @__PURE__ */ p("span", { class: "preloadicon glyphicon glyphicon-remove", "aria-hidden": "true" }));
});
let T = te(/* @__PURE__ */ p(He, null), document.getElementById("main"));
const je = () => {
  T == null || T(), T = void 0;
};
export {
  je as disposeRoot
};
//# sourceMappingURL=main.mjs.map
