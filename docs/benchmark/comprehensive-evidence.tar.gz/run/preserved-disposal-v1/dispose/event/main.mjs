const Ke = Symbol.for("lithentWDomSymbol"), k = { value: "" }, m = { value: null }, b = { value: !1 }, g = /* @__PURE__ */ new WeakMap(), Ue = /* @__PURE__ */ new WeakSet(), qe = (e, t) => {
  g.set(e, {
    ctor: t,
    vd: { value: null },
    up: () => {
    },
    upR: [],
    upS: { value: 0 },
    upD: [],
    upCB: [],
    mts: [],
    umts: [],
    wdCB: []
    // WDom creation callback queue
  });
}, ye = () => g.get(m.value), ze = (e) => {
  m.value = e;
}, Ie = (e, t) => {
  m.value = e, qe(e, t);
}, We = (e) => {
  const t = g.get(e);
  t && (t.umts.forEach((o) => o()), t.umts = []);
}, w = (e) => e.getParent && e.getParent(), j = (e) => () => e, re = Object.keys, ge = (e, t) => Object.prototype.propertyIsEnumerable.call(e, t), me = (e, t) => {
  if (ge(e, t)) return !0;
  const o = Object.getPrototypeOf(e);
  return !Object.prototype.hasOwnProperty.call(e, t) && !!o && me(o, t);
}, H = (e) => typeof e == "object" && e !== null, $e = (e, t) => "ctor" in e ? e.ctor === (t && t.ctor) : e === (t && t.ctor), Fe = (e, t) => t.type === "f" && // A component's node is a one-child fragment too: never update it in
// place as a plain fragment, or the component is never unmounted, nor
// update a plain fragment with one (a hoisted <Comp /> first drawn by a
// redraw), or it is never mounted.
!t.ctor && !e.ctor && !!t.children && t.children.length === (e.children && e.children.length), Ve = (e, t) => t.type === "e" && t.tag === e.tag && !!t.children && t.children.length === (e.children && e.children.length), le = (e, t) => t.type === e.type, Ge = (e, t) => t.type === e.type && (V(e) && V(t) || !!t.children && t.children.length === (e.children && e.children.length)), $ = (e) => (e && e.compProps && e.compProps.key) ?? (e && e.props && e.props.key), P = (e) => e === "f" || e === "l", K = (e) => typeof e == "function" && !we(e) || H(e) && "resolve" in e, we = (e) => e === z, Je = (e) => !e.type, F = (e) => e[0] === "o" && e[1] === "n", Y = (e) => M($(e)), V = (e) => !!e && !!e.children && e.children.some(Y), M = (e) => e != null, se = (e, t) => e === "style" && H(t), Xe = (e, t) => e === "ref" && H(t), ce = /* @__PURE__ */ new WeakMap(), ae = (e, t) => {
  const o = e.constructor.prototype;
  let n = ce.get(o);
  n || ce.set(o, n = /* @__PURE__ */ new Map());
  let r = n.get(t);
  if (r === void 0) {
    const l = Object.getOwnPropertyDescriptor(o, t);
    r = !!(l && l.get && l.set), n.set(t, r);
  }
  return r;
}, ie = (e) => e.localName.includes("-") && e.constructor === HTMLElement, Ye = (e) => K(e) ? "c" : e.type || "et", Ze = {
  c: $e,
  l: Ge,
  t: le,
  e: Ve,
  f: Fe,
  et: le
}, N = Symbol(), I = Symbol();
function G(e) {
  var t;
  const o = (t = this[N]) == null ? void 0 : t["on" + e.type];
  typeof o == "function" ? o.call(this, e) : o && o.handleEvent(e);
}
const be = (e, t, o) => {
  const n = t.slice(2).toLowerCase(), r = "on" + n, l = e[N];
  l && l[r] === o ? (delete l[r], e.removeEventListener(n, G)) : e.removeEventListener(n, o);
}, de = (e, t, o, n) => {
  var r;
  if (n === o) return;
  const l = t.slice(2).toLowerCase(), c = "on" + l, s = e[N] || (e[N] = {}), a = s[c];
  (r = s[I]) != null && r.has(c) ? (n && be(e, t, n), o && o !== s[c] && e.addEventListener(l, o)) : o ? a && a !== n && a !== o ? ((s[I] || (s[I] = /* @__PURE__ */ new Set())).add(c), e.addEventListener(l, o)) : (s[c] = o, a || e.addEventListener(l, G)) : a && a === n && (delete s[c], e.removeEventListener(l, G));
}, Ee = (e) => {
  const t = ye();
  t && t.umts.push(e);
}, U = (e) => {
  const { compKey: t } = e;
  t && (e.il = !0, Qe(t)), Ce(e);
}, Ce = (e) => {
  if (e.tag === "portal" && e.el)
    for (const t in e.props)
      F(t) && be(
        e.el,
        t,
        e.props[t]
      );
  (e.children || []).forEach((t) => {
    t.compKey ? U(t) : Ce(t);
  });
}, Qe = (e) => {
  We(e), g.delete(e);
};
let J = [];
const _e = (e) => {
  e.compKey && J.push(e);
}, x = () => {
  J.forEach(et), J = [];
}, et = (e) => {
  const { compKey: t } = e, o = t && g.get(t);
  if (o) {
    const n = o.mts;
    m.value = t, o.upS.value = 0, o.mts = [], n.forEach((r) => {
      const l = r();
      l && Ee(l);
    });
  }
}, tt = (e) => {
  const { compKey: t } = e;
  if (t) {
    const o = g.get(t), n = o && o.wdCB;
    m.value = t, n && n.length > 0 && (o.wdCB = [], n.forEach((r) => {
      const l = r();
      typeof l == "function" && Ee(l);
    }));
  }
}, ot = (e) => {
  const { compKey: t } = e, o = t && g.get(t);
  if (o) {
    const n = o.upCB;
    m.value = t, o.upS.value = 0, e.ctor && (o.upCB = [], n.forEach((r) => r()));
  }
}, Se = () => new DocumentFragment(), ke = (e, t, o) => o ? e.insertBefore(t, o) : e.tagName === "HTML" ? e.replaceWith(t) : e.appendChild(t), nt = (e) => document.createElement(e), rt = (e, t, o, n) => {
  e.isRoot = !0, t = t || document.body, e.we = t;
  const r = R(e, n);
  return e.ae = o, ke(t, r, o), x(), () => {
    const l = g.get(e.compProps), c = l && l.vd.value || e;
    U(c), lt(c);
  };
}, lt = (e) => Q(e, e.we), Z = (e) => {
  const t = w(e);
  Q(
    e,
    e.isRoot ? e.we : t && C(t)
  );
}, Q = (e, t) => {
  if (t && e.el) {
    const o = e.el.nodeType;
    o === 11 || e.tag === "portal" ? xe(e, t) : (o === 1 || o === 3) && t.removeChild(e.el), e.el = void 0;
  }
}, xe = (e, t) => {
  const o = e.oc || e.children || [];
  if (o.length > 1 && o.every((n) => {
    const r = n.el && n.el.nodeType;
    return (r === 1 || r === 3) && n.el.tagName !== "HTML" && n.tag !== "portal";
  })) {
    let n = 0;
    for (let r = t.firstChild; r && n <= o.length; r = r.nextSibling)
      n++;
    if (n === o.length) {
      t.textContent = "", o.forEach((r) => r.el = void 0);
      return;
    }
  }
  o.forEach((n) => {
    const r = n.el && n.el.nodeType;
    if (r)
      if (r === 1 || r === 3) {
        const l = n.el;
        l.tagName === "HTML" ? l.innerHTML = "" : l.remove();
      } else r === 11 && xe(n, t);
  });
}, st = (e, t) => {
  const o = C(t);
  e.forEach((n) => {
    U(n), Q(n, o);
  });
}, Pe = (e) => {
  Z(e), Re(e);
}, Re = (e, t) => {
  t = t || R(e);
  const o = w(e);
  if (!o || !o.type) {
    e.isRoot && e.we && e.tag !== "portal" && (ke(e.we, t, e.ae), x());
    return;
  }
  const n = C(o), r = _(e, o);
  n && (e.tag !== "portal" && n.insertBefore(t, r || null), x());
}, Le = (e) => P(e.type) ? (e.children || []).reduce((t, o) => {
  const n = Le(o);
  return n && t.appendChild(n), t;
}, Se()) : e.el, _ = (e, t) => {
  const o = t.children || [];
  return D(o.slice(o.indexOf(e) + 1)) || (P(t.type) ? t.isRoot ? t.ae : _(t, w(t)) : void 0);
}, A = /* @__PURE__ */ new Set(), D = (e) => e.reduce(
  (t, o) => {
    if (t || A.size && A.has(o)) return t;
    const { type: n, el: r } = o;
    if (n && P(n)) {
      const l = D(o.children || []);
      if (l) return l;
    }
    return r && r.nodeType !== 11 ? r : t;
  },
  void 0
), ct = (e) => {
  const t = w(e), o = e.el;
  if (o && (t ? t.type : e.isRoot))
    if (!t || o.nodeType === 11)
      Pe(e);
    else {
      const n = C(t), r = R(e);
      n && e.tag !== "portal" && n.replaceChild(r, o), x();
    }
}, pe = (e) => {
  if (e.type === "t") {
    pt(e);
    return;
  }
  if (e.el) {
    const { op: t, props: o } = e;
    Me(o, e.el, t), e.tag === "input" && (e.el.value = String(
      o && o.value || ""
    ));
  }
  at(e), ot(e);
}, at = (e) => {
  const t = e.children || [];
  if (e.type !== "l" || !t.some(
    (i) => "ATS".includes(i.nr) || i.oi !== void 0
  )) {
    t.forEach(X);
    return;
  }
  const o = [], n = [], r = [];
  let l = !0;
  t.forEach((i, u) => {
    const v = i.oi, S = i.nr;
    S === "S" ? r.push(i) : S !== "A" && v !== void 0 && (v < n[n.length - 1] && (l = !1), o.push(u), n.push(v));
  });
  let c;
  if (!l) {
    const i = c = [];
    it(n).forEach((u) => i[o[u]] = !0), o.forEach(
      (u) => i[u] || (i[u] = !1, r.push(t[u]))
    );
  }
  const s = [];
  let a = 0;
  r.forEach((i) => A.add(i));
  try {
    t.forEach((i, u) => {
      const v = i.nr;
      v === "A" || v === "S" ? (v === "S" && Z(i), s[u] = R(i), a++) : X(i);
    });
  } finally {
    r.forEach((i) => A.delete(i));
  }
  const p = C(e), f = e.isRoot ? e.ae : _(e, w(e));
  let h = t.length;
  for (; h > 0 && s[h - 1] !== void 0; )
    h--;
  for (let i = h; i < t.length; i++) {
    const u = s[i];
    u && p && t[i].tag !== "portal" && p.insertBefore(u, f || null);
  }
  if (c || a > t.length - h) {
    let i = D(t.slice(h)) || f;
    for (let u = h - 1; u >= 0; u--) {
      const v = t[u], S = s[u] !== void 0, He = !!c && c[u] === !1;
      if ((S || He) && p && v.tag !== "portal") {
        const ne = S ? s[u] : Le(v);
        ne && p.insertBefore(ne, i || null);
      }
      const oe = D([v]);
      oe && (i = oe);
    }
  }
  t.forEach(Te), x();
}, Te = (e) => {
  e.oi = e.oc = e.op = void 0, e.nr = "N";
}, it = (e) => {
  const t = [], o = [];
  e.forEach((l, c) => {
    let s = 0, a = t.length;
    if (a && e[t[a - 1]] < l)
      s = a;
    else
      for (; s < a; ) {
        const p = s + a >> 1;
        e[t[p]] < l ? s = p + 1 : a = p;
      }
    o[c] = s ? t[s - 1] : -1, t[s] = c;
  });
  let n = t.length, r = t[n - 1];
  for (; n-- > 0; )
    t[n] = r, r = o[r];
  return t;
}, X = (e) => {
  const { nr: t } = e;
  t && t !== "N" && (dt[t](e), Te(e));
}, dt = {
  A: Re,
  D: Z,
  R: ct,
  U: pe,
  S: Pe,
  // A keyed item reaches here only as a component redrawing itself: it has
  // not moved, so it is updated in place. Re-inserting its nodes would blur a
  // focused input inside it or reload an iframe. Moves within a list are
  // placed by updateChildren.
  T: pe
}, pt = (e) => {
  e.el && (e.el.nodeValue = String(e.text));
}, Me = (e, t, o) => {
  const n = o || {};
  for (const r in e) {
    const l = e[r];
    l !== n[r] && (F(r) ? de(
      t,
      r,
      l,
      n[r]
    ) : r === "key" || r === "portal" && H(l) || (r === "innerHTML" && typeof l == "string" ? t.innerHTML = l : se(r, l) ? ft(
      l,
      se(r, n.style) ? n.style : {},
      t
    ) : Xe(r, l) ? l.value = t : r && (r !== "type" && ae(t, r) ? t[r] = l : (ut(
      r === "className" ? "class" : r,
      t,
      l
    ), ie(t) && !(r in HTMLElement.prototype) && (t[r] = l)))));
  }
  for (const r in n)
    if (!(e && me(e, r))) {
      if (F(r)) {
        de(
          t,
          r,
          void 0,
          n[r]
        );
        continue;
      }
      t.removeAttribute(r), ie(t) ? delete t[r] : t.localName.includes("-") && ae(t, r) && (t[r] = void 0);
    }
}, ut = (e, t, o) => k.value && e !== "xmlns" ? t.setAttributeNS(null, e, o) : t.setAttribute(e, o), R = (e, t) => {
  let o;
  const { type: n, tag: r, text: l, props: c, children: s = [] } = e, a = P(n);
  if (tt(e), r === "svg" && (k.value = String(c && c.xmlns)), !t) {
    if (!n || a)
      o = Se();
    else if (n === "e" && r)
      r === "portal" && c && c.portal ? o = c.portal : o = k.value ? document.createElementNS(k.value, r) : nt(r);
    else if (n === "t" && M(l))
      o = document.createTextNode(String(l));
    else
      throw Error("Invalid wDom");
    e.el = o;
  }
  return ht(e, s, o, t), Me(c, o, null), _e(e), r === "svg" && (k.value = ""), o;
}, ht = (e, t, o, n) => {
  const r = j(e);
  t.forEach((l, c) => {
    if (l.nr === "N" && !n) {
      const s = Oe(l);
      l = t[c] = "resolve" in s ? s.resolve() : s;
    }
    if (l.getParent = r, l.nr = "N", l.type) {
      const s = R(l, n);
      l.tag !== "portal" && !n && o && o.appendChild(s);
    }
  });
}, ft = (e, t, o) => {
  const n = { ...t };
  if (!(o instanceof HTMLElement)) return;
  const r = o.style;
  for (const l in e)
    r[l] = e[l], delete n[l];
  for (const l in n)
    r[l] = "";
}, C = (e) => P(e.type) ? e.isRoot ? e.we : C(w(e)) : e.el, q = (e, t) => (e !== t && e.nr && (e = Oe(e)), vt(
  e,
  !!t && Ze[Ye(e)](e, t),
  t
)), vt = (e, t, o) => {
  const n = bt(e, t, o), r = gt(
    n,
    t,
    o
  ), l = r === "N";
  return l || (n.children = Et(
    n,
    t,
    o
  )), n.nr = r, yt(n, o, r), !l && o && (o.il = !0, o.ctor && (o.children = void 0)), o && o.tag === "portal" && (n.tag = "portal"), n;
}, yt = (e, t, o) => {
  o !== "A" && t && (e.el = t.el), (o === "D" || o === "R" || o === "S") && (t && U(t), e.oc = t && t.children), e.op = t && t.props;
}, gt = (e, t, o) => {
  if (Je(e)) return "D";
  if (e === o || t && e.type === "t" && e.text === o.text)
    return "N";
  if (!(o && o.type)) return "A";
  const n = w(o), r = !e.isRoot && n && n.type === "l" && Y(e);
  return t ? r ? "T" : "U" : r ? "S" : "R";
}, mt = (e, t) => {
  e && t !== e && (t = t || {}, re(e).forEach(
    (o) => ge(t, o) || delete e[o]
  ), re(t).forEach((o) => e[o] = t[o]));
}, wt = (e, t) => {
  const { compProps: o, compChild: n } = e, { props: r, children: l } = t;
  return o && mt(o, r), n && l && n !== l && n.splice(0, n.length, ...l), e.reRender && e.reRender();
}, bt = (e, t, o) => K(e) ? t && o ? wt(o, e) : (
  // Resolved before (children a component draws again somewhere else):
  // the first instance owns its props, which are also its key, so the
  // new instance is made from a copy.
  (e.rd ? ee(e) : (e.rd = !0, e)).resolve()
) : e, Et = (e, t, o) => t && o ? St(e, o) : Ct(e), Ct = (e) => {
  const t = j(e);
  return (e.children || []).map((o) => {
    const n = q(o);
    return n.getParent = t, n;
  });
}, St = (e, t) => {
  if (e.type === "l" && V(e))
    return kt(e, t);
  const o = t.children || [], n = j(e);
  return (e.children || []).map((r, l) => {
    const c = q(r, o[l]);
    return c.getParent = n, c;
  });
}, kt = (e, t) => {
  const o = t.children || [], n = /* @__PURE__ */ new Map();
  o.forEach((s, a) => {
    const p = $(s);
    M(p) && !n.has(p) && n.set(p, a);
  });
  const r = [], l = j(e), c = (e.children || []).map((s, a) => {
    const p = $(s), f = M(p) ? n.get(p) : a < o.length && !Y(o[a]) ? a : void 0;
    let h;
    f !== void 0 && (n.delete(p), r[f] = !0, h = o[f]);
    const i = q(s, h);
    return h && (i.oi = f), i.getParent = l, i;
  });
  return st(
    o.filter((s, a) => !r[a]),
    t
  ), c;
}, T = /* @__PURE__ */ new Map();
let B = !1;
const xt = (e, t) => {
  T.set(e, t), B || (B = !0, queueMicrotask(Ne));
}, Pt = (e, t) => {
  const o = g.get(e);
  o && (o.up = () => {
    const n = o.vd.value;
    xt(e, () => t(n));
  });
}, Rt = (e) => () => {
  const t = g.get(e), o = t && t.up;
  return o ? (o(), !0) : !1;
}, Ne = () => {
  try {
    T.forEach((e, t) => {
      T.delete(t), e();
    });
  } finally {
    B = !!T.size, B && queueMicrotask(Ne);
  }
}, E = (e, t, o, n, r, l) => ({
  type: e,
  nr: void 0,
  tag: t,
  props: o,
  text: n,
  children: r,
  getParent: l,
  el: void 0,
  oi: void 0,
  oc: void 0,
  op: void 0,
  il: void 0,
  [Ke]: !0
}), Lt = () => {
  const e = ye(), t = e && e.upR;
  t && t.length && t.forEach((o) => o());
}, z = (e, ...t) => E("f", void 0, void 0, void 0, t), d = (e, t, ...o) => {
  const n = { value: void 0 }, r = De(n, o), l = Nt(e, t || {}, r);
  return K(l) || (n.value = l), l;
}, Ae = (e) => (t, o) => e, Tt = (e, t, o) => {
  const n = (r, l) => {
    if (!(!r || l.has(r))) {
      if (l.add(r), r.compChild) {
        const c = r.compChild.indexOf(t);
        c !== -1 && r.compChild.splice(c, 1, o);
      }
      n(r.getParent ? r.getParent() : void 0, l);
    }
  };
  n(e, /* @__PURE__ */ new Set());
}, Mt = (e, t, o, n) => {
  if (n.il)
    return;
  b.value = !0;
  let r;
  try {
    const l = te(e, t, o);
    r = q(l, n);
    const { isRoot: c, getParent: s, we: a, ae: p } = n;
    if (r.getParent = s, !c && s) {
      const f = s(), h = f && f.children || [], i = h.indexOf(n);
      i !== -1 && h.splice(i, 1, r), Tt(f, n, r);
    } else
      r.isRoot = !0, r.we = a, r.ae = p;
  } finally {
    b.value = !1;
  }
  X(r);
}, Nt = (e, t, o) => {
  if (we(e))
    return z(t, ...o);
  if (K(e)) {
    const n = te(e, t, o);
    if (b.value)
      return n;
    const r = ee(n).resolve();
    return r.rs = n, r;
  }
  return E("e", e, t, void 0, o);
}, De = (e, t) => {
  const o = () => e.value;
  return t.map((n) => {
    const r = Be(n);
    return r.getParent = o, r;
  });
}, Be = (e) => {
  if (e == null || typeof e == "boolean")
    return E(null);
  if (Array.isArray(e)) {
    const t = { value: void 0 }, o = De(t, e), n = E("l", void 0, void 0, void 0, o);
    return t.value = n, n;
  } else if (typeof e == "string" || typeof e == "number")
    return E("t", void 0, void 0, e);
  return e;
}, At = (e, t, o) => (n = t) => {
  const r = b.value, l = m.value;
  b.value = !1;
  try {
    Ie(n, e);
    const c = e(t, o);
    let s;
    if (typeof c == "function") {
      const a = c;
      s = Ue.has(a) ? a(t, o) : a(Rt(n), t, o);
    } else {
      let a = !0;
      s = (p) => a ? (a = !1, c) : e(p, o);
    }
    return Dt(
      s,
      n,
      e,
      t,
      o
    );
  } finally {
    m.value = l, b.value = r;
  }
}, Oe = (e) => e.ctor ? ee(
  e.rs || {
    ctor: e.ctor,
    props: e.compProps,
    children: e.compChild
  }
) : E(
  e.type,
  e.tag,
  e.props,
  e.text,
  e.children && [...e.children],
  e.getParent
), ee = ({
  ctor: e,
  props: t,
  children: o
}) => te(e, { ...t }, [...o || []]), te = (e, t, o) => ({
  ctor: e,
  props: t,
  children: o,
  resolve: At(e, t, o)
}), Dt = (e, t, o, n, r) => {
  const l = Ot(e), c = l(n), s = Bt(
    l,
    t,
    o,
    n,
    r
  );
  return je(c, t, o, n, r, s), Pt(
    t,
    (a) => Mt(
      o,
      a.compProps || n,
      a.compChild || r,
      a
    )
  ), c;
}, Bt = (e, t, o, n, r) => {
  const l = () => {
    const c = m.value;
    try {
      ze(t), Lt();
      const s = e(n);
      return je(s, t, o, n, r, l), s;
    } finally {
      m.value = c;
    }
  };
  return l;
}, Ot = (e) => (t) => {
  const o = Be(e(t)), n = z({}, o);
  return o.getParent = () => n, n;
}, je = (e, t, o, n, r, l) => {
  e.compProps = n, e.compChild = r, e.ctor = o, e.compKey = t, e.reRender = l;
  const c = g.get(t);
  c && (c.vd.value = e);
}, jt = (e, t) => {
  let o = [], n = null;
  return (r) => {
    const l = e(), c = o.length === l.length && o.every((a, p) => a === l[p]);
    if (o = l, c && n)
      return n;
    const s = t(r);
    return n = s, s;
  };
}, ue = [
  "pretty",
  "large",
  "big",
  "small",
  "tall",
  "short",
  "long",
  "handsome",
  "plain",
  "quaint",
  "clean",
  "elegant",
  "easy",
  "angry",
  "crazy",
  "helpful",
  "mushy",
  "odd",
  "unsightly",
  "adorable",
  "important",
  "inexpensive",
  "cheap",
  "expensive",
  "fancy"
], he = [
  "red",
  "yellow",
  "blue",
  "green",
  "pink",
  "brown",
  "purple",
  "brown",
  "white",
  "black",
  "orange"
], fe = [
  "table",
  "chair",
  "house",
  "bbq",
  "desk",
  "car",
  "pony",
  "cookie",
  "sandwich",
  "burger",
  "pizza",
  "mouse",
  "keyboard"
], W = (e) => Math.round(Math.random() * 1e3) % e, Ht = () => `${ue[W(ue.length)]} ${he[W(he.length)]} ${fe[W(fe.length)]}`;
let ve = 1;
const y = {
  state: { rows: [], selected: null },
  buildData(e) {
    const t = new Array(e);
    for (let o = 0; o < e; o += 1)
      t[o] = Kt(ve, Ht()), ve += 1;
    return t;
  },
  run() {
    this.state.rows = this.buildData(1e3);
  },
  runLots() {
    this.state.rows = this.buildData(1e4);
  },
  add() {
    this.state.rows = this.state.rows.concat(this.buildData(1e3));
  },
  update() {
    const { rows: e } = this.state;
    for (let t = 0; t < e.length; t += 10)
      e[t].label += " !!!";
  },
  clear() {
    this.state.rows = [], this.state.selected = null;
  },
  swapRows() {
    const { rows: e } = this.state;
    if (e.length > 998) {
      const t = e[1];
      e[1] = e[998], e[998] = t;
    }
  },
  remove(e) {
    this.state.rows = this.state.rows.filter((t) => t.id !== e);
  },
  select(e) {
    this.state.selected = e;
  }
};
let O = () => {
};
function Kt(e, t) {
  const o = () => {
    y.select(e), O();
  }, n = () => {
    y.remove(e), O();
  }, r = {
    id: e,
    label: t,
    view: jt(
      () => [r.label, y.state.selected === e],
      () => /* @__PURE__ */ d("tr", { key: e, class: y.state.selected === e ? "danger" : void 0 }, /* @__PURE__ */ d("td", { class: "col-md-1" }, e), /* @__PURE__ */ d("td", { class: "col-md-4" }, /* @__PURE__ */ d("a", { onClick: o }, r.label)), /* @__PURE__ */ d("td", { class: "col-md-1" }, /* @__PURE__ */ d("a", { onClick: n }, /* @__PURE__ */ d("span", { class: "glyphicon glyphicon-remove", "aria-hidden": "true" }))), /* @__PURE__ */ d("td", { class: "col-md-6" }))
    )
  };
  return r;
}
const Ut = Ae((e) => (O = e, () => /* @__PURE__ */ d(z, null, y.state.rows.map((t) => t.view(t))))), qt = Ae(() => {
  const e = (o) => () => {
    o(), O();
  }, t = [
    {
      id: "run",
      text: "Create 1,000 rows",
      onClick: e(() => y.run())
    },
    {
      id: "runlots",
      text: "Create 10,000 rows",
      onClick: e(() => y.runLots())
    },
    {
      id: "add",
      text: "Append 1,000 rows",
      onClick: e(() => y.add())
    },
    {
      id: "update",
      text: "Update every 10th row",
      onClick: e(() => y.update())
    },
    { id: "clear", text: "Clear", onClick: e(() => y.clear()) },
    {
      id: "swaprows",
      text: "Swap Rows",
      onClick: e(() => y.swapRows())
    }
  ];
  return () => /* @__PURE__ */ d("div", { class: "container" }, /* @__PURE__ */ d("div", { class: "jumbotron" }, /* @__PURE__ */ d("div", { class: "row" }, /* @__PURE__ */ d("div", { class: "col-md-6" }, /* @__PURE__ */ d("h1", null, 'Lithent-"keyed"')), /* @__PURE__ */ d("div", { class: "col-md-6" }, /* @__PURE__ */ d("div", { class: "row" }, t.map(({ id: o, text: n, onClick: r }) => /* @__PURE__ */ d("div", { key: o, class: "col-sm-6 smallpad" }, /* @__PURE__ */ d(
    "button",
    {
      type: "button",
      class: "btn btn-primary btn-block",
      id: o,
      onClick: r
    },
    n
  ))))))), /* @__PURE__ */ d("table", { class: "table table-hover table-striped test-data" }, /* @__PURE__ */ d("tbody", { id: "tbody" }, /* @__PURE__ */ d(Ut, null))), /* @__PURE__ */ d("span", { class: "preloadicon glyphicon glyphicon-remove", "aria-hidden": "true" }));
});
let L = rt(/* @__PURE__ */ d(qt, null), document.getElementById("main"));
const zt = () => {
  L == null || L(), L = void 0;
};
export {
  zt as disposeRoot
};
//# sourceMappingURL=main.mjs.map
