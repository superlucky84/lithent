import { createRequire } from 'node:module';
const require=createRequire(import.meta.url);
export const load=async name=>({imported:await import(name),required:require(name)});
