const re = Symbol.for("lithentWDomSymbol"), M = { value: "" }, y = { value: null }, k = { value: !1 }, p = /* @__PURE__ */ new WeakMap(), le = /* @__PURE__ */ new WeakSet();
let ue = !1;
const Ae = (e, t) => {
  p.set(e, {
    ctor: t,
    vd: { value: null },
    up: () => {
    },
    upR: [],
    upS: { value: 0 },
    upD: [],
    upCB: [],
    mts: [],
    umts: [],
    wdCB: []
    // WDom creation callback queue
  });
}, Le = () => y.value, P = () => p.get(y.value), Nt = (e, t) => {
  const n = p.get(e);
  return n ? n[t] : null;
}, Oe = (e) => {
  y.value = e;
}, Ue = (e, t) => {
  y.value = e, Ae(e, t);
}, Tt = (e) => {
  ue = e;
}, Be = () => ue, ie = (e) => {
  const t = p.get(e);
  t && (t.umts.forEach((n) => n()), t.umts = []);
}, Ft = (e) => {
  ie(e), p.delete(e);
}, C = (e) => e.getParent && e.getParent(), U = (e) => () => e, w = Object.keys, ae = (e, t) => Object.prototype.propertyIsEnumerable.call(e, t), fe = (e, t) => {
  if (ae(e, t)) return !0;
  const n = Object.getPrototypeOf(e);
  return !Object.prototype.hasOwnProperty.call(e, t) && !!n && fe(n, t);
}, b = (e) => typeof e == "object" && e !== null, At = (e) => b(e) && !Array.isArray(e) && !Object.getOwnPropertySymbols(e).includes(re), Qe = (e, t) => "ctor" in e ? e.ctor === (t && t.ctor) : e === (t && t.ctor), Ke = (e, t) => t.type === "f" && // A component's node is a one-child fragment too: never update it in
// place as a plain fragment, or the component is never unmounted, nor
// update a plain fragment with one (a hoisted <Comp /> first drawn by a
// redraw), or it is never mounted.
!t.ctor && !e.ctor && !!t.children && t.children.length === (e.children && e.children.length), je = (e, t) => t.type === "e" && t.tag === e.tag && !!t.children && t.children.length === (e.children && e.children.length), W = (e, t) => t.type === e.type, _e = (e, t) => t.type === e.type && (H(e) && H(t) || !!t.children && t.children.length === (e.children && e.children.length)), j = (e) => (e && e.compProps && e.compProps.key) ?? (e && e.props && e.props.key), x = (e) => e === "f" || e === "l", B = (e) => typeof e == "function" && !de(e) || b(e) && "resolve" in e, de = (e) => e === X, He = (e) => !e.type, _ = (e) => e[0] === "o" && e[1] === "n", z = (e) => F(j(e)), H = (e) => !!e && !!e.children && e.children.some(z), F = (e) => e != null, D = (e, t) => e === "style" && b(t), Ve = (e, t) => e === "ref" && b(t), ee = /* @__PURE__ */ new WeakMap(), te = (e, t) => {
  const n = e.constructor.prototype;
  let c = ee.get(n);
  c || ee.set(n, c = /* @__PURE__ */ new Map());
  let o = c.get(t);
  if (o === void 0) {
    const s = Object.getOwnPropertyDescriptor(n, t);
    o = !!(s && s.get && s.set), c.set(t, o);
  }
  return o;
}, ne = (e) => e.localName.includes("-") && e.constructor === HTMLElement, qe = (e) => B(e) ? "c" : e.type || "et", ze = {
  c: Qe,
  l: _e,
  t: W,
  e: je,
  f: Ke,
  et: W
}, pe = (e) => {
  const t = P();
  t && t.umts.push(e);
}, Q = (e) => {
  const { compKey: t } = e;
  t && (e.il = !0, Ge(t)), he(e);
}, he = (e) => {
  if (e.tag === "portal" && e.el)
    for (const t in e.props)
      _(t) && e.el.removeEventListener(
        t.slice(2).toLowerCase(),
        e.props[t]
      );
  (e.children || []).forEach((t) => {
    t.compKey ? Q(t) : he(t);
  });
}, Ge = (e) => {
  ie(e), Be() || p.delete(e);
};
let V = [];
const Ie = (e) => {
  e.compKey && V.push(e);
}, S = () => {
  V.forEach(Je), V = [];
}, Lt = (e) => {
  const t = P();
  t && t.mts.push(e);
}, Je = (e) => {
  const { compKey: t } = e, n = t && p.get(t);
  if (n) {
    const c = n.mts;
    y.value = t, n.upS.value = 0, n.mts = [], c.forEach((o) => {
      const s = o();
      s && pe(s);
    });
  }
}, Ot = (e) => {
  const t = P();
  t && t.wdCB.push(e);
}, Xe = (e) => {
  const { compKey: t } = e;
  if (t) {
    const n = p.get(t), c = n && n.wdCB;
    y.value = t, c && c.length > 0 && (n.wdCB = [], c.forEach((o) => {
      const s = o();
      typeof s == "function" && pe(s);
    }));
  }
}, ce = (e, t = () => []) => {
  const n = P();
  if (!n) return;
  const { upD: c, upS: o } = n, s = c[o.value], r = t();
  if (s && Ze(s, r)) {
    const l = e();
    l && n.upCB.push(l);
  }
  c[o.value] = r, o.value += 1;
}, Ye = (e) => {
  const { compKey: t } = e, n = t && p.get(t);
  if (n) {
    const c = n.upCB;
    y.value = t, n.upS.value = 0, e.ctor && (n.upCB = [], c.forEach((o) => o()));
  }
}, Ze = (e, t) => e.length ? e.some((n, c) => n !== t[c]) : !0, ve = () => new DocumentFragment(), ye = (e, t, n) => n ? e.insertBefore(t, n) : e.tagName === "HTML" ? e.replaceWith(t) : e.appendChild(t), $e = (e) => document.createElement(e), Ut = (e, t, n, c) => {
  e.isRoot = !0, t = t || document.body, e.we = t;
  const o = N(e, c);
  return e.ae = n, (n || !c) && ye(t, o, n), S(), () => {
    const s = p.get(e.compProps), r = s && s.vd.value || e;
    Q(r), me(r);
  };
}, me = (e) => I(e, e.we), G = (e) => {
  const t = C(e);
  I(
    e,
    e.isRoot ? e.we : t && g(t)
  );
}, I = (e, t) => {
  if (t && e.el) {
    const n = e.el.nodeType;
    n === 11 || e.tag === "portal" ? Ce(e, t) : (n === 1 || n === 3) && t.removeChild(e.el), e.el = void 0;
  }
}, Ce = (e, t) => {
  const n = e.oc || e.children || [];
  if (n.length > 1 && n.every((c) => {
    const o = c.el && c.el.nodeType;
    return (o === 1 || o === 3) && c.el.tagName !== "HTML" && c.tag !== "portal";
  })) {
    let c = 0;
    for (let o = t.firstChild; o && c <= n.length; o = o.nextSibling)
      c++;
    if (c === n.length) {
      t.textContent = "", n.forEach((o) => o.el = void 0);
      return;
    }
  }
  n.forEach((c) => {
    const o = c.el && c.el.nodeType;
    if (o)
      if (o === 1 || o === 3) {
        const s = c.el;
        s.tagName === "HTML" ? s.innerHTML = "" : s.remove();
      } else o === 11 && Ce(c, t);
  });
}, we = (e, t) => {
  const n = g(t);
  e.forEach((c) => {
    Q(c), I(c, n);
  });
}, ke = (e) => {
  G(e), Re(e);
}, Re = (e, t) => {
  t = t || N(e);
  const n = C(e);
  if (!n || !n.type) {
    e.isRoot && e.we && e.tag !== "portal" && (ye(e.we, t, e.ae), S());
    return;
  }
  const c = g(n), o = J(e, n);
  c && (e.tag !== "portal" && c.insertBefore(t, o || null), S());
}, Pe = (e) => x(e.type) ? (e.children || []).reduce((t, n) => {
  const c = Pe(n);
  return c && t.appendChild(c), t;
}, ve()) : e.el, J = (e, t) => {
  const n = t.children || [];
  return L(n.slice(n.indexOf(e) + 1)) || (x(t.type) ? t.isRoot ? t.ae : J(t, C(t)) : void 0);
}, A = /* @__PURE__ */ new Set(), L = (e) => e.reduce(
  (t, n) => {
    if (t || A.size && A.has(n)) return t;
    const { type: c, el: o } = n;
    if (c && x(c)) {
      const s = L(n.children || []);
      if (s) return s;
    }
    return o && o.nodeType !== 11 ? o : t;
  },
  void 0
), We = (e) => {
  const t = C(e), n = e.el;
  if (n && (t ? t.type : e.isRoot))
    if (!t || n.nodeType === 11)
      ke(e);
    else {
      const c = g(t), o = N(e);
      c && e.tag !== "portal" && c.replaceChild(o, n), S();
    }
}, oe = (e) => {
  if (e.type === "t") {
    nt(e);
    return;
  }
  if (e.el) {
    const { op: t, props: n } = e;
    Ee(n, e.el, t), e.tag === "input" && (e.el.value = String(
      n && n.value || ""
    ));
  }
  De(e), Ye(e);
}, De = (e) => {
  const t = e.children || [];
  if (e.type !== "l" || !t.some(
    (u) => "ATS".includes(u.nr) || u.oi !== void 0
  )) {
    t.forEach(q);
    return;
  }
  const n = [], c = [], o = [];
  let s = !0;
  t.forEach((u, f) => {
    const v = u.oi, E = u.nr;
    E === "S" ? o.push(u) : E !== "A" && v !== void 0 && (v < c[c.length - 1] && (s = !1), n.push(f), c.push(v));
  });
  let r;
  if (!s) {
    const u = r = [];
    et(c).forEach((f) => u[n[f]] = !0), n.forEach(
      (f) => u[f] || (u[f] = !1, o.push(t[f]))
    );
  }
  const l = [];
  let i = 0;
  o.forEach((u) => A.add(u));
  try {
    t.forEach((u, f) => {
      const v = u.nr;
      v === "A" || v === "S" ? (v === "S" && G(u), l[f] = N(u), i++) : q(u);
    });
  } finally {
    o.forEach((u) => A.delete(u));
  }
  const a = g(e), h = e.isRoot ? e.ae : J(e, C(e));
  let d = t.length;
  for (; d > 0 && l[d - 1] !== void 0; )
    d--;
  for (let u = d; u < t.length; u++) {
    const f = l[u];
    f && a && t[u].tag !== "portal" && a.insertBefore(f, h || null);
  }
  if (r || i > t.length - d) {
    let u = L(t.slice(d)) || h;
    for (let f = d - 1; f >= 0; f--) {
      const v = t[f], E = l[f] !== void 0, Fe = !!r && r[f] === !1;
      if ((E || Fe) && a && v.tag !== "portal") {
        const m = E ? l[f] : Pe(v);
        m && a.insertBefore(m, u || null);
      }
      const $ = L([v]);
      $ && (u = $);
    }
  }
  t.forEach(ge), S();
}, ge = (e) => {
  e.oi = e.oc = e.op = void 0, e.nr = "N";
}, et = (e) => {
  const t = [], n = [];
  e.forEach((s, r) => {
    let l = 0, i = t.length;
    if (i && e[t[i - 1]] < s)
      l = i;
    else
      for (; l < i; ) {
        const a = l + i >> 1;
        e[t[a]] < s ? l = a + 1 : i = a;
      }
    n[r] = l ? t[l - 1] : -1, t[l] = r;
  });
  let c = t.length, o = t[c - 1];
  for (; c-- > 0; )
    t[c] = o, o = n[o];
  return t;
}, q = (e) => {
  const { nr: t } = e;
  t && t !== "N" && (tt[t](e), ge(e));
}, tt = {
  A: Re,
  D: G,
  R: We,
  U: oe,
  S: ke,
  // A keyed item reaches here only as a component redrawing itself: it has
  // not moved, so it is updated in place. Re-inserting its nodes would blur a
  // focused input inside it or reload an iframe. Moves within a list are
  // placed by updateChildren.
  T: oe
}, nt = (e) => {
  e.el && (e.el.nodeValue = String(e.text));
}, Ee = (e, t, n) => {
  const c = n || {};
  for (const o in e) {
    const s = e[o];
    s !== c[o] && (_(o) ? se(
      t,
      o,
      s,
      c[o]
    ) : o === "key" || o === "portal" && b(s) || (o === "innerHTML" && typeof s == "string" ? t.innerHTML = s : D(o, s) ? st(
      s,
      D(o, c.style) ? c.style : {},
      t
    ) : Ve(o, s) ? s.value = t : o && (o !== "type" && te(t, o) ? t[o] = s : (ct(
      o === "className" ? "class" : o,
      t,
      s
    ), ne(t) && !(o in HTMLElement.prototype) && (t[o] = s)))));
  }
  for (const o in c)
    if (!(e && fe(e, o))) {
      if (_(o)) {
        se(
          t,
          o,
          void 0,
          c[o]
        );
        continue;
      }
      t.removeAttribute(o), ne(t) ? delete t[o] : t.localName.includes("-") && te(t, o) && (t[o] = void 0);
    }
}, ct = (e, t, n) => M.value && e !== "xmlns" ? t.setAttributeNS(null, e, n) : t.setAttribute(e, n), N = (e, t) => {
  let n;
  const { type: c, tag: o, text: s, props: r, children: l = [] } = e, i = x(c);
  if (Xe(e), o === "svg" && (M.value = String(r && r.xmlns)), t)
    n = e.el;
  else {
    if (!c || i)
      n = ve();
    else if (c === "e" && o)
      o === "portal" && r && r.portal ? n = r.portal : n = M.value ? document.createElementNS(M.value, o) : $e(o);
    else if (c === "t" && F(s))
      n = document.createTextNode(String(s));
    else
      throw Error("Invalid wDom");
    e.el = n;
  }
  return ot(e, l, n, t), Ee(r, n, null), Ie(e), o === "svg" && (M.value = ""), n;
}, ot = (e, t, n, c) => {
  const o = U(e);
  t.forEach((s, r) => {
    if (s.nr === "N" && !c) {
      const l = Ne(s);
      s = t[r] = "resolve" in l ? l.resolve() : l;
    }
    if (s.getParent = o, s.nr = "N", s.type) {
      const l = N(s, c);
      s.tag !== "portal" && !c && n && n.appendChild(l);
    }
  });
}, se = (e, t, n, c) => {
  const o = t.slice(2).toLowerCase();
  c !== n && (c && e.removeEventListener(o, c), n && e.addEventListener(o, n));
}, st = (e, t, n) => {
  const c = { ...t };
  if (!(n instanceof HTMLElement)) return;
  const o = n.style;
  for (const s in e)
    o[s] = e[s], delete c[s];
  for (const s in c)
    o[s] = "";
}, g = (e) => x(e.type) ? e.isRoot ? e.we : g(C(e)) : e.el, K = (e, t) => (e !== t && e.nr && (e = Ne(e)), rt(
  e,
  !!t && ze[qe(e)](e, t),
  t
)), rt = (e, t, n) => {
  const c = ft(e, t, n), o = ut(
    c,
    t,
    n
  ), s = o === "N";
  return s || (c.children = dt(
    c,
    t,
    n
  )), c.nr = o, lt(c, n, o), !s && n && (n.il = !0, n.ctor && (n.children = void 0)), n && n.tag === "portal" && (c.tag = "portal"), c;
}, lt = (e, t, n) => {
  n !== "A" && t && (e.el = t.el), (n === "D" || n === "R" || n === "S") && (t && Q(t), e.oc = t && t.children), e.op = t && t.props;
}, ut = (e, t, n) => {
  if (He(e)) return "D";
  if (e === n || t && e.type === "t" && e.text === n.text)
    return "N";
  if (!(n && n.type)) return "A";
  const c = C(n), o = !e.isRoot && c && c.type === "l" && z(e);
  return t ? o ? "T" : "U" : o ? "S" : "R";
}, it = (e, t) => {
  e && t !== e && (t = t || {}, w(e).forEach(
    (n) => ae(t, n) || delete e[n]
  ), w(t).forEach((n) => e[n] = t[n]));
}, at = (e, t) => {
  const { compProps: n, compChild: c } = e, { props: o, children: s } = t;
  return n && it(n, o), c && s && c !== s && c.splice(0, c.length, ...s), e.reRender && e.reRender();
}, ft = (e, t, n) => B(e) ? t && n ? at(n, e) : (
  // Resolved before (children a component draws again somewhere else):
  // the first instance owns its props, which are also its key, so the
  // new instance is made from a copy.
  (e.rd ? Y(e) : (e.rd = !0, e)).resolve()
) : e, dt = (e, t, n) => t && n ? ht(e, n) : pt(e), pt = (e) => {
  const t = U(e);
  return (e.children || []).map((n) => {
    const c = K(n);
    return c.getParent = t, c;
  });
}, ht = (e, t) => {
  if (e.type === "l" && H(e))
    return vt(e, t);
  const n = t.children || [], c = U(e);
  return (e.children || []).map((o, s) => {
    const r = K(o, n[s]);
    return r.getParent = c, r;
  });
}, vt = (e, t) => {
  const n = t.children || [], c = /* @__PURE__ */ new Map();
  n.forEach((l, i) => {
    const a = j(l);
    F(a) && !c.has(a) && c.set(a, i);
  });
  const o = [], s = U(e), r = (e.children || []).map((l, i) => {
    const a = j(l), h = F(a) ? c.get(a) : i < n.length && !z(n[i]) ? i : void 0;
    let d;
    h !== void 0 && (c.delete(a), o[h] = !0, d = n[h]);
    const u = K(l, d);
    return d && (u.oi = h), u.getParent = s, u;
  });
  return we(
    n.filter((l, i) => !o[i]),
    t
  ), r;
}, T = /* @__PURE__ */ new Map();
let O = !1;
const yt = (e, t) => {
  T.set(e, t), O || (O = !0, queueMicrotask(Se));
}, Ct = (e, t) => {
  const n = p.get(e);
  n && (n.up = () => {
    const c = n.vd.value;
    yt(e, () => t(c));
  });
}, Me = (e) => () => {
  const t = p.get(e), n = t && t.up;
  return n ? (n(), !0) : !1;
}, Se = () => {
  try {
    T.forEach((e, t) => {
      T.delete(t), e();
    });
  } finally {
    O = !!T.size, O && queueMicrotask(Se);
  }
}, R = (e, t, n, c, o, s) => ({
  type: e,
  nr: void 0,
  tag: t,
  props: n,
  text: c,
  children: o,
  getParent: s,
  el: void 0,
  oi: void 0,
  oc: void 0,
  op: void 0,
  il: void 0,
  [re]: !0
}), Bt = (e, t = () => []) => {
  const n = P();
  n && (n.upR.push(() => ce(e, t)), ce(e, t));
}, kt = () => {
  const e = P(), t = e && e.upR;
  t && t.length && t.forEach((n) => n());
}, X = (e, ...t) => R("f", void 0, void 0, void 0, t), Rt = (e, t, ...n) => {
  const c = { value: void 0 }, o = be(c, n), s = Et(e, t || {}, o);
  return B(s) || (c.value = s), s;
}, Qt = (e, t) => Rt("portal", { portal: t }, e), Kt = (e) => (t, n) => e, jt = (e) => (t, n) => (le.add(e), e), Pt = (e, t, n) => {
  const c = (o, s) => {
    if (!(!o || s.has(o))) {
      if (s.add(o), o.compChild) {
        const r = o.compChild.indexOf(t);
        r !== -1 && o.compChild.splice(r, 1, n);
      }
      c(o.getParent ? o.getParent() : void 0, s);
    }
  };
  c(e, /* @__PURE__ */ new Set());
}, gt = (e, t, n, c) => {
  if (c.il)
    return;
  k.value = !0;
  let o;
  try {
    const s = Z(e, t, n);
    o = K(s, c);
    const { isRoot: r, getParent: l, we: i, ae: a } = c;
    if (o.getParent = l, !r && l) {
      const h = l(), d = h && h.children || [], u = d.indexOf(c);
      u !== -1 && d.splice(u, 1, o), Pt(h, c, o);
    } else
      o.isRoot = !0, o.we = i, o.ae = a;
  } finally {
    k.value = !1;
  }
  q(o);
}, Et = (e, t, n) => {
  if (de(e))
    return X(t, ...n);
  if (B(e)) {
    const c = Z(e, t, n);
    if (k.value)
      return c;
    const o = Y(c).resolve();
    return o.rs = c, o;
  }
  return R("e", e, t, void 0, n);
}, be = (e, t) => {
  const n = () => e.value;
  return t.map((c) => {
    const o = xe(c);
    return o.getParent = n, o;
  });
}, xe = (e) => {
  if (e == null || typeof e == "boolean")
    return R(null);
  if (Array.isArray(e)) {
    const t = { value: void 0 }, n = be(t, e), c = R("l", void 0, void 0, void 0, n);
    return t.value = c, c;
  } else if (typeof e == "string" || typeof e == "number")
    return R("t", void 0, void 0, e);
  return e;
}, Mt = (e, t, n) => (c = t) => {
  const o = k.value, s = y.value;
  k.value = !1;
  try {
    Ue(c, e);
    const r = e(t, n);
    let l;
    if (typeof r == "function") {
      const i = r;
      l = le.has(i) ? i(t, n) : i(Me(c), t, n);
    } else {
      let i = !0;
      l = (a) => i ? (i = !1, r) : e(a, n);
    }
    return St(
      l,
      c,
      e,
      t,
      n
    );
  } finally {
    y.value = s, k.value = o;
  }
}, Ne = (e) => e.ctor ? Y(
  e.rs || {
    ctor: e.ctor,
    props: e.compProps,
    children: e.compChild
  }
) : R(
  e.type,
  e.tag,
  e.props,
  e.text,
  e.children && [...e.children],
  e.getParent
), Y = ({
  ctor: e,
  props: t,
  children: n
}) => Z(e, { ...t }, [...n || []]), Z = (e, t, n) => ({
  ctor: e,
  props: t,
  children: n,
  resolve: Mt(e, t, n)
}), St = (e, t, n, c, o) => {
  const s = xt(e), r = s(c), l = bt(
    s,
    t,
    n,
    c,
    o
  );
  return Te(r, t, n, c, o, l), Ct(
    t,
    (i) => gt(
      n,
      i.compProps || c,
      i.compChild || o,
      i
    )
  ), r;
}, bt = (e, t, n, c, o) => {
  const s = () => {
    const r = y.value;
    try {
      Oe(t), kt();
      const l = e(c);
      return Te(l, t, n, c, o, s), l;
    } finally {
      y.value = r;
    }
  };
  return s;
}, xt = (e) => (t) => {
  const n = xe(e(t)), c = X({}, n);
  return n.getParent = () => c, c;
}, Te = (e, t, n, c, o, s) => {
  e.compProps = c, e.compChild = o, e.ctor = n, e.compKey = t, e.reRender = s;
  const r = p.get(t);
  r && (r.vd.value = e);
}, _t = (e) => ({ value: e }), Ht = () => Promise.resolve(), Vt = () => {
  const e = Le();
  return e ? Me(e) : () => !1;
};
export {
  X as Fragment,
  p as componentMap,
  Me as componentUpdate,
  Ft as disposeComponentEntry,
  Le as getComponentKey,
  Nt as getComponentSubInfo,
  Rt as h,
  At as isPropType,
  jt as lmount,
  le as lmountComponentSet,
  Kt as mount,
  Lt as mountCallback,
  Ot as mountReadyCallback,
  Ht as nextTick,
  Qt as portal,
  _t as ref,
  Ut as render,
  gt as replaceWDom,
  Tt as setComponentMapManualMode,
  Bt as updateCallback,
  Vt as useRenew
};
//# sourceMappingURL=lithent.mjs.map
