import type { WDom } from '@/types';

type ChildOrderFrame = {
  proofs: WeakMap<WDom, WDom[]>;
  ready: boolean;
  invalid: boolean;
};

// Lives only for one synchronous replacement. No flags on reusable WDom nodes.
export const childOrderRef: { value?: ChildOrderFrame } = {};
