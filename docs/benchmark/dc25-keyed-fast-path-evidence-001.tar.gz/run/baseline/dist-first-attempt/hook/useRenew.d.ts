import { Renew } from '../types';
/**
 * Hook to get the renew (component update) function.
 * Useful for lmount components that need to trigger updates.
 */
export declare const useRenew: () => Renew;
