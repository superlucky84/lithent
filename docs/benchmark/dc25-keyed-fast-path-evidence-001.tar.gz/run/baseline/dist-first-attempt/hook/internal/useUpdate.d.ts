import { WDom } from '../../types';
type DependencyFactory = () => unknown[];
export declare const useUpdated: (effectAction: () => (() => void) | void, dependencies?: DependencyFactory) => void;
export declare const runUpdatedQueueFromWDom: (newWDom: WDom) => void;
export {};
