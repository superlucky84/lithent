export declare const ref: <T>(initValue: T) => {
    value: T;
};
export declare const nextTick: () => Promise<void>;
