import { WDom } from '../types';
/**
 * WDom이 생성된 직후(DOM 마운트 전)에 실행될 콜백 등록
 */
export declare const mountReadyCallback: (effectAction: () => void | (() => void)) => void;
/**
 * 특정 WDom의 wdomCallback 즉시 실행
 * wDomToDom() 내부에서 각 WDom 생성 시점에 호출됨
 */
export declare const runWDomCallbacksFromWDom: (newWDom: WDom) => void;
