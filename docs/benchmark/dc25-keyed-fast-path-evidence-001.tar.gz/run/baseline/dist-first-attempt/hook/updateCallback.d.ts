type DependencyFactory = () => unknown[];
export declare const updateCallback: (effectAction: () => (() => void) | void, dependencies?: DependencyFactory) => void;
export declare const runUpdateCallback: () => void;
export {};
