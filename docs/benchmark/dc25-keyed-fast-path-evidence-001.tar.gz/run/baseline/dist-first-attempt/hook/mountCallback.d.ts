import { WDom } from '../types';
/**
 * WDom을 mountedQueue에 추가
 */
export declare const addMountedQueue: (wDom: WDom) => void;
/**
 * DOM 렌더링 후 mountCallback 실행
 */
export declare const execMountedQueue: () => void;
/**
 * mountCallback 등록
 */
export declare const mountCallback: (effectAction: () => void) => void;
