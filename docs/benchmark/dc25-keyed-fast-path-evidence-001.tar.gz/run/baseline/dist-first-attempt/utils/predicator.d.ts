import { WDom, TagFunction, TagFunctionResolver, FragmentFunction, WDomType } from '../types';
type WDomParam = string | WDom | TagFunction | TagFunctionResolver | FragmentFunction;
export declare const getKey: (target: WDom) => unknown;
/**
 * Check if the type is virtual (fragment or loop)
 * Virtual types don't create real DOM elements themselves
 */
export declare const checkVirtualType: (type?: string | null) => boolean;
export declare const checkCustemComponentFunction: (target: WDomParam) => target is TagFunctionResolver | TagFunction;
export declare const checkFragmentFunction: (target: unknown) => target is FragmentFunction;
export declare const checkEmptyElement: (wDom: WDom) => boolean;
export declare const checkPortalElement: ({ el, op, props }: WDom) => boolean;
export declare const checkEventKey: (key: string) => boolean;
export declare const checkExistyKey: (target: WDom) => boolean;
export declare const checkKeyedChildren: (target?: WDom) => boolean;
export declare const checkExisty: (value: unknown) => boolean;
export declare const checkStyleData: (dataKey: string, dataValue: unknown) => dataValue is Record<string, string>;
export declare const checkRefData: (dataKey: string, dataValue: unknown) => dataValue is {
    value: HTMLElement | Element | DocumentFragment | Text | undefined;
};
export declare const hasAccessorMethods: (target: unknown, dataKey: string) => boolean;
export declare const isPendingCustomElement: (target: unknown) => boolean;
/**
 * Get WDom type as a single character code
 * 'c': component, 'f': fragment, 'e': element, 'l': loop, 't': text, 'et': empty/null
 */
export declare const getWDomType: (wDom: WDom | TagFunction | TagFunctionResolver) => WDomType;
export declare const checkSameWDomWithOriginal: {
    c: (newWDom: WDom | TagFunction | TagFunctionResolver, originalWDom?: WDom) => boolean;
    l: (newWDom: WDom, originalWDom: WDom) => boolean;
    t: (newWDom: WDom, originalWDom: WDom) => boolean;
    e: (newWDom: WDom, originalWDom: WDom) => boolean;
    f: (newWDom: WDom, originalWDom: WDom) => boolean;
    et: (newWDom: WDom, originalWDom: WDom) => boolean;
};
export {};
