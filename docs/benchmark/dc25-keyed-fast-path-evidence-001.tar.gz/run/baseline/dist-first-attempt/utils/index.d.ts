import { WDom, Props } from '../types';
export declare const getParent: (vDom: WDom) => WDom;
export declare const makeParentGetter: (parent: WDom) => () => WDom;
export declare const entries: {
    <T>(o: {
        [s: string]: T;
    } | ArrayLike<T>): [string, T][];
    (o: {}): [string, any][];
};
export declare const keys: {
    (o: object): string[];
    (o: {}): string[];
};
export declare const isEnumerableProp: (props: Props, key: string) => boolean;
export declare const hasEnumerableProp: (props: Props, key: string) => boolean;
export declare const isObject: (target: unknown) => target is Record<string, unknown>;
export declare const assign: {
    <T extends {}, U>(target: T, source: U): T & U;
    <T_1 extends {}, U_1, V>(target: T_1, source1: U_1, source2: V): T_1 & U_1 & V;
    <T_2 extends {}, U_2, V_1, W>(target: T_2, source1: U_2, source2: V_1, source3: W): T_2 & U_2 & V_1 & W;
    (target: object, ...sources: any[]): any;
};
export declare const isPropType: (obj: unknown) => obj is Partial<Record<string, unknown>>;
