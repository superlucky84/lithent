import { Props, WDom } from '../types';
export declare const setRedrawAction: (compKey: Props, exec: () => void) => void;
/**
 * Like setRedrawAction, but bound once per component instead of on every
 * render: the node to redraw is the component's current one when renew() is
 * called.
 */
export declare const bindRedraw: (compKey: Props, exec: (wDom: WDom) => void) => void;
export declare const componentUpdate: (compKey: Props) => () => boolean;
