import { ComponentMap, ComponentSubKey, CompKey, ComponentInfo, TagFunction } from '../types';
export declare const wdomSymbol: unique symbol;
export declare const xmlnsRef: {
    value: string;
};
export declare const compKeyRef: {
    value: CompKey | null;
};
export declare const needDiffRef: {
    value: boolean;
};
export declare const componentMap: ComponentMap;
export declare const lmountComponentSet: WeakSet<Function>;
export declare const getComponentKey: () => CompKey | null;
/** The component whose setup or render is running (a WeakMap misses null). */
export declare const getCurrentComponent: () => ComponentInfo | undefined;
export declare const getComponentSubInfo: <K extends ComponentSubKey>(compKey: CompKey, subKey: K) => ComponentInfo[K] | null;
export declare const initUpdateHookState: (compKey: CompKey) => void;
export declare const initMountHookState: (compKey: CompKey, ctor?: TagFunction) => void;
export declare const setComponentMapManualMode: (enabled: boolean) => void;
export declare const isComponentMapManualMode: () => boolean;
export declare const runUnmountEffects: (compKey: CompKey) => void;
export declare const disposeComponentEntry: (compKey: CompKey) => void;
