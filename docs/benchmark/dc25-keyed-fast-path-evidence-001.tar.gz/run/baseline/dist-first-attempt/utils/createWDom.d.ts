import type { WDom } from '../types';
export declare const createWDom: (type: WDom['type'], tag?: WDom['tag'], props?: WDom['props'], text?: WDom['text'], children?: WDom['children'], getParent?: WDom['getParent']) => WDom;
