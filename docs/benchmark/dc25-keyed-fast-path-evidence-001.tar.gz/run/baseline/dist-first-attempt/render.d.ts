import { WDom } from './types';
export declare const render: (wDom: WDom, wrapElement: HTMLElement | null, afterElement?: HTMLElement | null, isHydration?: boolean) => () => void;
export declare const typeDelete: (newWDom: WDom) => void;
/**
 * Unmount and remove unused keyed children. Listeners are left on the
 * discarded DOM and go away with it. The parent element is found from the
 * list they were in: a child's own parent link may have been moved on by
 * the same node being drawn in another place since.
 */
export declare const typeDeleteUnused: (items: WDom[], list: WDom) => void;
export declare const wDomUpdate: (newWDomTree: WDom) => void;
