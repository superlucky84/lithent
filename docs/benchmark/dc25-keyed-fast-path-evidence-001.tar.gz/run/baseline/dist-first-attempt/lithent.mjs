const ue = Symbol.for("lithentWDomSymbol"), S = { value: "" }, y = { value: null }, k = { value: !1 }, p = /* @__PURE__ */ new WeakMap(), ie = /* @__PURE__ */ new WeakSet();
let ae = !1;
const Le = (e, t) => {
  p.set(e, {
    ctor: t,
    vd: { value: null },
    up: () => {
    },
    upR: [],
    upS: { value: 0 },
    upD: [],
    upCB: [],
    mts: [],
    umts: [],
    wdCB: []
    // WDom creation callback queue
  });
}, Oe = () => y.value, E = () => p.get(y.value), Tt = (e, t) => {
  const n = p.get(e);
  return n ? n[t] : null;
}, Ue = (e) => {
  y.value = e;
}, Be = (e, t) => {
  y.value = e, Le(e, t);
}, Ft = (e) => {
  ae = e;
}, Qe = () => ae, fe = (e) => {
  const t = p.get(e);
  t && (t.umts.forEach((n) => n()), t.umts = []);
}, At = (e) => {
  fe(e), p.delete(e);
}, C = (e) => e.getParent && e.getParent(), B = (e) => () => e, D = Object.keys, de = (e, t) => Object.prototype.propertyIsEnumerable.call(e, t), pe = (e, t) => {
  if (de(e, t)) return !0;
  const n = Object.getPrototypeOf(e);
  return !Object.prototype.hasOwnProperty.call(e, t) && !!n && pe(n, t);
}, x = (e) => typeof e == "object" && e !== null, Lt = (e) => x(e) && !Array.isArray(e) && !Object.getOwnPropertySymbols(e).includes(ue), Ke = (e, t) => "ctor" in e ? e.ctor === (t && t.ctor) : e === (t && t.ctor), je = (e, t) => t.type === "f" && // A component's node is a one-child fragment too: never update it in
// place as a plain fragment, or the component is never unmounted, nor
// update a plain fragment with one (a hoisted <Comp /> first drawn by a
// redraw), or it is never mounted.
!t.ctor && !e.ctor && !!t.children && t.children.length === (e.children && e.children.length), _e = (e, t) => t.type === "e" && t.tag === e.tag && !!t.children && t.children.length === (e.children && e.children.length), ee = (e, t) => t.type === e.type, He = (e, t) => t.type === e.type && (V(e) && V(t) || !!t.children && t.children.length === (e.children && e.children.length)), _ = (e) => (e && e.compProps && e.compProps.key) ?? (e && e.props && e.props.key), N = (e) => e === "f" || e === "l", Q = (e) => typeof e == "function" && !he(e) || x(e) && "resolve" in e, he = (e) => e === Z, Ve = (e) => !e.type, R = ({ el: e, op: t, props: n }) => !!e && (e === (t && t.portal) || e === (n && n.portal)), H = (e) => e[0] === "o" && e[1] === "n", I = (e) => A(_(e)), V = (e) => !!e && !!e.children && e.children.some(I), A = (e) => e != null, te = (e, t) => e === "style" && x(t), qe = (e, t) => e === "ref" && x(t), ne = /* @__PURE__ */ new WeakMap(), ce = (e, t) => {
  const n = e.constructor.prototype;
  let c = ne.get(n);
  c || ne.set(n, c = /* @__PURE__ */ new Map());
  let o = c.get(t);
  if (o === void 0) {
    const s = Object.getOwnPropertyDescriptor(n, t);
    o = !!(s && s.get && s.set), c.set(t, o);
  }
  return o;
}, oe = (e) => e.localName.includes("-") && e.constructor === HTMLElement, ze = (e) => Q(e) ? "c" : e.type || "et", Ge = {
  c: Ke,
  l: He,
  t: ee,
  e: _e,
  f: je,
  et: ee
}, ve = (e) => {
  const t = E();
  t && t.umts.push(e);
}, K = (e) => {
  const { compKey: t } = e;
  t && (e.il = !0, Ie(t)), ye(e);
}, ye = (e) => {
  if (e.tag === "portal" && e.el)
    for (const t in e.props)
      H(t) && e.el.removeEventListener(
        t.slice(2).toLowerCase(),
        e.props[t]
      );
  (e.children || []).forEach((t) => {
    t.compKey ? K(t) : ye(t);
  });
}, Ie = (e) => {
  fe(e), Qe() || p.delete(e);
};
let q = [];
const Je = (e) => {
  e.compKey && q.push(e);
}, b = () => {
  q.forEach(Xe), q = [];
}, Ot = (e) => {
  const t = E();
  t && t.mts.push(e);
}, Xe = (e) => {
  const { compKey: t } = e, n = t && p.get(t);
  if (n) {
    const c = n.mts;
    y.value = t, n.upS.value = 0, n.mts = [], c.forEach((o) => {
      const s = o();
      s && ve(s);
    });
  }
}, Ut = (e) => {
  const t = E();
  t && t.wdCB.push(e);
}, Ye = (e) => {
  const { compKey: t } = e;
  if (t) {
    const n = p.get(t), c = n && n.wdCB;
    y.value = t, c && c.length > 0 && (n.wdCB = [], c.forEach((o) => {
      const s = o();
      typeof s == "function" && ve(s);
    }));
  }
}, se = (e, t = () => []) => {
  const n = E();
  if (!n) return;
  const { upD: c, upS: o } = n, s = c[o.value], r = t();
  if (s && $e(s, r)) {
    const l = e();
    l && n.upCB.push(l);
  }
  c[o.value] = r, o.value += 1;
}, Ze = (e) => {
  const { compKey: t } = e, n = t && p.get(t);
  if (n) {
    const c = n.upCB;
    y.value = t, n.upS.value = 0, e.ctor && (n.upCB = [], c.forEach((o) => o()));
  }
}, $e = (e, t) => e.length ? e.some((n, c) => n !== t[c]) : !0, Ce = () => new DocumentFragment(), ke = (e, t, n) => n ? e.insertBefore(t, n) : e.tagName === "HTML" ? e.replaceWith(t) : e.appendChild(t), me = (e) => document.createElement(e), Bt = (e, t, n, c) => {
  e.isRoot = !0, t = t || document.body, e.we = t;
  const o = T(e, c);
  return e.ae = n, (n || !c) && ke(t, o, n), b(), () => {
    const s = p.get(e.compProps), r = s && s.vd.value || e;
    K(r), we(r);
  };
}, we = (e) => X(e, e.we), J = (e) => {
  const t = C(e);
  X(
    e,
    e.isRoot ? e.we : t && g(t)
  );
}, X = (e, t) => {
  if (t && e.el) {
    const n = e.el.nodeType, c = R(e);
    n === 11 || c ? z(
      e,
      c ? e.el : t
    ) : (n === 1 || n === 3) && t.removeChild(e.el), e.el = void 0;
  }
}, z = (e, t) => {
  const n = e.oc || e.children || [];
  if (n.length > 1 && n.every((c) => {
    const o = c.el && c.el.nodeType;
    return (o === 1 || o === 3) && c.el.tagName !== "HTML" && !R(c);
  })) {
    let c = 0;
    for (let o = t.firstChild; o && c <= n.length; o = o.nextSibling)
      c++;
    if (c === n.length) {
      t.textContent = "", n.forEach((o) => o.el = void 0);
      return;
    }
  }
  n.forEach((c) => {
    const o = c.el && c.el.nodeType;
    if (R(c))
      z(c, c.el);
    else if (o === 1 || o === 3) {
      const s = c.el;
      s.tagName === "HTML" ? s.innerHTML = "" : s.remove();
    } else o === 11 && z(c, t);
  });
}, We = (e, t) => {
  const n = g(t);
  e.forEach((c) => {
    K(c), X(c, n);
  });
}, Pe = (e) => {
  J(e), Re(e);
}, Re = (e, t) => {
  t = t || T(e);
  const n = C(e);
  if (!n || !n.type) {
    e.isRoot && e.we && e.tag !== "portal" && (ke(e.we, t, e.ae), b());
    return;
  }
  const c = g(n), o = Y(e, n);
  c && (e.tag !== "portal" && c.insertBefore(t, o || null), b());
}, Ee = (e) => N(e.type) ? (e.children || []).reduce((t, n) => {
  const c = Ee(n);
  return c && !R(n) && t.appendChild(c), t;
}, Ce()) : e.el, Y = (e, t) => {
  const n = t.children || [];
  return O(n.slice(n.indexOf(e) + 1)) || (N(t.type) ? t.isRoot ? t.ae : Y(t, C(t)) : void 0);
}, L = /* @__PURE__ */ new Set(), O = (e) => e.reduce(
  (t, n) => {
    if (t || R(n) || L.size && L.has(n))
      return t;
    const { type: c, el: o } = n;
    if (c && N(c)) {
      const s = O(n.children || []);
      if (s) return s;
    }
    return o && o.nodeType !== 11 ? o : t;
  },
  void 0
), De = (e) => {
  const t = C(e), n = e.el;
  if (n && (t ? t.type : e.isRoot))
    if (!t || n.nodeType === 11 || R(e) || e.tag === "portal")
      Pe(e);
    else {
      const c = g(t), o = T(e);
      c && c.replaceChild(o, n), b();
    }
}, re = (e) => {
  if (e.type === "t") {
    ct(e);
    return;
  }
  if (e.el) {
    const { op: t, props: n } = e;
    Me(n, e.el, t), e.tag === "input" && (e.el.value = String(
      n && n.value || ""
    ));
  }
  et(e), Ze(e);
}, et = (e) => {
  const t = e.children || [];
  if (e.type !== "l" || !t.some(
    (u) => "ATS".includes(u.nr) || u.oi !== void 0
  )) {
    t.forEach(G);
    return;
  }
  const n = [], c = [], o = [];
  let s = !0;
  t.forEach((u, f) => {
    const v = u.oi, M = u.nr;
    M === "S" ? o.push(u) : M !== "A" && v !== void 0 && (v < c[c.length - 1] && (s = !1), n.push(f), c.push(v));
  });
  let r;
  if (!s) {
    const u = r = [];
    tt(c).forEach((f) => u[n[f]] = !0), n.forEach(
      (f) => u[f] || (u[f] = !1, o.push(t[f]))
    );
  }
  const l = [];
  let i = 0;
  o.forEach((u) => L.add(u));
  try {
    t.forEach((u, f) => {
      const v = u.nr;
      v === "A" || v === "S" ? (v === "S" && J(u), l[f] = T(u), i++) : G(u);
    });
  } finally {
    o.forEach((u) => L.delete(u));
  }
  const a = g(e), h = e.isRoot ? e.ae : Y(e, C(e));
  let d = t.length;
  for (; d > 0 && l[d - 1] !== void 0; )
    d--;
  for (let u = d; u < t.length; u++) {
    const f = l[u];
    f && a && t[u].tag !== "portal" && a.insertBefore(f, h || null);
  }
  if (r || i > t.length - d) {
    let u = O(t.slice(d)) || h;
    for (let f = d - 1; f >= 0; f--) {
      const v = t[f], M = l[f] !== void 0, Ae = !!r && r[f] === !1;
      if ((M || Ae) && a && v.tag !== "portal") {
        const W = M ? l[f] : Ee(v);
        W && a.insertBefore(W, u || null);
      }
      const w = O([v]);
      w && (u = w);
    }
  }
  t.forEach(ge), b();
}, ge = (e) => {
  e.oi = e.oc = e.op = void 0, e.nr = "N";
}, tt = (e) => {
  const t = [], n = [];
  e.forEach((s, r) => {
    let l = 0, i = t.length;
    if (i && e[t[i - 1]] < s)
      l = i;
    else
      for (; l < i; ) {
        const a = l + i >> 1;
        e[t[a]] < s ? l = a + 1 : i = a;
      }
    n[r] = l ? t[l - 1] : -1, t[l] = r;
  });
  let c = t.length, o = t[c - 1];
  for (; c-- > 0; )
    t[c] = o, o = n[o];
  return t;
}, G = (e) => {
  const { nr: t } = e;
  t && t !== "N" && (nt[t](e), ge(e));
}, nt = {
  A: Re,
  D: J,
  R: De,
  U: re,
  S: Pe,
  // A keyed item reaches here only as a component redrawing itself: it has
  // not moved, so it is updated in place. Re-inserting its nodes would blur a
  // focused input inside it or reload an iframe. Moves within a list are
  // placed by updateChildren.
  T: re
}, ct = (e) => {
  e.el && (e.el.nodeValue = String(e.text));
}, Me = (e, t, n) => {
  const c = n || {};
  for (const o in e) {
    const s = e[o];
    s !== c[o] && (H(o) ? le(
      t,
      o,
      s,
      c[o]
    ) : o === "key" || o === "portal" && x(s) || (o === "innerHTML" && typeof s == "string" ? t.innerHTML = s : te(o, s) ? rt(
      s,
      te(o, c.style) ? c.style : {},
      t
    ) : qe(o, s) ? s.value = t : o && (o !== "type" && ce(t, o) ? t[o] = s : (ot(
      o === "className" ? "class" : o,
      t,
      s
    ), oe(t) && !(o in HTMLElement.prototype) && (t[o] = s)))));
  }
  for (const o in c)
    if (!(e && pe(e, o))) {
      if (H(o)) {
        le(
          t,
          o,
          void 0,
          c[o]
        );
        continue;
      }
      t.removeAttribute(o), oe(t) ? delete t[o] : t.localName.includes("-") && ce(t, o) && (t[o] = void 0);
    }
}, ot = (e, t, n) => S.value && e !== "xmlns" ? t.setAttributeNS(null, e, n) : t.setAttribute(e, n), T = (e, t) => {
  let n;
  const { type: c, tag: o, text: s, props: r, children: l = [] } = e, i = N(c);
  if (Ye(e), o === "svg" && (S.value = String(r && r.xmlns)), t)
    n = e.el;
  else {
    if (!c || i)
      n = Ce();
    else if (c === "e" && o)
      o === "portal" && r && r.portal ? n = r.portal : n = S.value ? document.createElementNS(S.value, o) : me(o);
    else if (c === "t" && A(s))
      n = document.createTextNode(String(s));
    else
      throw Error("Invalid wDom");
    e.el = n;
  }
  return st(e, l, n, t), Me(r, n, null), Je(e), o === "svg" && (S.value = ""), n;
}, st = (e, t, n, c) => {
  const o = B(e);
  t.forEach((s, r) => {
    if (s.nr === "N" && !c) {
      const l = Te(s);
      s = t[r] = "resolve" in l ? l.resolve() : l;
    }
    if (s.getParent = o, s.nr = "N", s.type) {
      const l = T(s, c);
      s.tag !== "portal" && !c && n && n.appendChild(l);
    }
  });
}, le = (e, t, n, c) => {
  const o = t.slice(2).toLowerCase();
  c !== n && (c && e.removeEventListener(o, c), n && e.addEventListener(o, n));
}, rt = (e, t, n) => {
  const c = { ...t };
  if (!(n instanceof HTMLElement)) return;
  const o = n.style;
  for (const s in e)
    o[s] = e[s], delete c[s];
  for (const s in c)
    o[s] = "";
}, g = (e) => N(e.type) ? e.isRoot ? e.we : g(C(e)) : e.el, j = (e, t) => (e !== t && e.nr && (e = Te(e)), lt(
  e,
  !!t && Ge[ze(e)](e, t),
  t
)), lt = (e, t, n) => {
  const c = dt(e, t, n), o = it(
    c,
    t,
    n
  ), s = o === "N";
  return s || (c.children = pt(
    c,
    t,
    n
  )), c.nr = o, ut(c, n, o), !s && n && (n.il = !0, n.ctor && (n.children = void 0)), c;
}, ut = (e, t, n) => {
  n !== "A" && t && (e.el = t.el), (n === "D" || n === "R" || n === "S") && (t && K(t), e.oc = t && t.children), e.op = t && t.props;
}, it = (e, t, n) => {
  if (Ve(e)) return "D";
  if (e === n || t && e.type === "t" && e.text === n.text)
    return "N";
  if (!(n && n.type)) return "A";
  const c = C(n), o = !e.isRoot && c && c.type === "l" && I(e);
  return t ? o ? "T" : "U" : o ? "S" : "R";
}, at = (e, t) => {
  e && t !== e && (t = t || {}, D(e).forEach(
    (n) => de(t, n) || delete e[n]
  ), D(t).forEach((n) => e[n] = t[n]));
}, ft = (e, t) => {
  const { compProps: n, compChild: c } = e, { props: o, children: s } = t;
  return n && at(n, o), c && s && c !== s && c.splice(0, c.length, ...s), e.reRender && e.reRender();
}, dt = (e, t, n) => Q(e) ? t && n ? ft(n, e) : (
  // Resolved before (children a component draws again somewhere else):
  // the first instance owns its props, which are also its key, so the
  // new instance is made from a copy.
  (e.rd ? $(e) : (e.rd = !0, e)).resolve()
) : e, pt = (e, t, n) => t && n ? vt(e, n) : ht(e), ht = (e) => {
  const t = B(e);
  return (e.children || []).map((n) => {
    const c = j(n);
    return c.getParent = t, c;
  });
}, vt = (e, t) => {
  if (e.type === "l" && V(e))
    return yt(e, t);
  const n = t.children || [], c = B(e);
  return (e.children || []).map((o, s) => {
    const r = j(o, n[s]);
    return r.getParent = c, r;
  });
}, yt = (e, t) => {
  const n = t.children || [], c = /* @__PURE__ */ new Map();
  n.forEach((l, i) => {
    const a = _(l);
    A(a) && !c.has(a) && c.set(a, i);
  });
  const o = [], s = B(e), r = (e.children || []).map((l, i) => {
    const a = _(l), h = A(a) ? c.get(a) : i < n.length && !I(n[i]) ? i : void 0;
    let d;
    h !== void 0 && (c.delete(a), o[h] = !0, d = n[h]);
    const u = j(l, d);
    return d && (u.oi = h), u.getParent = s, u;
  });
  return We(
    n.filter((l, i) => !o[i]),
    t
  ), r;
}, F = /* @__PURE__ */ new Map();
let U = !1;
const Ct = (e, t) => {
  F.set(e, t), U || (U = !0, queueMicrotask(be));
}, kt = (e, t) => {
  const n = p.get(e);
  n && (n.up = () => {
    const c = n.vd.value;
    Ct(e, () => t(c));
  });
}, Se = (e) => () => {
  const t = p.get(e), n = t && t.up;
  return n ? (n(), !0) : !1;
}, be = () => {
  try {
    F.forEach((e, t) => {
      F.delete(t), e();
    });
  } finally {
    U = !!F.size, U && queueMicrotask(be);
  }
}, P = (e, t, n, c, o, s) => ({
  type: e,
  nr: void 0,
  tag: t,
  props: n,
  text: c,
  children: o,
  getParent: s,
  el: void 0,
  oi: void 0,
  oc: void 0,
  op: void 0,
  il: void 0,
  [ue]: !0
}), Qt = (e, t = () => []) => {
  const n = E();
  n && (n.upR.push(() => se(e, t)), se(e, t));
}, Pt = () => {
  const e = E(), t = e && e.upR;
  t && t.length && t.forEach((n) => n());
}, Z = (e, ...t) => P("f", void 0, void 0, void 0, t), Rt = (e, t, ...n) => {
  const c = { value: void 0 }, o = xe(c, n), s = Mt(e, t || {}, o);
  return Q(s) || (c.value = s), s;
}, Kt = (e, t) => Rt("portal", { portal: t }, e), jt = (e) => (t, n) => e, _t = (e) => (t, n) => (ie.add(e), e), Et = (e, t, n) => {
  const c = (o, s) => {
    if (!(!o || s.has(o))) {
      if (s.add(o), o.compChild) {
        const r = o.compChild.indexOf(t);
        r !== -1 && o.compChild.splice(r, 1, n);
      }
      c(o.getParent ? o.getParent() : void 0, s);
    }
  };
  c(e, /* @__PURE__ */ new Set());
}, gt = (e, t, n, c) => {
  if (c.il)
    return;
  k.value = !0;
  let o;
  try {
    const s = m(e, t, n);
    o = j(s, c);
    const { isRoot: r, getParent: l, we: i, ae: a } = c;
    if (o.getParent = l, !r && l) {
      const h = l(), d = h && h.children || [], u = d.indexOf(c);
      u !== -1 && d.splice(u, 1, o), Et(h, c, o);
    } else
      o.isRoot = !0, o.we = i, o.ae = a;
  } finally {
    k.value = !1;
  }
  G(o);
}, Mt = (e, t, n) => {
  if (he(e))
    return Z(t, ...n);
  if (Q(e)) {
    const c = m(e, t, n);
    if (k.value)
      return c;
    const o = $(c).resolve();
    return o.rs = c, o;
  }
  return P("e", e, t, void 0, n);
}, xe = (e, t) => {
  const n = () => e.value;
  return t.map((c) => {
    const o = Ne(c);
    return o.getParent = n, o;
  });
}, Ne = (e) => {
  if (e == null || typeof e == "boolean")
    return P(null);
  if (Array.isArray(e)) {
    const t = { value: void 0 }, n = xe(t, e), c = P("l", void 0, void 0, void 0, n);
    return t.value = c, c;
  } else if (typeof e == "string" || typeof e == "number")
    return P("t", void 0, void 0, e);
  return e;
}, St = (e, t, n) => (c = t) => {
  const o = k.value, s = y.value;
  k.value = !1;
  try {
    Be(c, e);
    const r = e(t, n);
    let l;
    if (typeof r == "function") {
      const i = r;
      l = ie.has(i) ? i(t, n) : i(Se(c), t, n);
    } else {
      let i = !0;
      l = (a) => i ? (i = !1, r) : e(a, n);
    }
    return bt(
      l,
      c,
      e,
      t,
      n
    );
  } finally {
    y.value = s, k.value = o;
  }
}, Te = (e) => e.ctor ? $(
  e.rs || {
    ctor: e.ctor,
    props: e.compProps,
    children: e.compChild
  }
) : P(
  e.type,
  e.tag,
  e.props,
  e.text,
  e.children && [...e.children],
  e.getParent
), $ = ({
  ctor: e,
  props: t,
  children: n
}) => m(e, { ...t }, [...n || []]), m = (e, t, n) => ({
  ctor: e,
  props: t,
  children: n,
  resolve: St(e, t, n)
}), bt = (e, t, n, c, o) => {
  const s = Nt(e), r = s(c), l = xt(
    s,
    t,
    n,
    c,
    o
  );
  return Fe(r, t, n, c, o, l), kt(
    t,
    (i) => gt(
      n,
      i.compProps || c,
      i.compChild || o,
      i
    )
  ), r;
}, xt = (e, t, n, c, o) => {
  const s = () => {
    const r = y.value;
    try {
      Ue(t), Pt();
      const l = e(c);
      return Fe(l, t, n, c, o, s), l;
    } finally {
      y.value = r;
    }
  };
  return s;
}, Nt = (e) => (t) => {
  const n = Ne(e(t)), c = Z({}, n);
  return n.getParent = () => c, c;
}, Fe = (e, t, n, c, o, s) => {
  e.compProps = c, e.compChild = o, e.ctor = n, e.compKey = t, e.reRender = s;
  const r = p.get(t);
  r && (r.vd.value = e);
}, Ht = (e) => ({ value: e }), Vt = () => Promise.resolve(), qt = () => {
  const e = Oe();
  return e ? Se(e) : () => !1;
};
export {
  Z as Fragment,
  p as componentMap,
  Se as componentUpdate,
  At as disposeComponentEntry,
  Oe as getComponentKey,
  Tt as getComponentSubInfo,
  Rt as h,
  Lt as isPropType,
  _t as lmount,
  ie as lmountComponentSet,
  jt as mount,
  Ot as mountCallback,
  Ut as mountReadyCallback,
  Vt as nextTick,
  Kt as portal,
  Ht as ref,
  Bt as render,
  gt as replaceWDom,
  Ft as setComponentMapManualMode,
  Qt as updateCallback,
  qt as useRenew
};
//# sourceMappingURL=lithent.mjs.map
