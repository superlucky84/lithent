import { WDom, TagFunctionResolver } from './types';
/**
 * The starting point of the diffing process between the original virtual DOM and the new virtual DOM for re-rendering.
 */
export declare const makeNewWDomTree: (newWDom: WDom | TagFunctionResolver, originalWDom?: WDom) => WDom;
