import { WDom, TagFunction, TagFunctionResolver, FragmentFunction, Props, MiddleStateWDomChildren, Component, LComponent } from './types';
/**
 * It allows grouping multiple elements together.
 */
export declare const Fragment: (_props: Props, ...children: WDom[]) => WDom;
/**
 * Element creation
 */
export declare const h: (tag: TagFunction | FragmentFunction | string, props: Props, ...children: MiddleStateWDomChildren) => WDom | {
    ctor: TagFunction;
    props: Partial<Record<string, unknown>>;
    children: WDom[];
    resolve: (compKey?: Partial<Record<string, unknown>>) => WDom;
};
/**
 * Enables portals
 */
export declare const portal: (wDom: WDom, portal: HTMLElement) => WDom | {
    ctor: TagFunction;
    props: Partial<Record<string, unknown>>;
    children: WDom[];
    resolve: (compKey?: Partial<Record<string, unknown>>) => WDom;
};
/**
 * It helps with component creation.
 */
export declare const mount: <T>(component: Component<T>) => (_props: T, _children?: MiddleStateWDomChildren) => Component<T>;
/**
 * It helps with component creation without renew parameter.
 * Use useRenew() hook to get renew function if needed.
 */
export declare const lmount: <T>(component: LComponent<T>) => (_props: T, _children?: MiddleStateWDomChildren) => LComponent<T>;
/**
 * It re-renders starting from a specific component.
 */
export declare const replaceWDom: (tag: TagFunction, props: Props, children: WDom[], originalWDom: WDom) => void;
/**
 * A fresh copy of a node that is already drawn somewhere: a hoisted constant,
 * children a component renders again in another place, the same node twice.
 * A node holds the state of the place it is drawn in (el, children, parent,
 * component instance), so a second place gets its own copy. A component
 * becomes a resolver for a new instance with its own props and children.
 */
export declare const cloneWDom: (wDom: WDom) => WDom | TagFunctionResolver;
export declare const copyResolver: ({ ctor, props, children, }: Omit<TagFunctionResolver, 'resolve'>) => {
    ctor: TagFunction;
    props: Partial<Record<string, unknown>>;
    children: WDom[];
    resolve: (compKey?: Partial<Record<string, unknown>>) => WDom;
};
