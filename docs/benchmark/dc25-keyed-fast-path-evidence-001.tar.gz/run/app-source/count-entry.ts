import './src/main';
export { nextTick } from 'lithent';
