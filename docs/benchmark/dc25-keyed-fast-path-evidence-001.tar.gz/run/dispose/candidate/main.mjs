const qt = Symbol.for("lithentWDomSymbol"), A = { value: "" }, E = { value: null }, P = { value: !1 }, w = /* @__PURE__ */ new WeakMap(), zt = /* @__PURE__ */ new WeakSet(), Wt = (t, e) => {
  w.set(t, {
    ctor: e,
    vd: { value: null },
    up: () => {
    },
    upR: [],
    upS: { value: 0 },
    upD: [],
    upCB: [],
    mts: [],
    umts: [],
    wdCB: []
    // WDom creation callback queue
  });
}, Ct = () => w.get(E.value), It = (t) => {
  E.value = t;
}, $t = (t, e) => {
  E.value = t, Wt(t, e);
}, Ft = (t) => {
  const e = w.get(t);
  e && (e.umts.forEach((o) => o()), e.umts = []);
}, x = (t) => t.getParent && t.getParent(), $ = (t) => () => t, dt = Object.keys, kt = (t, e) => Object.prototype.propertyIsEnumerable.call(t, e), St = (t, e) => {
  if (kt(t, e)) return !0;
  const o = Object.getPrototypeOf(t);
  return !Object.prototype.hasOwnProperty.call(t, e) && !!o && St(o, e);
}, F = (t) => typeof t == "object" && t !== null, Vt = (t, e) => "ctor" in t ? t.ctor === (e && e.ctor) : t === (e && e.ctor), Gt = (t, e) => e.type === "f" && // A component's node is a one-child fragment too: never update it in
// place as a plain fragment, or the component is never unmounted, nor
// update a plain fragment with one (a hoisted <Comp /> first drawn by a
// redraw), or it is never mounted.
!e.ctor && !t.ctor && !!e.children && e.children.length === (t.children && t.children.length), Jt = (t, e) => e.type === "e" && e.tag === t.tag && !!e.children && e.children.length === (t.children && t.children.length), pt = (t, e) => e.type === t.type, Qt = (t, e) => e.type === t.type && (tt(t) && tt(e) || !!e.children && e.children.length === (t.children && t.children.length)), Z = (t) => (t && t.compProps && t.compProps.key) ?? (t && t.props && t.props.key), H = (t) => t === "f" || t === "l", V = (t) => typeof t == "function" && !Rt(t) || F(t) && "resolve" in t, Rt = (t) => t === Q, Xt = (t) => !t.type, L = ({ el: t, op: e, props: o }) => !!t && (t === (e && e.portal) || t === (o && o.portal)), _ = (t) => t[0] === "o" && t[1] === "n", rt = (t) => D(Z(t)), tt = (t) => !!t && !!t.children && t.children.some(rt), D = (t) => t != null, ut = (t, e) => t === "style" && F(e), Yt = (t, e) => t === "ref" && F(e), ht = /* @__PURE__ */ new WeakMap(), vt = (t, e) => {
  const o = t.constructor.prototype;
  let n = ht.get(o);
  n || ht.set(o, n = /* @__PURE__ */ new Map());
  let r = n.get(e);
  if (r === void 0) {
    const l = Object.getOwnPropertyDescriptor(o, e);
    r = !!(l && l.get && l.set), n.set(e, r);
  }
  return r;
}, ft = (t) => t.localName.includes("-") && t.constructor === HTMLElement, Zt = (t) => V(t) ? "c" : t.type || "et", _t = {
  c: Vt,
  l: Qt,
  t: pt,
  e: Jt,
  f: Gt,
  et: pt
}, xt = (t) => {
  const e = Ct();
  e && e.umts.push(t);
}, G = (t) => {
  const { compKey: e } = t;
  e && (t.il = !0, te(e)), Pt(t);
}, Pt = (t) => {
  if (t.tag === "portal" && t.el)
    for (const e in t.props)
      _(e) && t.el.removeEventListener(
        e.slice(2).toLowerCase(),
        t.props[e]
      );
  (t.children || []).forEach((e) => {
    e.compKey ? G(e) : Pt(e);
  });
}, te = (t) => {
  Ft(t), w.delete(t);
};
let et = [];
const ee = (t) => {
  t.compKey && et.push(t);
}, M = () => {
  et.forEach(oe), et = [];
}, oe = (t) => {
  const { compKey: e } = t, o = e && w.get(e);
  if (o) {
    const n = o.mts;
    E.value = e, o.upS.value = 0, o.mts = [], n.forEach((r) => {
      const l = r();
      l && xt(l);
    });
  }
}, ne = (t) => {
  const { compKey: e } = t;
  if (e) {
    const o = w.get(e), n = o && o.wdCB;
    E.value = e, n && n.length > 0 && (o.wdCB = [], n.forEach((r) => {
      const l = r();
      typeof l == "function" && xt(l);
    }));
  }
}, re = (t) => {
  const { compKey: e } = t, o = e && w.get(e);
  if (o) {
    const n = o.upCB;
    E.value = e, o.upS.value = 0, t.ctor && (o.upCB = [], n.forEach((r) => r()));
  }
}, O = {}, Tt = () => new DocumentFragment(), Lt = (t, e, o) => o ? t.insertBefore(e, o) : t.tagName === "HTML" ? t.replaceWith(e) : t.appendChild(e), le = (t) => document.createElement(t), se = (t, e, o, n) => {
  t.isRoot = !0, e = e || document.body, t.we = e;
  const r = j(t, n);
  return t.ae = o, Lt(e, r, o), M(), () => {
    const l = w.get(t.compProps), s = l && l.vd.value || t;
    G(s), ce(s);
  };
}, ce = (t) => st(t, t.we), lt = (t) => {
  const e = x(t);
  st(
    t,
    t.isRoot ? t.we : e && N(e)
  );
}, st = (t, e) => {
  if (e && t.el) {
    const o = t.el.nodeType, n = L(t);
    o === 11 || n ? ot(
      t,
      n ? t.el : e
    ) : (o === 1 || o === 3) && e.removeChild(t.el), t.el = void 0;
  }
}, ot = (t, e) => {
  const o = t.oc || t.children || [];
  if (o.length > 1 && o.every((n) => {
    const r = n.el && n.el.nodeType;
    return (r === 1 || r === 3) && n.el.tagName !== "HTML" && !L(n);
  })) {
    let n = 0;
    for (let r = e.firstChild; r && n <= o.length; r = r.nextSibling)
      n++;
    if (n === o.length) {
      e.textContent = "", o.forEach((r) => r.el = void 0);
      return;
    }
  }
  o.forEach((n) => {
    const r = n.el && n.el.nodeType;
    if (L(n))
      ot(n, n.el);
    else if (r === 1 || r === 3) {
      const l = n.el;
      l.tagName === "HTML" ? l.innerHTML = "" : l.remove();
    } else r === 11 && ot(n, e);
  });
}, ae = (t, e) => {
  const o = N(e);
  t.forEach((n) => {
    G(n), st(n, o);
  });
}, Mt = (t) => {
  lt(t), Nt(t);
}, Nt = (t, e) => {
  e = e || j(t);
  const o = x(t);
  if (!o || !o.type) {
    t.isRoot && t.we && t.tag !== "portal" && (Lt(t.we, e, t.ae), M());
    return;
  }
  const n = N(o), r = ct(t, o);
  n && (t.tag !== "portal" && n.insertBefore(e, r || null), M());
}, At = (t) => H(t.type) ? (t.children || []).reduce((e, o) => {
  const n = At(o);
  return n && !L(o) && e.appendChild(n), e;
}, Tt()) : t.el, ct = (t, e) => {
  const o = e.children || [];
  return W(o.slice(o.indexOf(t) + 1)) || (H(e.type) ? e.isRoot ? e.ae : ct(e, x(e)) : void 0);
}, z = /* @__PURE__ */ new Set(), W = (t) => t.reduce(
  (e, o) => {
    if (e || L(o) || z.size && z.has(o))
      return e;
    const { type: n, el: r } = o;
    if (n && H(n)) {
      const l = W(o.children || []);
      if (l) return l;
    }
    return r && r.nodeType !== 11 ? r : e;
  },
  void 0
), ie = (t) => {
  const e = x(t), o = t.el;
  if (o && (e ? e.type : t.isRoot))
    if (!e || o.nodeType === 11 || L(t) || t.tag === "portal")
      Mt(t);
    else {
      const n = N(e), r = j(t);
      n && n.replaceChild(r, o), M();
    }
}, gt = (t) => {
  if (t.type === "t") {
    he(t);
    return;
  }
  const e = t.type === "l" ? t.so : void 0, o = e ? t.sc : void 0;
  if (e && (t.so = t.sc = void 0), t.el) {
    const { op: n, props: r } = t;
    Dt(r, t.el, n), t.tag === "input" && (t.el.value = String(
      r && r.value || ""
    ));
  }
  de(t, e, o), re(t);
}, de = (t, e, o) => {
  const n = t.children || [];
  if (e && e === O.value && e.ready && !e.invalid && n === o) {
    n.forEach(U), n.forEach(nt), M();
    return;
  }
  if (t.type !== "l" || !n.some(
    (a) => "ATS".includes(a.nr) || a.oi !== void 0
  )) {
    n.forEach(U);
    return;
  }
  const r = [], l = [], s = [];
  let c = !0;
  n.forEach((a, u) => {
    const v = a.oi, h = a.nr;
    h === "S" ? s.push(a) : h !== "A" && v !== void 0 && (v < l[l.length - 1] && (c = !1), r.push(u), l.push(v));
  });
  let i;
  if (!c) {
    const a = i = [];
    pe(l).forEach((u) => a[r[u]] = !0), r.forEach(
      (u) => a[u] || (a[u] = !1, s.push(n[u]))
    );
  }
  const p = [];
  let b = 0;
  s.forEach((a) => z.add(a));
  try {
    n.forEach((a, u) => {
      const v = a.nr;
      v === "A" || v === "S" ? (v === "S" && lt(a), p[u] = j(a), b++) : U(a);
    });
  } finally {
    s.forEach((a) => z.delete(a));
  }
  const C = N(t), m = t.isRoot ? t.ae : ct(t, x(t));
  let g = n.length;
  for (; g > 0 && p[g - 1] !== void 0; )
    g--;
  for (let a = g; a < n.length; a++) {
    const u = p[a];
    u && C && n[a].tag !== "portal" && C.insertBefore(u, m || null);
  }
  if (i || b > n.length - g) {
    let a = W(n.slice(g)) || m;
    for (let u = g - 1; u >= 0; u--) {
      const v = n[u], h = p[u] !== void 0, f = !!i && i[u] === !1;
      if ((h || f) && C && v.tag !== "portal") {
        const S = h ? p[u] : At(v);
        S && C.insertBefore(S, a || null);
      }
      const k = W([v]);
      k && (a = k);
    }
  }
  n.forEach(nt), M();
}, nt = (t) => {
  t.oi = t.oc = t.op = void 0, t.nr = "N";
}, pe = (t) => {
  const e = [], o = [];
  t.forEach((l, s) => {
    let c = 0, i = e.length;
    if (i && t[e[i - 1]] < l)
      c = i;
    else
      for (; c < i; ) {
        const p = c + i >> 1;
        t[e[p]] < l ? c = p + 1 : i = p;
      }
    o[s] = c ? e[c - 1] : -1, e[c] = s;
  });
  let n = e.length, r = e[n - 1];
  for (; n-- > 0; )
    e[n] = r, r = o[r];
  return e;
}, U = (t) => {
  const { nr: e } = t;
  e && e !== "N" && (ue[e](t), nt(t));
}, ue = {
  A: Nt,
  D: lt,
  R: ie,
  U: gt,
  S: Mt,
  // A keyed item reaches here only as a component redrawing itself: it has
  // not moved, so it is updated in place. Re-inserting its nodes would blur a
  // focused input inside it or reload an iframe. Moves within a list are
  // placed by updateChildren.
  T: gt
}, he = (t) => {
  t.el && (t.el.nodeValue = String(t.text));
}, Dt = (t, e, o) => {
  const n = o || {};
  for (const r in t) {
    const l = t[r];
    l !== n[r] && (_(r) ? yt(
      e,
      r,
      l,
      n[r]
    ) : r === "key" || r === "portal" && F(l) || (r === "innerHTML" && typeof l == "string" ? e.innerHTML = l : ut(r, l) ? ge(
      l,
      ut(r, n.style) ? n.style : {},
      e
    ) : Yt(r, l) ? l.value = e : r && (r !== "type" && vt(e, r) ? e[r] = l : (ve(
      r === "className" ? "class" : r,
      e,
      l
    ), ft(e) && !(r in HTMLElement.prototype) && (e[r] = l)))));
  }
  for (const r in n)
    if (!(t && St(t, r))) {
      if (_(r)) {
        yt(
          e,
          r,
          void 0,
          n[r]
        );
        continue;
      }
      e.removeAttribute(r), ft(e) ? delete e[r] : e.localName.includes("-") && vt(e, r) && (e[r] = void 0);
    }
}, ve = (t, e, o) => A.value && t !== "xmlns" ? e.setAttributeNS(null, t, o) : e.setAttribute(t, o), j = (t, e) => {
  let o;
  const { type: n, tag: r, text: l, props: s, children: c = [] } = t, i = H(n);
  if (ne(t), r === "svg" && (A.value = String(s && s.xmlns)), !e) {
    if (!n || i)
      o = Tt();
    else if (n === "e" && r)
      r === "portal" && s && s.portal ? o = s.portal : o = A.value ? document.createElementNS(A.value, r) : le(r);
    else if (n === "t" && D(l))
      o = document.createTextNode(String(l));
    else
      throw Error("Invalid wDom");
    t.el = o;
  }
  return fe(t, c, o, e), Dt(s, o, null), ee(t), r === "svg" && (A.value = ""), o;
}, fe = (t, e, o, n) => {
  const r = $(t);
  e.forEach((l, s) => {
    if (l.nr === "N" && !n) {
      const c = Kt(l);
      l = e[s] = "resolve" in c ? c.resolve() : c;
    }
    if (l.getParent = r, l.nr = "N", l.type) {
      const c = j(l, n);
      l.tag !== "portal" && !n && o && o.appendChild(c);
    }
  });
}, yt = (t, e, o, n) => {
  const r = e.slice(2).toLowerCase();
  n !== o && (n && t.removeEventListener(r, n), o && t.addEventListener(r, o));
}, ge = (t, e, o) => {
  const n = { ...e };
  if (!(o instanceof HTMLElement)) return;
  const r = o.style;
  for (const l in t)
    r[l] = t[l], delete n[l];
  for (const l in n)
    r[l] = "";
}, N = (t) => H(t.type) ? t.isRoot ? t.we : N(x(t)) : t.el, J = (t, e) => (t !== e && t.nr && (t = Kt(t)), ye(
  t,
  !!e && _t[Zt(t)](t, e),
  e
)), ye = (t, e, o) => {
  const n = Ce(t, e, o), r = we(
    n,
    e,
    o
  ), l = r === "N";
  return l || (n.children = ke(
    n,
    e,
    o
  )), n.nr = r, me(n, o, r), !l && o && (o.il = !0, o.ctor && (o.children = void 0)), n;
}, me = (t, e, o) => {
  o !== "A" && e && (t.el = e.el), (o === "D" || o === "R" || o === "S") && (e && G(e), t.oc = e && e.children), t.op = e && e.props;
}, we = (t, e, o) => {
  if (Xt(t)) return "D";
  if (t === o || e && t.type === "t" && t.text === o.text)
    return "N";
  if (!(o && o.type)) return "A";
  const n = x(o), r = !t.isRoot && n && n.type === "l" && rt(t);
  return e ? r ? "T" : "U" : r ? "S" : "R";
}, be = (t, e) => {
  t && e !== t && (e = e || {}, dt(t).forEach(
    (o) => kt(e, o) || delete t[o]
  ), dt(e).forEach((o) => t[o] = e[o]));
}, Ee = (t, e) => {
  const { compProps: o, compChild: n } = t, { props: r, children: l } = e;
  return o && be(o, r), n && l && n !== l && n.splice(0, n.length, ...l), t.reRender && t.reRender();
}, Ce = (t, e, o) => V(t) ? e && o ? Ee(o, t) : (
  // Resolved before (children a component draws again somewhere else):
  // the first instance owns its props, which are also its key, so the
  // new instance is made from a copy.
  (t.rd ? at(t) : (t.rd = !0, t)).resolve()
) : t, ke = (t, e, o) => e && o ? Re(t, o) : Se(t), Se = (t) => {
  const e = $(t);
  return (t.children || []).map((o) => {
    const n = J(o);
    return n.getParent = e, n;
  });
}, Re = (t, e) => {
  if (t.type === "l" && tt(t))
    return xe(t, e);
  const o = e.children || [], n = $(t);
  return (t.children || []).map((r, l) => {
    const s = J(r, o[l]);
    return s.getParent = n, s;
  });
}, xe = (t, e) => {
  const o = e.children || [], n = O.value, r = [], l = /* @__PURE__ */ new Set();
  let s = !0;
  o.forEach((v, h) => {
    const f = Z(v);
    r[h] = f, (!D(f) || l.has(f)) && (s = !1), l.add(f);
  });
  const c = [], i = $(t), p = t.children || [];
  let b = s && l.size === o.length && p.length === o.length;
  const C = (v) => {
    const h = /* @__PURE__ */ new Map();
    return r.forEach((f, k) => {
      k >= v && D(f) && !h.has(f) && h.set(f, k);
    }), h;
  };
  let m = b ? void 0 : C(0), g = p.length === o.length, a = 0;
  const u = p.map((v, h) => {
    const f = Z(v), k = r[h];
    b && !(f === k || f !== f && k !== k) && (b = !1, m = C(h));
    const S = b ? h : D(f) ? m.get(f) : h < o.length && !rt(o[h]) ? h : void 0;
    let X;
    S !== void 0 && (a++, m && m.delete(f), c[S] = !0, X = o[S]);
    const R = J(v, X);
    return X && (R.oi = S), R.getParent = i, g = g && S === h && (R.nr === "N" || R.nr === "U" || R.nr === "T") && R.tag !== "portal", R;
  });
  return ae(b && a === o.length && o.length === p.length ? [] : o.filter((v, h) => !c[h]), e), g && a === o.length && n && !n.invalid && (t.so = n, t.sc = u), u;
}, q = /* @__PURE__ */ new Map();
let I = !1;
const Pe = (t, e) => {
  q.set(t, e), I || (I = !0, queueMicrotask(Ot));
}, Te = (t, e) => {
  const o = w.get(t);
  o && (o.up = () => {
    const n = o.vd.value;
    Pe(t, () => e(n));
  });
}, Le = (t) => () => {
  const e = w.get(t), o = e && e.up;
  return o ? (o(), !0) : !1;
}, Ot = () => {
  try {
    q.forEach((t, e) => {
      q.delete(e), t();
    });
  } finally {
    I = !!q.size, I && queueMicrotask(Ot);
  }
}, T = (t, e, o, n, r, l) => ({
  type: t,
  nr: void 0,
  tag: e,
  props: o,
  text: n,
  children: r,
  getParent: l,
  el: void 0,
  oi: void 0,
  oc: void 0,
  op: void 0,
  il: void 0,
  [qt]: !0
}), Me = () => {
  const t = Ct(), e = t && t.upR;
  e && e.length && e.forEach((o) => o());
}, Q = (t, ...e) => T("f", void 0, void 0, void 0, e), d = (t, e, ...o) => {
  const n = { value: void 0 }, r = Ht(n, o), l = De(t, e || {}, r);
  return V(l) || (n.value = l), l;
}, Bt = (t) => (e, o) => t, Ne = (t, e, o) => {
  const n = (r, l) => {
    if (!(!r || l.has(r))) {
      if (l.add(r), r.compChild) {
        const s = r.compChild.indexOf(e);
        s !== -1 && r.compChild.splice(s, 1, o);
      }
      n(r.getParent ? r.getParent() : void 0, l);
    }
  };
  n(t, /* @__PURE__ */ new Set());
}, Ae = (t, e, o, n) => {
  if (n.il)
    return;
  const r = O.value;
  r && (r.invalid = !0);
  const l = { ready: !1, invalid: !1 };
  O.value = l;
  try {
    P.value = !0;
    let s;
    try {
      const c = it(t, e, o);
      s = J(c, n);
      const { isRoot: i, getParent: p, we: b, ae: C } = n;
      if (s.getParent = p, !i && p) {
        const m = p(), g = m && m.children || [], a = g.indexOf(n);
        a !== -1 && g.splice(a, 1, s), Ne(m, n, s);
      } else
        s.isRoot = !0, s.we = b, s.ae = C;
    } finally {
      P.value = !1;
    }
    l.ready = !0, U(s);
  } finally {
    l.invalid = !0, O.value = r;
  }
}, De = (t, e, o) => {
  if (Rt(t))
    return Q(e, ...o);
  if (V(t)) {
    const n = it(t, e, o);
    if (P.value)
      return n;
    const r = at(n).resolve();
    return r.rs = n, r;
  }
  return T("e", t, e, void 0, o);
}, Ht = (t, e) => {
  const o = () => t.value;
  return e.map((n) => {
    const r = jt(n);
    return r.getParent = o, r;
  });
}, jt = (t) => {
  if (t == null || typeof t == "boolean")
    return T(null);
  if (Array.isArray(t)) {
    const e = { value: void 0 }, o = Ht(e, t), n = T("l", void 0, void 0, void 0, o);
    return e.value = n, n;
  } else if (typeof t == "string" || typeof t == "number")
    return T("t", void 0, void 0, t);
  return t;
}, Oe = (t, e, o) => (n = e) => {
  const r = P.value, l = E.value;
  P.value = !1;
  try {
    $t(n, t);
    const s = t(e, o);
    let c;
    if (typeof s == "function") {
      const i = s;
      c = zt.has(i) ? i(e, o) : i(Le(n), e, o);
    } else {
      let i = !0;
      c = (p) => i ? (i = !1, s) : t(p, o);
    }
    return Be(
      c,
      n,
      t,
      e,
      o
    );
  } finally {
    E.value = l, P.value = r;
  }
}, Kt = (t) => t.ctor ? at(
  t.rs || {
    ctor: t.ctor,
    props: t.compProps,
    children: t.compChild
  }
) : T(
  t.type,
  t.tag,
  t.props,
  t.text,
  t.children && [...t.children],
  t.getParent
), at = ({
  ctor: t,
  props: e,
  children: o
}) => it(t, { ...e }, [...o || []]), it = (t, e, o) => ({
  ctor: t,
  props: e,
  children: o,
  resolve: Oe(t, e, o)
}), Be = (t, e, o, n, r) => {
  const l = je(t), s = l(n), c = He(
    l,
    e,
    o,
    n,
    r
  );
  return Ut(s, e, o, n, r, c), Te(
    e,
    (i) => Ae(
      o,
      i.compProps || n,
      i.compChild || r,
      i
    )
  ), s;
}, He = (t, e, o, n, r) => {
  const l = () => {
    const s = E.value;
    try {
      It(e), Me();
      const c = t(n);
      return Ut(c, e, o, n, r, l), c;
    } finally {
      E.value = s;
    }
  };
  return l;
}, je = (t) => (e) => {
  const o = jt(t(e)), n = Q({}, o);
  return o.getParent = () => n, n;
}, Ut = (t, e, o, n, r, l) => {
  t.compProps = n, t.compChild = r, t.ctor = o, t.compKey = e, t.reRender = l;
  const s = w.get(e);
  s && (s.vd.value = t);
}, Ke = (t, e) => {
  let o = [], n = null;
  return (r) => {
    const l = t(), s = o.length === l.length && o.every((i, p) => i === l[p]);
    if (o = l, s && n)
      return n;
    const c = e(r);
    return n = c, c;
  };
}, mt = [
  "pretty",
  "large",
  "big",
  "small",
  "tall",
  "short",
  "long",
  "handsome",
  "plain",
  "quaint",
  "clean",
  "elegant",
  "easy",
  "angry",
  "crazy",
  "helpful",
  "mushy",
  "odd",
  "unsightly",
  "adorable",
  "important",
  "inexpensive",
  "cheap",
  "expensive",
  "fancy"
], wt = [
  "red",
  "yellow",
  "blue",
  "green",
  "pink",
  "brown",
  "purple",
  "brown",
  "white",
  "black",
  "orange"
], bt = [
  "table",
  "chair",
  "house",
  "bbq",
  "desk",
  "car",
  "pony",
  "cookie",
  "sandwich",
  "burger",
  "pizza",
  "mouse",
  "keyboard"
], Y = (t) => Math.round(Math.random() * 1e3) % t, Ue = () => `${mt[Y(mt.length)]} ${wt[Y(wt.length)]} ${bt[Y(bt.length)]}`;
let Et = 1;
const y = {
  state: { rows: [], selected: null },
  buildData(t) {
    const e = new Array(t);
    for (let o = 0; o < t; o += 1)
      e[o] = qe(Et, Ue()), Et += 1;
    return e;
  },
  run() {
    this.state.rows = this.buildData(1e3);
  },
  runLots() {
    this.state.rows = this.buildData(1e4);
  },
  add() {
    this.state.rows = this.state.rows.concat(this.buildData(1e3));
  },
  update() {
    const { rows: t } = this.state;
    for (let e = 0; e < t.length; e += 10)
      t[e].label += " !!!";
  },
  clear() {
    this.state.rows = [], this.state.selected = null;
  },
  swapRows() {
    const { rows: t } = this.state;
    if (t.length > 998) {
      const e = t[1];
      t[1] = t[998], t[998] = e;
    }
  },
  remove(t) {
    this.state.rows = this.state.rows.filter((e) => e.id !== t);
  },
  select(t) {
    this.state.selected = t;
  }
};
let B = () => {
};
function qe(t, e) {
  const o = () => {
    y.select(t), B();
  }, n = () => {
    y.remove(t), B();
  }, r = {
    id: t,
    label: e,
    view: Ke(
      () => [r.label, y.state.selected === t],
      () => /* @__PURE__ */ d("tr", { key: t, class: y.state.selected === t ? "danger" : void 0 }, /* @__PURE__ */ d("td", { class: "col-md-1" }, t), /* @__PURE__ */ d("td", { class: "col-md-4" }, /* @__PURE__ */ d("a", { onClick: o }, r.label)), /* @__PURE__ */ d("td", { class: "col-md-1" }, /* @__PURE__ */ d("a", { onClick: n }, /* @__PURE__ */ d("span", { class: "glyphicon glyphicon-remove", "aria-hidden": "true" }))), /* @__PURE__ */ d("td", { class: "col-md-6" }))
    )
  };
  return r;
}
const ze = Bt((t) => (B = t, () => /* @__PURE__ */ d(Q, null, y.state.rows.map((e) => e.view(e))))), We = Bt(() => {
  const t = (o) => () => {
    o(), B();
  }, e = [
    {
      id: "run",
      text: "Create 1,000 rows",
      onClick: t(() => y.run())
    },
    {
      id: "runlots",
      text: "Create 10,000 rows",
      onClick: t(() => y.runLots())
    },
    {
      id: "add",
      text: "Append 1,000 rows",
      onClick: t(() => y.add())
    },
    {
      id: "update",
      text: "Update every 10th row",
      onClick: t(() => y.update())
    },
    { id: "clear", text: "Clear", onClick: t(() => y.clear()) },
    {
      id: "swaprows",
      text: "Swap Rows",
      onClick: t(() => y.swapRows())
    }
  ];
  return () => /* @__PURE__ */ d("div", { class: "container" }, /* @__PURE__ */ d("div", { class: "jumbotron" }, /* @__PURE__ */ d("div", { class: "row" }, /* @__PURE__ */ d("div", { class: "col-md-6" }, /* @__PURE__ */ d("h1", null, 'Lithent-"keyed"')), /* @__PURE__ */ d("div", { class: "col-md-6" }, /* @__PURE__ */ d("div", { class: "row" }, e.map(({ id: o, text: n, onClick: r }) => /* @__PURE__ */ d("div", { key: o, class: "col-sm-6 smallpad" }, /* @__PURE__ */ d(
    "button",
    {
      type: "button",
      class: "btn btn-primary btn-block",
      id: o,
      onClick: r
    },
    n
  ))))))), /* @__PURE__ */ d("table", { class: "table table-hover table-striped test-data" }, /* @__PURE__ */ d("tbody", { id: "tbody" }, /* @__PURE__ */ d(ze, null))), /* @__PURE__ */ d("span", { class: "preloadicon glyphicon glyphicon-remove", "aria-hidden": "true" }));
});
let K = se(/* @__PURE__ */ d(We, null), document.getElementById("main"));
const Ie = () => {
  K == null || K(), K = void 0;
}, $e = () => {
  y.clear(), B = () => {
  };
};
export {
  Ie as disposeRoot,
  $e as releaseAppState
};
//# sourceMappingURL=main.mjs.map
