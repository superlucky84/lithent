const Ot = Symbol.for("lithentWDomSymbol"), x = { value: "" }, m = { value: null }, b = { value: !1 }, g = /* @__PURE__ */ new WeakMap(), jt = /* @__PURE__ */ new WeakSet(), Ht = (t, e) => {
  g.set(t, {
    ctor: e,
    vd: { value: null },
    up: () => {
    },
    upR: [],
    upS: { value: 0 },
    upD: [],
    upCB: [],
    mts: [],
    umts: [],
    wdCB: []
    // WDom creation callback queue
  });
}, vt = () => g.get(m.value), Kt = (t) => {
  m.value = t;
}, Ut = (t, e) => {
  m.value = t, Ht(t, e);
}, zt = (t) => {
  const e = g.get(t);
  e && (e.umts.forEach((o) => o()), e.umts = []);
}, w = (t) => t.getParent && t.getParent(), j = (t) => () => t, nt = Object.keys, yt = (t, e) => Object.prototype.propertyIsEnumerable.call(t, e), gt = (t, e) => {
  if (yt(t, e)) return !0;
  const o = Object.getPrototypeOf(t);
  return !Object.prototype.hasOwnProperty.call(t, e) && !!o && gt(o, e);
}, H = (t) => typeof t == "object" && t !== null, Wt = (t, e) => "ctor" in t ? t.ctor === (e && e.ctor) : t === (e && e.ctor), qt = (t, e) => e.type === "f" && // A component's node is a one-child fragment too: never update it in
// place as a plain fragment, or the component is never unmounted, nor
// update a plain fragment with one (a hoisted <Comp /> first drawn by a
// redraw), or it is never mounted.
!e.ctor && !t.ctor && !!e.children && e.children.length === (t.children && t.children.length), It = (t, e) => e.type === "e" && e.tag === t.tag && !!e.children && e.children.length === (t.children && t.children.length), rt = (t, e) => e.type === t.type, $t = (t, e) => e.type === t.type && (F(t) && F(e) || !!e.children && e.children.length === (t.children && t.children.length)), I = (t) => (t && t.compProps && t.compProps.key) ?? (t && t.props && t.props.key), M = (t) => t === "f" || t === "l", K = (t) => typeof t == "function" && !mt(t) || H(t) && "resolve" in t, mt = (t) => t === W, Ft = (t) => !t.type, C = ({ el: t, op: e, props: o }) => !!t && (t === (e && e.portal) || t === (o && o.portal)), $ = (t) => t[0] === "o" && t[1] === "n", X = (t) => A(I(t)), F = (t) => !!t && !!t.children && t.children.some(X), A = (t) => t != null, lt = (t, e) => t === "style" && H(e), Vt = (t, e) => t === "ref" && H(e), st = /* @__PURE__ */ new WeakMap(), ct = (t, e) => {
  const o = t.constructor.prototype;
  let n = st.get(o);
  n || st.set(o, n = /* @__PURE__ */ new Map());
  let r = n.get(e);
  if (r === void 0) {
    const l = Object.getOwnPropertyDescriptor(o, e);
    r = !!(l && l.get && l.set), n.set(e, r);
  }
  return r;
}, at = (t) => t.localName.includes("-") && t.constructor === HTMLElement, Gt = (t) => K(t) ? "c" : t.type || "et", Jt = {
  c: Wt,
  l: $t,
  t: rt,
  e: It,
  f: qt,
  et: rt
}, wt = (t) => {
  const e = vt();
  e && e.umts.push(t);
}, U = (t) => {
  const { compKey: e } = t;
  e && (t.il = !0, Xt(e)), bt(t);
}, bt = (t) => {
  if (t.tag === "portal" && t.el)
    for (const e in t.props)
      $(e) && t.el.removeEventListener(
        e.slice(2).toLowerCase(),
        t.props[e]
      );
  (t.children || []).forEach((e) => {
    e.compKey ? U(e) : bt(e);
  });
}, Xt = (t) => {
  zt(t), g.delete(t);
};
let V = [];
const Yt = (t) => {
  t.compKey && V.push(t);
}, P = () => {
  V.forEach(Zt), V = [];
}, Zt = (t) => {
  const { compKey: e } = t, o = e && g.get(e);
  if (o) {
    const n = o.mts;
    m.value = e, o.upS.value = 0, o.mts = [], n.forEach((r) => {
      const l = r();
      l && wt(l);
    });
  }
}, _t = (t) => {
  const { compKey: e } = t;
  if (e) {
    const o = g.get(e), n = o && o.wdCB;
    m.value = e, n && n.length > 0 && (o.wdCB = [], n.forEach((r) => {
      const l = r();
      typeof l == "function" && wt(l);
    }));
  }
}, Qt = (t) => {
  const { compKey: e } = t, o = e && g.get(e);
  if (o) {
    const n = o.upCB;
    m.value = e, o.upS.value = 0, t.ctor && (o.upCB = [], n.forEach((r) => r()));
  }
}, Et = () => new DocumentFragment(), Ct = (t, e, o) => o ? t.insertBefore(e, o) : t.tagName === "HTML" ? t.replaceWith(e) : t.appendChild(e), te = (t) => document.createElement(t), ee = (t, e, o, n) => {
  t.isRoot = !0, e = e || document.body, t.we = e;
  const r = T(t, n);
  return t.ae = o, Ct(e, r, o), P(), () => {
    const l = g.get(t.compProps), s = l && l.vd.value || t;
    U(s), oe(s);
  };
}, oe = (t) => Z(t, t.we), Y = (t) => {
  const e = w(t);
  Z(
    t,
    t.isRoot ? t.we : e && k(e)
  );
}, Z = (t, e) => {
  if (e && t.el) {
    const o = t.el.nodeType, n = C(t);
    o === 11 || n ? G(
      t,
      n ? t.el : e
    ) : (o === 1 || o === 3) && e.removeChild(t.el), t.el = void 0;
  }
}, G = (t, e) => {
  const o = t.oc || t.children || [];
  if (o.length > 1 && o.every((n) => {
    const r = n.el && n.el.nodeType;
    return (r === 1 || r === 3) && n.el.tagName !== "HTML" && !C(n);
  })) {
    let n = 0;
    for (let r = e.firstChild; r && n <= o.length; r = r.nextSibling)
      n++;
    if (n === o.length) {
      e.textContent = "", o.forEach((r) => r.el = void 0);
      return;
    }
  }
  o.forEach((n) => {
    const r = n.el && n.el.nodeType;
    if (C(n))
      G(n, n.el);
    else if (r === 1 || r === 3) {
      const l = n.el;
      l.tagName === "HTML" ? l.innerHTML = "" : l.remove();
    } else r === 11 && G(n, e);
  });
}, ne = (t, e) => {
  const o = k(e);
  t.forEach((n) => {
    U(n), Z(n, o);
  });
}, kt = (t) => {
  Y(t), St(t);
}, St = (t, e) => {
  e = e || T(t);
  const o = w(t);
  if (!o || !o.type) {
    t.isRoot && t.we && t.tag !== "portal" && (Ct(t.we, e, t.ae), P());
    return;
  }
  const n = k(o), r = _(t, o);
  n && (t.tag !== "portal" && n.insertBefore(e, r || null), P());
}, xt = (t) => M(t.type) ? (t.children || []).reduce((e, o) => {
  const n = xt(o);
  return n && !C(o) && e.appendChild(n), e;
}, Et()) : t.el, _ = (t, e) => {
  const o = e.children || [];
  return B(o.slice(o.indexOf(t) + 1)) || (M(e.type) ? e.isRoot ? e.ae : _(e, w(e)) : void 0);
}, D = /* @__PURE__ */ new Set(), B = (t) => t.reduce(
  (e, o) => {
    if (e || C(o) || D.size && D.has(o))
      return e;
    const { type: n, el: r } = o;
    if (n && M(n)) {
      const l = B(o.children || []);
      if (l) return l;
    }
    return r && r.nodeType !== 11 ? r : e;
  },
  void 0
), re = (t) => {
  const e = w(t), o = t.el;
  if (o && (e ? e.type : t.isRoot))
    if (!e || o.nodeType === 11 || C(t) || t.tag === "portal")
      kt(t);
    else {
      const n = k(e), r = T(t);
      n && n.replaceChild(r, o), P();
    }
}, it = (t) => {
  if (t.type === "t") {
    ae(t);
    return;
  }
  if (t.el) {
    const { op: e, props: o } = t;
    Rt(o, t.el, e), t.tag === "input" && (t.el.value = String(
      o && o.value || ""
    ));
  }
  le(t), Qt(t);
}, le = (t) => {
  const e = t.children || [];
  if (t.type !== "l" || !e.some(
    (i) => "ATS".includes(i.nr) || i.oi !== void 0
  )) {
    e.forEach(J);
    return;
  }
  const o = [], n = [], r = [];
  let l = !0;
  e.forEach((i, u) => {
    const y = i.oi, S = i.nr;
    S === "S" ? r.push(i) : S !== "A" && y !== void 0 && (y < n[n.length - 1] && (l = !1), o.push(u), n.push(y));
  });
  let s;
  if (!l) {
    const i = s = [];
    se(n).forEach((u) => i[o[u]] = !0), o.forEach(
      (u) => i[u] || (i[u] = !1, r.push(e[u]))
    );
  }
  const c = [];
  let a = 0;
  r.forEach((i) => D.add(i));
  try {
    e.forEach((i, u) => {
      const y = i.nr;
      y === "A" || y === "S" ? (y === "S" && Y(i), c[u] = T(i), a++) : J(i);
    });
  } finally {
    r.forEach((i) => D.delete(i));
  }
  const d = k(t), v = t.isRoot ? t.ae : _(t, w(t));
  let h = e.length;
  for (; h > 0 && c[h - 1] !== void 0; )
    h--;
  for (let i = h; i < e.length; i++) {
    const u = c[i];
    u && d && e[i].tag !== "portal" && d.insertBefore(u, v || null);
  }
  if (s || a > e.length - h) {
    let i = B(e.slice(h)) || v;
    for (let u = h - 1; u >= 0; u--) {
      const y = e[u], S = c[u] !== void 0, Bt = !!s && s[u] === !1;
      if ((S || Bt) && d && y.tag !== "portal") {
        const ot = S ? c[u] : xt(y);
        ot && d.insertBefore(ot, i || null);
      }
      const et = B([y]);
      et && (i = et);
    }
  }
  e.forEach(Pt), P();
}, Pt = (t) => {
  t.oi = t.oc = t.op = void 0, t.nr = "N";
}, se = (t) => {
  const e = [], o = [];
  t.forEach((l, s) => {
    let c = 0, a = e.length;
    if (a && t[e[a - 1]] < l)
      c = a;
    else
      for (; c < a; ) {
        const d = c + a >> 1;
        t[e[d]] < l ? c = d + 1 : a = d;
      }
    o[s] = c ? e[c - 1] : -1, e[c] = s;
  });
  let n = e.length, r = e[n - 1];
  for (; n-- > 0; )
    e[n] = r, r = o[r];
  return e;
}, J = (t) => {
  const { nr: e } = t;
  e && e !== "N" && (ce[e](t), Pt(t));
}, ce = {
  A: St,
  D: Y,
  R: re,
  U: it,
  S: kt,
  // A keyed item reaches here only as a component redrawing itself: it has
  // not moved, so it is updated in place. Re-inserting its nodes would blur a
  // focused input inside it or reload an iframe. Moves within a list are
  // placed by updateChildren.
  T: it
}, ae = (t) => {
  t.el && (t.el.nodeValue = String(t.text));
}, Rt = (t, e, o) => {
  const n = o || {};
  for (const r in t) {
    const l = t[r];
    l !== n[r] && ($(r) ? pt(
      e,
      r,
      l,
      n[r]
    ) : r === "key" || r === "portal" && H(l) || (r === "innerHTML" && typeof l == "string" ? e.innerHTML = l : lt(r, l) ? de(
      l,
      lt(r, n.style) ? n.style : {},
      e
    ) : Vt(r, l) ? l.value = e : r && (r !== "type" && ct(e, r) ? e[r] = l : (ie(
      r === "className" ? "class" : r,
      e,
      l
    ), at(e) && !(r in HTMLElement.prototype) && (e[r] = l)))));
  }
  for (const r in n)
    if (!(t && gt(t, r))) {
      if ($(r)) {
        pt(
          e,
          r,
          void 0,
          n[r]
        );
        continue;
      }
      e.removeAttribute(r), at(e) ? delete e[r] : e.localName.includes("-") && ct(e, r) && (e[r] = void 0);
    }
}, ie = (t, e, o) => x.value && t !== "xmlns" ? e.setAttributeNS(null, t, o) : e.setAttribute(t, o), T = (t, e) => {
  let o;
  const { type: n, tag: r, text: l, props: s, children: c = [] } = t, a = M(n);
  if (_t(t), r === "svg" && (x.value = String(s && s.xmlns)), !e) {
    if (!n || a)
      o = Et();
    else if (n === "e" && r)
      r === "portal" && s && s.portal ? o = s.portal : o = x.value ? document.createElementNS(x.value, r) : te(r);
    else if (n === "t" && A(l))
      o = document.createTextNode(String(l));
    else
      throw Error("Invalid wDom");
    t.el = o;
  }
  return pe(t, c, o, e), Rt(s, o, null), Yt(t), r === "svg" && (x.value = ""), o;
}, pe = (t, e, o, n) => {
  const r = j(t);
  e.forEach((l, s) => {
    if (l.nr === "N" && !n) {
      const c = At(l);
      l = e[s] = "resolve" in c ? c.resolve() : c;
    }
    if (l.getParent = r, l.nr = "N", l.type) {
      const c = T(l, n);
      l.tag !== "portal" && !n && o && o.appendChild(c);
    }
  });
}, pt = (t, e, o, n) => {
  const r = e.slice(2).toLowerCase();
  n !== o && (n && t.removeEventListener(r, n), o && t.addEventListener(r, o));
}, de = (t, e, o) => {
  const n = { ...e };
  if (!(o instanceof HTMLElement)) return;
  const r = o.style;
  for (const l in t)
    r[l] = t[l], delete n[l];
  for (const l in n)
    r[l] = "";
}, k = (t) => M(t.type) ? t.isRoot ? t.we : k(w(t)) : t.el, z = (t, e) => (t !== e && t.nr && (t = At(t)), ue(
  t,
  !!e && Jt[Gt(t)](t, e),
  e
)), ue = (t, e, o) => {
  const n = ge(t, e, o), r = fe(
    n,
    e,
    o
  ), l = r === "N";
  return l || (n.children = me(
    n,
    e,
    o
  )), n.nr = r, he(n, o, r), !l && o && (o.il = !0, o.ctor && (o.children = void 0)), n;
}, he = (t, e, o) => {
  o !== "A" && e && (t.el = e.el), (o === "D" || o === "R" || o === "S") && (e && U(e), t.oc = e && e.children), t.op = e && e.props;
}, fe = (t, e, o) => {
  if (Ft(t)) return "D";
  if (t === o || e && t.type === "t" && t.text === o.text)
    return "N";
  if (!(o && o.type)) return "A";
  const n = w(o), r = !t.isRoot && n && n.type === "l" && X(t);
  return e ? r ? "T" : "U" : r ? "S" : "R";
}, ve = (t, e) => {
  t && e !== t && (e = e || {}, nt(t).forEach(
    (o) => yt(e, o) || delete t[o]
  ), nt(e).forEach((o) => t[o] = e[o]));
}, ye = (t, e) => {
  const { compProps: o, compChild: n } = t, { props: r, children: l } = e;
  return o && ve(o, r), n && l && n !== l && n.splice(0, n.length, ...l), t.reRender && t.reRender();
}, ge = (t, e, o) => K(t) ? e && o ? ye(o, t) : (
  // Resolved before (children a component draws again somewhere else):
  // the first instance owns its props, which are also its key, so the
  // new instance is made from a copy.
  (t.rd ? Q(t) : (t.rd = !0, t)).resolve()
) : t, me = (t, e, o) => e && o ? be(t, o) : we(t), we = (t) => {
  const e = j(t);
  return (t.children || []).map((o) => {
    const n = z(o);
    return n.getParent = e, n;
  });
}, be = (t, e) => {
  if (t.type === "l" && F(t))
    return Ee(t, e);
  const o = e.children || [], n = j(t);
  return (t.children || []).map((r, l) => {
    const s = z(r, o[l]);
    return s.getParent = n, s;
  });
}, Ee = (t, e) => {
  const o = e.children || [], n = /* @__PURE__ */ new Map();
  o.forEach((c, a) => {
    const d = I(c);
    A(d) && !n.has(d) && n.set(d, a);
  });
  const r = [], l = j(t), s = (t.children || []).map((c, a) => {
    const d = I(c), v = A(d) ? n.get(d) : a < o.length && !X(o[a]) ? a : void 0;
    let h;
    v !== void 0 && (n.delete(d), r[v] = !0, h = o[v]);
    const i = z(c, h);
    return h && (i.oi = v), i.getParent = l, i;
  });
  return ne(
    o.filter((c, a) => !r[a]),
    e
  ), s;
}, N = /* @__PURE__ */ new Map();
let O = !1;
const Ce = (t, e) => {
  N.set(t, e), O || (O = !0, queueMicrotask(Mt));
}, ke = (t, e) => {
  const o = g.get(t);
  o && (o.up = () => {
    const n = o.vd.value;
    Ce(t, () => e(n));
  });
}, Se = (t) => () => {
  const e = g.get(t), o = e && e.up;
  return o ? (o(), !0) : !1;
}, Mt = () => {
  try {
    N.forEach((t, e) => {
      N.delete(e), t();
    });
  } finally {
    O = !!N.size, O && queueMicrotask(Mt);
  }
}, E = (t, e, o, n, r, l) => ({
  type: t,
  nr: void 0,
  tag: e,
  props: o,
  text: n,
  children: r,
  getParent: l,
  el: void 0,
  oi: void 0,
  oc: void 0,
  op: void 0,
  il: void 0,
  [Ot]: !0
}), xe = () => {
  const t = vt(), e = t && t.upR;
  e && e.length && e.forEach((o) => o());
}, W = (t, ...e) => E("f", void 0, void 0, void 0, e), p = (t, e, ...o) => {
  const n = { value: void 0 }, r = Lt(n, o), l = Me(t, e || {}, r);
  return K(l) || (n.value = l), l;
}, Tt = (t) => (e, o) => t, Pe = (t, e, o) => {
  const n = (r, l) => {
    if (!(!r || l.has(r))) {
      if (l.add(r), r.compChild) {
        const s = r.compChild.indexOf(e);
        s !== -1 && r.compChild.splice(s, 1, o);
      }
      n(r.getParent ? r.getParent() : void 0, l);
    }
  };
  n(t, /* @__PURE__ */ new Set());
}, Re = (t, e, o, n) => {
  if (n.il)
    return;
  b.value = !0;
  let r;
  try {
    const l = tt(t, e, o);
    r = z(l, n);
    const { isRoot: s, getParent: c, we: a, ae: d } = n;
    if (r.getParent = c, !s && c) {
      const v = c(), h = v && v.children || [], i = h.indexOf(n);
      i !== -1 && h.splice(i, 1, r), Pe(v, n, r);
    } else
      r.isRoot = !0, r.we = a, r.ae = d;
  } finally {
    b.value = !1;
  }
  J(r);
}, Me = (t, e, o) => {
  if (mt(t))
    return W(e, ...o);
  if (K(t)) {
    const n = tt(t, e, o);
    if (b.value)
      return n;
    const r = Q(n).resolve();
    return r.rs = n, r;
  }
  return E("e", t, e, void 0, o);
}, Lt = (t, e) => {
  const o = () => t.value;
  return e.map((n) => {
    const r = Nt(n);
    return r.getParent = o, r;
  });
}, Nt = (t) => {
  if (t == null || typeof t == "boolean")
    return E(null);
  if (Array.isArray(t)) {
    const e = { value: void 0 }, o = Lt(e, t), n = E("l", void 0, void 0, void 0, o);
    return e.value = n, n;
  } else if (typeof t == "string" || typeof t == "number")
    return E("t", void 0, void 0, t);
  return t;
}, Te = (t, e, o) => (n = e) => {
  const r = b.value, l = m.value;
  b.value = !1;
  try {
    Ut(n, t);
    const s = t(e, o);
    let c;
    if (typeof s == "function") {
      const a = s;
      c = jt.has(a) ? a(e, o) : a(Se(n), e, o);
    } else {
      let a = !0;
      c = (d) => a ? (a = !1, s) : t(d, o);
    }
    return Le(
      c,
      n,
      t,
      e,
      o
    );
  } finally {
    m.value = l, b.value = r;
  }
}, At = (t) => t.ctor ? Q(
  t.rs || {
    ctor: t.ctor,
    props: t.compProps,
    children: t.compChild
  }
) : E(
  t.type,
  t.tag,
  t.props,
  t.text,
  t.children && [...t.children],
  t.getParent
), Q = ({
  ctor: t,
  props: e,
  children: o
}) => tt(t, { ...e }, [...o || []]), tt = (t, e, o) => ({
  ctor: t,
  props: e,
  children: o,
  resolve: Te(t, e, o)
}), Le = (t, e, o, n, r) => {
  const l = Ae(t), s = l(n), c = Ne(
    l,
    e,
    o,
    n,
    r
  );
  return Dt(s, e, o, n, r, c), ke(
    e,
    (a) => Re(
      o,
      a.compProps || n,
      a.compChild || r,
      a
    )
  ), s;
}, Ne = (t, e, o, n, r) => {
  const l = () => {
    const s = m.value;
    try {
      Kt(e), xe();
      const c = t(n);
      return Dt(c, e, o, n, r, l), c;
    } finally {
      m.value = s;
    }
  };
  return l;
}, Ae = (t) => (e) => {
  const o = Nt(t(e)), n = W({}, o);
  return o.getParent = () => n, n;
}, Dt = (t, e, o, n, r, l) => {
  t.compProps = n, t.compChild = r, t.ctor = o, t.compKey = e, t.reRender = l;
  const s = g.get(e);
  s && (s.vd.value = t);
}, De = (t, e) => {
  let o = [], n = null;
  return (r) => {
    const l = t(), s = o.length === l.length && o.every((a, d) => a === l[d]);
    if (o = l, s && n)
      return n;
    const c = e(r);
    return n = c, c;
  };
}, dt = [
  "pretty",
  "large",
  "big",
  "small",
  "tall",
  "short",
  "long",
  "handsome",
  "plain",
  "quaint",
  "clean",
  "elegant",
  "easy",
  "angry",
  "crazy",
  "helpful",
  "mushy",
  "odd",
  "unsightly",
  "adorable",
  "important",
  "inexpensive",
  "cheap",
  "expensive",
  "fancy"
], ut = [
  "red",
  "yellow",
  "blue",
  "green",
  "pink",
  "brown",
  "purple",
  "brown",
  "white",
  "black",
  "orange"
], ht = [
  "table",
  "chair",
  "house",
  "bbq",
  "desk",
  "car",
  "pony",
  "cookie",
  "sandwich",
  "burger",
  "pizza",
  "mouse",
  "keyboard"
], q = (t) => Math.round(Math.random() * 1e3) % t, Be = () => `${dt[q(dt.length)]} ${ut[q(ut.length)]} ${ht[q(ht.length)]}`;
let ft = 1;
const f = {
  state: { rows: [], selected: null },
  buildData(t) {
    const e = new Array(t);
    for (let o = 0; o < t; o += 1)
      e[o] = Oe(ft, Be()), ft += 1;
    return e;
  },
  run() {
    this.state.rows = this.buildData(1e3);
  },
  runLots() {
    this.state.rows = this.buildData(1e4);
  },
  add() {
    this.state.rows = this.state.rows.concat(this.buildData(1e3));
  },
  update() {
    const { rows: t } = this.state;
    for (let e = 0; e < t.length; e += 10)
      t[e].label += " !!!";
  },
  clear() {
    this.state.rows = [], this.state.selected = null;
  },
  swapRows() {
    const { rows: t } = this.state;
    if (t.length > 998) {
      const e = t[1];
      t[1] = t[998], t[998] = e;
    }
  },
  remove(t) {
    this.state.rows = this.state.rows.filter((e) => e.id !== t);
  },
  select(t) {
    this.state.selected = t;
  }
};
let R = () => {
};
function Oe(t, e) {
  const o = () => {
    f.select(t), R();
  }, n = () => {
    f.remove(t), R();
  }, r = {
    id: t,
    label: e,
    view: De(
      () => [r.label, f.state.selected === t],
      () => /* @__PURE__ */ p("tr", { key: t, class: f.state.selected === t ? "danger" : void 0 }, /* @__PURE__ */ p("td", { class: "col-md-1" }, t), /* @__PURE__ */ p("td", { class: "col-md-4" }, /* @__PURE__ */ p("a", { onClick: o }, r.label)), /* @__PURE__ */ p("td", { class: "col-md-1" }, /* @__PURE__ */ p("a", { onClick: n }, /* @__PURE__ */ p("span", { class: "glyphicon glyphicon-remove", "aria-hidden": "true" }))), /* @__PURE__ */ p("td", { class: "col-md-6" }))
    )
  };
  return r;
}
const je = Tt((t) => (R = t, () => /* @__PURE__ */ p(W, null, f.state.rows.map((e) => e.view(e))))), He = Tt(() => {
  const t = (o) => () => {
    o(), R();
  }, e = [
    {
      id: "run",
      text: "Create 1,000 rows",
      onClick: t(() => f.run())
    },
    {
      id: "runlots",
      text: "Create 10,000 rows",
      onClick: t(() => f.runLots())
    },
    {
      id: "add",
      text: "Append 1,000 rows",
      onClick: t(() => f.add())
    },
    {
      id: "update",
      text: "Update every 10th row",
      onClick: t(() => f.update())
    },
    { id: "clear", text: "Clear", onClick: t(() => f.clear()) },
    {
      id: "swaprows",
      text: "Swap Rows",
      onClick: t(() => f.swapRows())
    }
  ];
  return () => /* @__PURE__ */ p("div", { class: "container" }, /* @__PURE__ */ p("div", { class: "jumbotron" }, /* @__PURE__ */ p("div", { class: "row" }, /* @__PURE__ */ p("div", { class: "col-md-6" }, /* @__PURE__ */ p("h1", null, 'Lithent-"keyed"')), /* @__PURE__ */ p("div", { class: "col-md-6" }, /* @__PURE__ */ p("div", { class: "row" }, e.map(({ id: o, text: n, onClick: r }) => /* @__PURE__ */ p("div", { key: o, class: "col-sm-6 smallpad" }, /* @__PURE__ */ p(
    "button",
    {
      type: "button",
      class: "btn btn-primary btn-block",
      id: o,
      onClick: r
    },
    n
  ))))))), /* @__PURE__ */ p("table", { class: "table table-hover table-striped test-data" }, /* @__PURE__ */ p("tbody", { id: "tbody" }, /* @__PURE__ */ p(je, null))), /* @__PURE__ */ p("span", { class: "preloadicon glyphicon glyphicon-remove", "aria-hidden": "true" }));
});
let L = ee(/* @__PURE__ */ p(He, null), document.getElementById("main"));
const Ke = () => {
  L == null || L(), L = void 0;
}, Ue = () => {
  f.clear(), R = () => {
  };
};
export {
  Ke as disposeRoot,
  Ue as releaseAppState
};
//# sourceMappingURL=main.mjs.map
