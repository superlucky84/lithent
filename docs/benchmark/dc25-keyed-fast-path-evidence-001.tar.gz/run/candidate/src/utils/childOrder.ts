export type ChildOrderFrame = { ready: boolean; invalid: boolean };
// Frames hold no nodes/arrays. Unvisited list metadata cannot retain a root tree.
export const childOrderRef: { value?: ChildOrderFrame } = {};
