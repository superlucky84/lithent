import original from "/Users/n250109005/project/lithent/playwright.config.ts";
export default {
 ...original, testDir: "/Users/n250109005/project/lithent/e2e",
 outputDir: "/private/tmp/lithent-dc25-20261027/browser-checks/test-results",
 use: { ...original.use, launchOptions: { executablePath: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" } },
 webServer: original.webServer.map((entry, index) => ({ ...entry, cwd: "/Users/n250109005/project/lithent/",
   command: "'/Users/n250109005/.volta/tools/image/node/24.22.1/bin/node' '/private/tmp/lithent-dc25-20261027/browser-checks/server.mjs' " + (index ? 'concurrent' : 'base') }))
};
