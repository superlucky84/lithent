import original from "/Users/n250109005/project/lithent/playwright.config.ts";
export default { ...original, testDir: "/Users/n250109005/project/lithent/e2e",
 outputDir: "/private/tmp/lithent-dc25-20261027/default-browser/test-results",
 use: { ...original.use, launchOptions: { executablePath: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" } },
 webServer: original.webServer.map(entry => ({ ...entry, cwd: "/Users/n250109005/project/lithent/" }))
};
