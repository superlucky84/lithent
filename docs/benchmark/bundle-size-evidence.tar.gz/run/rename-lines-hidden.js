(function(e,t){typeof exports=="object"&&typeof module<"u"?t(exports):typeof define=="function"&&define.amd?define(["exports"],t):(e=typeof globalThis<"u"?globalThis:e||self,t(e.lithent={}))})(this,(function(e){"use strict"
const t=Symbol.for("lithentWDomSymbol"),o={value:""},n={value:null},r={value:!1},l=new WeakMap,c=new WeakSet
let s=!1
const i=(e,t)=>{l.set(e,{ctor:t,vd:{value:null},up:()=>{},upR:[],upS:{value:0},upD:[],upCB:[],mts:[],umts:[],wdCB:[]})},a=()=>n.value,p=()=>l.get(n.value),u=(e,t)=>{const o=l.get(e)
return o?o[t]:null},d=e=>{n.value=e},f=(e,t)=>{n.value=e,i(e,t)},h=e=>{s=e},v=()=>s,y=e=>{const t=l.get(e)
t&&(t.umts.forEach((e=>e())),t.umts=[])},g=e=>{y(e),l.delete(e)},m=e=>e.getParent&&e.getParent(),E=e=>()=>e,C=Object.keys,w=(e,t)=>Object.prototype.propertyIsEnumerable.call(e,t),P=(e,t)=>{if(w(e,t))return!0
const o=Object.getPrototypeOf(e)
return!Object.prototype.hasOwnProperty.call(e,t)&&!!o&&P(o,t)},S=e=>typeof e=="object"&&e!==null,b=e=>S(e)&&!Array.isArray(e)&&!Object.getOwnPropertySymbols(e).includes(t),T=(e,t)=>"ctor"in e?e.ctor===(t&&t.ctor):e===(t&&t.ctor),M=(e,t)=>t.type==="f"&&!t.ctor&&!e.ctor&&!!t.children&&t.children.length===(e.children&&e.children.length),R=(e,t)=>t.type==="e"&&t.tag===e.tag&&!!t.children&&t.children.length===(e.children&&e.children.length),x=(e,t)=>t.type===e.type,N=(e,t)=>t.type===e.type&&(H(e)&&H(t)||!!t.children&&t.children.length===(e.children&&e.children.length)),L=e=>(e&&e.compProps&&e.compProps.key)??(e&&e.props&&e.props.key),O=e=>e==="f"||e==="l",k=e=>typeof e=="function"&&!A(e)||S(e)&&"resolve"in e,A=e=>e===ot,B=e=>!e.type,D=e=>e[0]==="o"&&e[1]==="n",j=e=>K(L(e)),H=e=>!!e&&!!e.children&&e.children.some(j),K=e=>e!=null,W=(e,t)=>e==="style"&&S(t),I=(e,t)=>e==="ref"&&S(t),U=new WeakMap,q=(e,t)=>{const o=e.constructor.prototype
let n=U.get(o)
n||U.set(o,n=new Map)
let r=n.get(t)
if(r===void 0){const e=Object.getOwnPropertyDescriptor(o,t)
r=!!(e&&e.get&&e.set),n.set(t,r)}return r},z=e=>e.localName.includes("-")&&e.constructor===HTMLElement,F=e=>k(e)?"c":e.type||"et",V={c:T,l:N,t:x,e:R,f:M,et:x},G=e=>{const t=p()
t&&t.umts.push(e)},J=e=>{const{compKey:t}=e
t&&(e.il=!0,X(t)),Q(e)},Q=e=>{if(e.tag==="portal"&&e.el)for(const t in e.props)D(t)&&e.el.removeEventListener(t.slice(2).toLowerCase(),e.props[t]);(e.children||[]).forEach((e=>{e.compKey?J(e):Q(e)}))},X=e=>{y(e),v()||l.delete(e)}
let Y=[]
const Z=e=>{e.compKey&&Y.push(e)},$=()=>{Y.forEach(ee),Y=[]},_=e=>{const t=p()
t&&t.mts.push(e)},ee=e=>{const{compKey:t}=e,o=t&&l.get(t)
if(o){const e=o.mts
n.value=t,o.upS.value=0,o.mts=[],e.forEach((e=>{const t=e()
t&&G(t)}))}},te=e=>{const t=p()
t&&t.wdCB.push(e)},oe=e=>{const{compKey:t}=e
if(t){const e=l.get(t),o=e&&e.wdCB
n.value=t,o&&o.length>0&&(e.wdCB=[],o.forEach((e=>{const t=e()
typeof t=="function"&&G(t)})))}},ne=(e,t=(()=>[]))=>{const o=p()
if(!o)return
const{upD:n,upS:r}=o,l=n[r.value],c=t()
if(l&&le(l,c)){const t=e()
t&&o.upCB.push(t)}n[r.value]=c,r.value+=1},re=e=>{const{compKey:t}=e,o=t&&l.get(t)
if(o){const r=o.upCB
n.value=t,o.upS.value=0,e.ctor&&(o.upCB=[],r.forEach((e=>e())))}},le=(e,t)=>e.length?e.some(((e,o)=>e!==t[o])):!0,ce=()=>new DocumentFragment,se=(e,t,o)=>o?e.insertBefore(t,o):e.tagName==="HTML"?e.replaceWith(t):e.appendChild(t),ie=e=>document.createElement(e),ae=(e,t,o,n)=>{e.isRoot=!0,t=t||document.body,e.we=t
const r=Oe(e,n)
return e.ae=o,(o||!n)&&se(t,r,o),$(),()=>{const t=l.get(e.compProps),o=t&&t.vd.value||e
J(o),pe(o)}},pe=e=>de(e,e.we),ue=e=>{const t=m(e)
de(e,e.isRoot?e.we:t&&De(t))},de=(e,t)=>{if(t&&e.el){const o=e.el.nodeType
o===11||e.tag==="portal"?fe(e,t):(o===1||o===3)&&t.removeChild(e.el),e.el=void 0}},fe=(e,t)=>{const o=e.oc||e.children||[]
if(o.length>1&&o.every((e=>{const t=e.el&&e.el.nodeType
return(t===1||t===3)&&e.el.tagName!=="HTML"&&e.tag!=="portal"}))){let e=0
for(let n=t.firstChild;n&&e<=o.length;n=n.nextSibling)e++
if(e===o.length){t.textContent="",o.forEach((e=>e.el=void 0))
return}}o.forEach((e=>{const o=e.el&&e.el.nodeType
if(o)if(o===1||o===3){const t=e.el
t.tagName==="HTML"?t.innerHTML="":t.remove()}else o===11&&fe(e,t)}))},he=(e,t)=>{const o=De(t)
e.forEach((e=>{J(e),de(e,o)}))},ve=e=>{ue(e),ye(e)},ye=(e,t)=>{t=t||Oe(e)
const o=m(e)
if(!o||!o.type){e.isRoot&&e.we&&e.tag!=="portal"&&(se(e.we,t,e.ae),$())
return}const n=De(o),r=me(e,o)
n&&(e.tag!=="portal"&&n.insertBefore(t,r||null),$())},ge=e=>O(e.type)?(e.children||[]).reduce(((e,t)=>{const o=ge(t)
return o&&e.appendChild(o),e}),ce()):e.el,me=(e,t)=>{const o=t.children||[]
return Ce(o.slice(o.indexOf(e)+1))||(O(t.type)?t.isRoot?t.ae:me(t,m(t)):void 0)},Ee=new Set,Ce=e=>e.reduce(((e,t)=>{if(e||Ee.size&&Ee.has(t))return e
const{type:o,el:n}=t
if(o&&O(o)){const e=Ce(t.children||[])
if(e)return e}return n&&n.nodeType!==11?n:e}),void 0),we=e=>{const t=m(e),o=e.el
if(o&&(t?t.type:e.isRoot))if(!t||o.nodeType===11)ve(e)
else{const n=De(t),r=Oe(e)
n&&e.tag!=="portal"&&n.replaceChild(r,o),$()}},Pe=e=>{if(e.type==="t"){xe(e)
return}if(e.el){const{op:t,props:o}=e
Ne(o,e.el,t),e.tag==="input"&&(e.el.value=String(o&&o.value||""))}Se(e),re(e)},Se=e=>{const t=e.children||[]
if(e.type!=="l"||!t.some((e=>"ATS".includes(e.nr)||e.oi!==void 0))){t.forEach(Me)
return}const o=[],n=[],r=[]
let l=!0
t.forEach(((e,t)=>{const c=e.oi,s=e.nr
s==="S"?r.push(e):s!=="A"&&c!==void 0&&(c<n[n.length-1]&&(l=!1),o.push(t),n.push(c))}))
let c
if(!l){const e=c=[]
Te(n).forEach((t=>e[o[t]]=!0)),o.forEach((o=>e[o]||(e[o]=!1,r.push(t[o]))))}const s=[]
let i=0
r.forEach((e=>Ee.add(e)))
try{t.forEach(((e,t)=>{const o=e.nr
o==="A"||o==="S"?(o==="S"&&ue(e),s[t]=Oe(e),i++):Me(e)}))}finally{r.forEach((e=>Ee.delete(e)))}const a=De(e),p=e.isRoot?e.ae:me(e,m(e))
let u=t.length
for(;u>0&&s[u-1]!==void 0;)u--
for(let e=u;e<t.length;e++){const o=s[e]
o&&a&&t[e].tag!=="portal"&&a.insertBefore(o,p||null)}if(c||i>t.length-u){let e=Ce(t.slice(u))||p
for(let o=u-1;o>=0;o--){const n=t[o],r=s[o]!==void 0,l=!!c&&c[o]===!1
if((r||l)&&a&&n.tag!=="portal"){const t=r?s[o]:ge(n)
t&&a.insertBefore(t,e||null)}const i=Ce([n])
i&&(e=i)}}t.forEach(be),$()},be=e=>{e.oi=e.oc=e.op=void 0,e.nr="N"},Te=e=>{const t=[],o=[]
e.forEach(((n,r)=>{let l=0,c=t.length
if(c&&e[t[c-1]]<n)l=c
else for(;l<c;){const o=l+c>>1
e[t[o]]<n?l=o+1:c=o}o[r]=l?t[l-1]:-1,t[l]=r}))
let n=t.length,r=t[n-1]
for(;n-- >0;)t[n]=r,r=o[r]
return t},Me=e=>{const{nr:t}=e
t&&t!=="N"&&(Re[t](e),be(e))},Re={A:ye,D:ue,R:we,U:Pe,S:ve,T:Pe},xe=e=>{e.el&&(e.el.nodeValue=String(e.text))},Ne=(e,t,o)=>{const n=o||{}
for(const o in e){const r=e[o]
r!==n[o]&&(D(o)?Ae(t,o,r,n[o]):o==="key"||o==="portal"&&S(r)||(o==="innerHTML"&&typeof r=="string"?t.innerHTML=r:W(o,r)?Be(r,W(o,n.style)?n.style:{},t):I(o,r)?r.value=t:o&&(o!=="type"&&q(t,o)?t[o]=r:(Le(o==="className"?"class":o,t,r),z(t)&&!(o in HTMLElement.prototype)&&(t[o]=r)))))}for(const o in n)if(!(e&&P(e,o))){if(D(o)){Ae(t,o,void 0,n[o])
continue}t.removeAttribute(o),z(t)?delete t[o]:t.localName.includes("-")&&q(t,o)&&(t[o]=void 0)}},Le=(e,t,n)=>o.value&&e!=="xmlns"?t.setAttributeNS(null,e,n):t.setAttribute(e,n),Oe=(e,t)=>{let n
const{type:r,tag:l,text:c,props:s,children:i=[]}=e,a=O(r)
if(oe(e),l==="svg"&&(o.value=String(s&&s.xmlns)),t)n=e.el
else{if(!r||a)n=ce()
else if(r==="e"&&l)l==="portal"&&s&&s.portal?n=s.portal:n=o.value?document.createElementNS(o.value,l):ie(l)
else if(r==="t"&&K(c))n=document.createTextNode(String(c))
else throw Error("Invalid wDom")
e.el=n}return ke(e,i,n,t),Ne(s,n,null),Z(e),l==="svg"&&(o.value=""),n},ke=(e,t,o,n)=>{const r=E(e)
t.forEach(((e,l)=>{if(e.nr==="N"&&!n){const o=ft(e)
e=t[l]="resolve"in o?o.resolve():o}if(e.getParent=r,e.nr="N",e.type){const t=Oe(e,n)
e.tag!=="portal"&&!n&&o&&o.appendChild(t)}}))},Ae=(e,t,o,n)=>{const r=t.slice(2).toLowerCase()
n!==o&&(n&&e.removeEventListener(r,n),o&&e.addEventListener(r,o))},Be=(e,t,o)=>{const n={...t}
if(!(o instanceof HTMLElement))return
const r=o.style
for(const t in e)r[t]=e[t],delete n[t]
for(const e in n)r[e]=""},De=e=>O(e.type)?e.isRoot?e.we:De(m(e)):e.el,je=(e,t)=>(e!==t&&e.nr&&(e=ft(e)),He(e,!!t&&V[F(e)](e,t),t)),He=(e,t,o)=>{const n=qe(e,t,o),r=We(n,t,o),l=r==="N"
return l||(n.children=ze(n,t,o)),n.nr=r,Ke(n,o,r),!l&&o&&(o.il=!0,o.ctor&&(o.children=void 0)),o&&o.tag==="portal"&&(n.tag="portal"),n},Ke=(e,t,o)=>{o!=="A"&&t&&(e.el=t.el),(o==="D"||o==="R"||o==="S")&&(t&&J(t),e.oc=t&&t.children),e.op=t&&t.props},We=(e,t,o)=>{if(B(e))return"D"
if(e===o||t&&e.type==="t"&&e.text===o.text)return"N"
if(!(o&&o.type))return"A"
const n=m(o),r=!e.isRoot&&n&&n.type==="l"&&j(e)
return t?r?"T":"U":r?"S":"R"},Ie=(e,t)=>{e&&t!==e&&(t=t||{},C(e).forEach((o=>w(t,o)||delete e[o])),C(t).forEach((o=>e[o]=t[o])))},Ue=(e,t)=>{const{compProps:o,compChild:n}=e,{props:r,children:l}=t
return o&&Ie(o,r),n&&l&&n!==l&&n.splice(0,n.length,...l),e.reRender&&e.reRender()},qe=(e,t,o)=>k(e)?t&&o?Ue(o,e):(e.rd?ht(e):(e.rd=!0,e)).resolve():e,ze=(e,t,o)=>t&&o?Ve(e,o):Fe(e),Fe=e=>{const t=E(e)
return(e.children||[]).map((e=>{const o=je(e)
return o.getParent=t,o}))},Ve=(e,t)=>{if(e.type==="l"&&H(e))return Ge(e,t)
const o=t.children||[],n=E(e)
return(e.children||[]).map(((e,t)=>{const r=je(e,o[t])
return r.getParent=n,r}))},Ge=(e,t)=>{const o=t.children||[],n=new Map
o.forEach(((e,t)=>{const o=L(e)
K(o)&&!n.has(o)&&n.set(o,t)}))
const r=[],l=E(e),c=(e.children||[]).map(((e,t)=>{const c=L(e),s=K(c)?n.get(c):t<o.length&&!j(o[t])?t:void 0
let i
s!==void 0&&(n.delete(c),r[s]=!0,i=o[s])
const a=je(e,i)
return i&&(a.oi=s),a.getParent=l,a}))
return he(o.filter(((e,t)=>!r[t])),t),c},Je=new Map
let Qe=!1
const Xe=(e,t)=>{Je.set(e,t),Qe||(Qe=!0,queueMicrotask($e))},Ye=(e,t)=>{const o=l.get(e)
o&&(o.up=()=>{const n=o.vd.value
Xe(e,(()=>t(n)))})},Ze=e=>()=>{const t=l.get(e),o=t&&t.up
return o?(o(),!0):!1},$e=()=>{try{Je.forEach(((e,t)=>{Je.delete(t),e()}))}finally{Qe=!!Je.size,Qe&&queueMicrotask($e)}},_e=(e,o,n,r,l,c)=>({type:e,nr:void 0,tag:o,props:n,text:r,children:l,getParent:c,el:void 0,oi:void 0,oc:void 0,op:void 0,il:void 0,[t]:!0}),et=(e,t=(()=>[]))=>{const o=p()
o&&(o.upR.push((()=>ne(e,t))),ne(e,t))},tt=()=>{const e=p(),t=e&&e.upR
t&&t.length&&t.forEach((e=>e()))},ot=(e,...t)=>_e("f",void 0,void 0,void 0,t),nt=(e,t,...o)=>{const n={value:void 0},r=pt(n,o),l=at(e,t||{},r)
return k(l)||(n.value=l),l},rt=(e,t)=>nt("portal",{portal:t},e),lt=e=>(t,o)=>e,ct=e=>(t,o)=>(c.add(e),e),st=(e,t,o)=>{const n=(e,r)=>{if(!(!e||r.has(e))){if(r.add(e),e.compChild){const n=e.compChild.indexOf(t)
n!==-1&&e.compChild.splice(n,1,o)}n(e.getParent?e.getParent():void 0,r)}}
n(e,new Set)},it=(e,t,o,n)=>{if(n.il)return
r.value=!0
let l
try{const r=vt(e,t,o)
l=je(r,n)
const{isRoot:c,getParent:s,we:i,ae:a}=n
if(l.getParent=s,!c&&s){const e=s(),t=e&&e.children||[],o=t.indexOf(n)
o!==-1&&t.splice(o,1,l),st(e,n,l)}else l.isRoot=!0,l.we=i,l.ae=a}finally{r.value=!1}Me(l)},at=(e,t,o)=>{if(A(e))return ot(t,...o)
if(k(e)){const n=vt(e,t,o)
if(r.value)return n
const l=ht(n).resolve()
return l.rs=n,l}return _e("e",e,t,void 0,o)},pt=(e,t)=>{const o=()=>e.value
return t.map((e=>{const t=ut(e)
return t.getParent=o,t}))},ut=e=>{if(e==null||typeof e=="boolean")return _e(null)
if(Array.isArray(e)){const t={value:void 0},o=pt(t,e),n=_e("l",void 0,void 0,void 0,o)
return t.value=n,n}else if(typeof e=="string"||typeof e=="number")return _e("t",void 0,void 0,e)
return e},dt=(e,t,o)=>(l=t)=>{const s=r.value,i=n.value
r.value=!1
try{f(l,e)
const n=e(t,o)
let r
if(typeof n=="function"){const e=n
r=c.has(e)?e(t,o):e(Ze(l),t,o)}else{let t=!0
r=r=>t?(t=!1,n):e(r,o)}return yt(r,l,e,t,o)}finally{n.value=i,r.value=s}},ft=e=>e.ctor?ht(e.rs||{ctor:e.ctor,props:e.compProps,children:e.compChild}):_e(e.type,e.tag,e.props,e.text,e.children&&[...e.children],e.getParent),ht=({ctor:e,props:t,children:o})=>vt(e,{...t},[...o||[]]),vt=(e,t,o)=>({ctor:e,props:t,children:o,resolve:dt(e,t,o)}),yt=(e,t,o,n,r)=>{const l=mt(e),c=l(n),s=gt(l,t,o,n,r)
return Et(c,t,o,n,r,s),Ye(t,(e=>it(o,e.compProps||n,e.compChild||r,e))),c},gt=(e,t,o,r,l)=>{const c=()=>{const s=n.value
try{d(t),tt()
const n=e(r)
return Et(n,t,o,r,l,c),n}finally{n.value=s}}
return c},mt=e=>t=>{const o=ut(e(t)),n=ot({},o)
return o.getParent=()=>n,n},Et=(e,t,o,n,r,c)=>{e.compProps=n,e.compChild=r,e.ctor=o,e.compKey=t,e.reRender=c
const s=l.get(t)
s&&(s.vd.value=e)},Ct=e=>({value:e}),wt=()=>Promise.resolve(),Pt=()=>{const e=a()
return e?Ze(e):()=>!1}
e.Fragment=ot,e.componentMap=l,e.componentUpdate=Ze,e.disposeComponentEntry=g,e.getComponentKey=a,e.getComponentSubInfo=u,e.h=nt,e.isPropType=b,e.lmount=ct,e.lmountComponentSet=c,e.mount=lt,e.mountCallback=_,e.mountReadyCallback=te,e.nextTick=wt,e.portal=rt,e.ref=Ct,e.render=ae,e.replaceWDom=it,e.setComponentMapManualMode=h,e.updateCallback=et,e.useRenew=Pt,Object.defineProperty(e,Symbol.toStringTag,{value:"Module"})}))

