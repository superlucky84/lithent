const S = Symbol.for("lithentWDomSymbol"), O = { value: "" }, k = { value: null }, M = { value: !1 }, h = /* @__PURE__ */ new WeakMap(), Lt = /* @__PURE__ */ new WeakSet();
let Bt = !1;
const ie = (t, e) => {
  h.set(t, {
    ctor: e,
    vd: { value: null },
    up: () => {
    },
    upR: [],
    upS: { value: 0 },
    upD: [],
    upCB: [],
    mts: [],
    umts: [],
    wdCB: []
    // WDom creation callback queue
  });
}, ue = () => k.value, A = () => h.get(k.value), Ot = (t, e) => {
  const n = h.get(t);
  return n ? n[e] : null;
}, ae = (t) => {
  k.value = t;
}, fe = (t, e) => {
  k.value = t, ie(t, e);
}, Tn = (t) => {
  Bt = t;
}, pe = () => Bt, Ft = (t) => {
  const e = h.get(t);
  e && (e.umts.forEach((n) => n()), e.umts = []);
}, An = (t) => {
  Ft(t), h.delete(t);
}, R = (t) => t.getParent && t.getParent(), Ut = (t) => () => t, Ct = Object.keys, Vt = (t, e) => Object.prototype.propertyIsEnumerable.call(t, e), _t = (t, e) => {
  if (Vt(t, e)) return !0;
  const n = Object.getPrototypeOf(t);
  return !Object.prototype.hasOwnProperty.call(t, e) && !!n && _t(n, e);
}, U = (t) => typeof t == "object" && t !== null, de = Object.assign, Ln = (t) => U(t) && !Array.isArray(t) && !Object.getOwnPropertySymbols(t).includes(S), he = (t, e) => "ctor" in t ? t.ctor === (e && e.ctor) : t === (e && e.ctor), ye = (t, e) => e.type === "f" && // A component's node is a one-child fragment too: never update it in
// place as a plain fragment, or the component is never unmounted, nor
// update a plain fragment with one (a hoisted <Comp /> first drawn by a
// redraw), or it is never mounted.
!e.ctor && !t.ctor && !!e.children && e.children.length === (t.children && t.children.length), ve = (t, e) => e.type === "e" && e.tag === t.tag && !!e.children && e.children.length === (t.children && t.children.length), kt = (t, e) => e.type === t.type, ge = (t, e) => e.type === t.type && ($(t) && $(e) || !!e.children && e.children.length === (t.children && t.children.length)), Z = (t) => (t && t.compProps && t.compProps.key) ?? (t && t.props && t.props.key), T = (t) => t === "f" || t === "l", K = (t) => typeof t == "function" && !It(t) || U(t) && "resolve" in t, It = (t) => t === at, Ce = (t) => !t.type, ke = (t) => t[0] === "o" && t[1] === "n", ct = (t) => I(Z(t)), $ = (t) => !!t && !!t.children && t.children.some(ct), I = (t) => t != null, Pt = (t, e) => t === "style" && U(e), Pe = (t, e) => t === "ref" && U(e), Et = /* @__PURE__ */ new WeakMap(), Rt = (t, e) => {
  const n = t.constructor.prototype;
  let s = Et.get(n);
  s || Et.set(n, s = /* @__PURE__ */ new Map());
  let c = s.get(e);
  if (c === void 0) {
    const o = Object.getOwnPropertyDescriptor(n, e);
    c = !!(o && o.get && o.set), s.set(e, c);
  }
  return c;
}, bt = (t) => t.localName.includes("-") && t.constructor === HTMLElement, Ee = (t) => K(t) ? "c" : t.type || "et", Re = {
  c: he,
  l: ge,
  t: kt,
  e: ve,
  f: ye,
  et: kt
}, Qt = (t) => {
  const e = A();
  e && e.umts.push(t);
}, Y = (t) => {
  const { compKey: e } = t;
  e && (t.il = !0, be(e)), jt(t);
}, jt = (t) => {
  if (t.tag === "portal" && t.el)
    for (const e in t.props)
      ke(e) && t.el.removeEventListener(
        e.slice(2).toLowerCase(),
        t.props[e]
      );
  (t.children || []).forEach((e) => {
    e.compKey ? Y(e) : jt(e);
  });
}, be = (t) => {
  Ft(t), pe() || h.delete(t);
};
let q = [];
const zt = (t) => {
  t.compKey && q.push(t);
}, Ht = () => {
  q.forEach(Se), q = [];
}, Bn = (t) => {
  const e = A();
  e && e.mts.push(t);
}, Se = (t) => {
  const { compKey: e } = t, n = e && h.get(e);
  if (n) {
    const s = n.mts;
    k.value = e, n.upS.value = 0, n.mts = [], s.forEach((c) => {
      const o = c();
      o && Qt(o);
    });
  }
}, On = (t) => {
  const e = A();
  e && e.wdCB.push(t);
}, Kt = (t) => {
  const { compKey: e } = t;
  if (e) {
    const n = h.get(e), s = n && n.wdCB;
    k.value = e, s && s.length > 0 && (n.wdCB = [], s.forEach((c) => {
      const o = c();
      typeof o == "function" && Qt(o);
    }));
  }
}, St = (t, e = () => []) => {
  const n = A();
  if (!n) return;
  const { upD: s, upS: c } = n, o = s[c.value], r = e();
  if (o && xe(o, r)) {
    const l = t();
    l && n.upCB.push(l);
  }
  s[c.value] = r, c.value += 1;
}, Me = (t) => {
  const { compKey: e } = t, n = e && h.get(e);
  if (n) {
    const s = n.upCB;
    k.value = e, n.upS.value = 0, t.ctor && (n.upCB = [], s.forEach((c) => c()));
  }
}, xe = (t, e) => t.length ? t.some((n, s) => n !== e[s]) : !0, G = () => new DocumentFragment(), m = /* @__PURE__ */ new WeakMap(), Ne = (t) => {
  const e = t.el, n = [], s = [], c = { ready: n, mounted: s }, o = L(t, !1, c);
  t.el = e, c.hasPortal || m.set(t, { el: o, ready: n, mounted: s });
}, w = (t, e) => e && e.parentNode === t ? e : null, rt = (t) => {
  const e = m.get(t);
  if (e)
    return m.delete(t), t.el = e.el, e.ready.forEach(Kt), e.mounted.forEach(zt), e.el;
}, Te = (t) => document.createElement(t), Fn = (t, e, n, s) => {
  t.isRoot = !0, e = e || document.body, t.we = e;
  const c = L(t, s);
  return n ? (t.ae = n, e.insertBefore(c, n)) : s || (e.tagName === "HTML" ? e.replaceWith(c) : e.appendChild(c)), Ht(), () => {
    const o = h.get(t.compProps || {}), r = o && o.vd.value || t;
    Y(r), Ae(r);
  };
}, Ae = (t) => it(t, t.we), lt = (t) => {
  const e = R(t), n = t.isRoot ? t.we : e ? B(e) : void 0;
  n && it(t, n);
}, it = (t, e) => {
  if (e && t.el) {
    const n = t.el.nodeType;
    n === 11 || (t == null ? void 0 : t.tag) === "portal" ? Yt(t, e) : (n === 1 || n === 3) && e.removeChild(t.el), t.el = void 0;
  }
}, Yt = (t, e) => {
  const n = t && t.oc || t && t.children || [];
  if (n.length > 1 && n.every((s) => {
    const c = s.el && s.el.nodeType;
    return (c === 1 || c === 3) && s.el.tagName !== "HTML" && s.tag !== "portal";
  })) {
    let s = 0;
    for (let c = e.firstChild; c && s <= n.length; c = c.nextSibling)
      s++;
    if (s === n.length) {
      e.textContent = "", n.forEach((c) => c.el = void 0);
      return;
    }
  }
  n.forEach((s) => {
    const c = s.el && s.el.nodeType;
    if (c)
      if (c === 1 || c === 3) {
        const o = s.el;
        o.tagName === "HTML" ? o.innerHTML = "" : o.remove();
      } else c === 11 && Yt(s, e);
  });
}, Le = (t, e) => {
  const n = B(e);
  t.forEach((s) => {
    Y(s), it(s, n);
  });
}, W = (t) => {
  lt(t), Xt(t);
}, Xt = (t, e) => {
  e || (e = rt(t) || L(t));
  const n = R(t);
  if (!n || !n.type) {
    t.isRoot && t.we && e && t.tag !== "portal" && (t.ae ? t.we.insertBefore(e, t.ae) : t.we.tagName === "HTML" ? t.we.replaceWith(e) : t.we.appendChild(e));
    return;
  }
  const s = B(n), c = ut(t, n, s);
  e && s && t.tag !== "portal" && s.insertBefore(e, w(s, c));
}, Jt = (t) => T(t.type) ? (t && t.children || []).reduce((e, n) => {
  const s = Jt(n);
  return s && e.appendChild(s), e;
}, G()) : t.el, ut = (t, e, n) => {
  const s = e.children || [], o = s.indexOf(t) + 1, r = s.slice(o), l = j(
    r,
    n
  ), i = e.type || "";
  if (l)
    return l;
  if (!e.isRoot && T(i))
    return ut(
      e,
      R(e),
      n
    );
  if (e.isRoot && T(i) && e.ae)
    return e.ae;
}, Q = /* @__PURE__ */ new Set(), j = (t, e) => t.reduce(
  (n, s) => {
    if (n || Q.size && Q.has(s)) return n;
    const { type: c, el: o } = s;
    if (c && T(c)) {
      const r = j(
        s.children || [],
        e
      );
      if (r) return r;
    }
    return o && o.nodeType !== 11 && (!e || o.parentNode === e) ? o : n;
  },
  void 0
), Be = (t) => {
  const e = R(t), n = t.el;
  if (t.isRoot && !e && n) {
    W(t);
    return;
  }
  if (e && e.type && n)
    if (n.nodeType === 11)
      W(t);
    else {
      const s = B(e), c = rt(t) || L(t);
      s && t.tag !== "portal" && s.replaceChild(c, n);
    }
}, D = (t) => {
  if (t.type === "t") {
    Ve(t);
    return;
  }
  if (t.el) {
    const { op: e, props: n } = t;
    $t(n, t.el, e), t.tag === "input" && (t.el.value = String(
      n && n.value || ""
    ));
  }
  Oe(t), Me(t);
}, Oe = (t) => {
  const e = t.children || [];
  let n = !1;
  if (t.type === "l") {
    for (const u of e)
      if ("ATS".includes(u.nr) || u.oi !== void 0) {
        n = !0;
        break;
      }
  }
  if (!n) {
    e.forEach((u) => tt(u));
    return;
  }
  const s = [], c = [], o = [];
  let r = !0;
  e.forEach((u, d) => {
    const v = u.oi;
    u.nr === "A" || u.nr === "S" ? o.push(u) : v !== void 0 && (v < c[c.length - 1] && (r = !1), s.push(d), c.push(v));
  });
  let l;
  if (!r) {
    const u = l = [];
    s.forEach((d) => u[d] = !1), Fe(c).forEach((d) => u[s[d]] = !0), s.forEach((d) => u[d] || o.push(e[d]));
  }
  const i = [];
  let a = 0;
  o.forEach((u) => Q.add(u));
  try {
    e.forEach((u, d) => {
      const v = u.nr;
      v === "A" || v === "S" ? (v === "S" && lt(u), i[d] = rt(u) || L(u), a++) : v === "T" ? D(u) : tt(u);
    });
  } finally {
    o.forEach((u) => Q.delete(u));
  }
  const p = B(t), P = t.isRoot ? t.ae : ut(t, R(t), p);
  let b = e.length;
  for (; b > 0 && i[b - 1] !== void 0; )
    b--;
  for (let u = b; u < e.length; u++) {
    const d = i[u];
    d && p && e[u].tag !== "portal" && p.insertBefore(d, w(p, P));
  }
  if (l || a > e.length - b) {
    let u = j(e.slice(b), p) || P;
    for (let d = b - 1; d >= 0; d--) {
      const v = e[d], yt = i[d] !== void 0, le = !!l && l[d] === !1;
      if ((yt || le) && p && v.tag !== "portal") {
        const gt = yt ? i[d] : Jt(v);
        gt && p.insertBefore(gt, w(p, u));
      }
      const vt = j([v], p);
      vt && (u = vt);
    }
  }
  e.forEach(Zt);
}, Zt = (t) => {
  t.oi = t.oc = t.op = void 0, t.nr = "N";
}, Fe = (t) => {
  const e = [];
  if (!t.length)
    return e;
  const n = new Array(t.length);
  e.push(0);
  for (let o = 1; o < t.length; o++) {
    const r = t[o];
    if (t[e[e.length - 1]] < r) {
      n[o] = e[e.length - 1], e.push(o);
      continue;
    }
    let l = 0, i = e.length - 1;
    for (; l < i; ) {
      const a = l + i >> 1;
      t[e[a]] < r ? l = a + 1 : i = a;
    }
    r < t[e[l]] && (l > 0 && (n[o] = e[l - 1]), e[l] = o);
  }
  let s = e.length, c = e[s - 1];
  for (; s-- > 0; )
    e[s] = c, c = n[c];
  return e;
}, tt = (t) => {
  const { nr: e } = t;
  e !== void 0 && e !== "N" && (Ue[e](t), Zt(t));
}, Ue = {
  A: Xt,
  D: lt,
  R: Be,
  U: D,
  S: W,
  // A keyed item reaches here only as a component redrawing itself: it has
  // not moved, so it is updated in place. Re-inserting its nodes would blur a
  // focused input inside it or reload an iframe. Moves within a list are
  // placed by updateChildren.
  T: D
}, Ve = (t) => {
  t.el && (t.el.nodeValue = String(t.text));
}, $t = (t, e, n, s) => {
  const c = n || {};
  for (const o in t) {
    const r = t[o];
    if (r === c[o])
      continue;
    const l = o[0] === "o" && o[1] === "n";
    s && l ? X(
      e,
      o,
      r,
      c[o]
    ) : o === "key" || o === "portal" && U(r) || (o === "innerHTML" && typeof r == "string" ? e.innerHTML = r : Pt(o, r) ? Qe(
      r,
      Pt(o, c.style) ? c.style : {},
      e
    ) : Pe(o, r) ? r.value = e : l ? X(
      e,
      o,
      r,
      c[o]
    ) : o && (o !== "type" && Rt(e, o) ? e[o] = r : (_e(
      o === "className" ? "class" : o,
      e,
      r
    ), bt(e) && !(o in HTMLElement.prototype) && (e[o] = r))));
  }
  for (const o in c)
    if (!(t && _t(t, o))) {
      if (o[0] === "o" && o[1] === "n") {
        X(
          e,
          o,
          void 0,
          c[o]
        );
        continue;
      }
      e.removeAttribute(o), bt(e) ? delete e[o] : e.localName.includes("-") && Rt(e, o) && (e[o] = void 0);
    }
}, _e = (t, e, n) => O.value && t !== "xmlns" ? e.setAttributeNS(null, t, n) : e.setAttribute(t, n), L = (t, e, n) => {
  let s;
  const { type: c, tag: o, text: r, props: l, children: i = [] } = t, a = T(c);
  if (n && o === "portal")
    return n.hasPortal = !0, l == null ? void 0 : l.portal;
  if (n ? t.compKey && n.ready.push(t) : Kt(t), o === "svg" && (O.value = String(l && l.xmlns)), e)
    s = t.el;
  else {
    if (!c)
      s = G();
    else if (a)
      s = G();
    else if (c === "e" && o)
      o === "portal" && l && l.portal ? s = l.portal : s = O.value ? document.createElementNS(O.value, o) : Te(o);
    else if (c === "t" && I(r))
      s = document.createTextNode(String(r));
    else
      throw Error("Invalid wDom");
    t.el = s;
  }
  return Ie(t, i, s, e, n), $t(l, s, null, e), n ? t.compKey && n.mounted.push(t) : zt(t), o === "svg" && (O.value = ""), s;
}, Ie = (t, e, n, s, c) => {
  const o = Ut(t);
  e.forEach((r, l) => {
    if (r.nr === "N" && !s) {
      const i = ce(r);
      r = e[l] = "resolve" in i ? i.resolve() : i;
    }
    if (r.getParent = o, r.nr = "N", r.type) {
      const i = L(r, s, c);
      r.tag !== "portal" && !s && n && n.appendChild(i);
    }
  });
}, X = (t, e, n, s) => {
  const c = e.slice(2).toLowerCase();
  s !== n && (s && t.removeEventListener(c, s), n && t.addEventListener(c, n));
}, Qe = (t, e, n) => {
  const s = { ...e }, c = n instanceof HTMLElement ? n : null, o = c == null ? void 0 : c.style;
  if (!o) return;
  const r = o;
  for (const l in t)
    r[l] = t[l], delete s[l];
  for (const l in s)
    r[l] = "";
}, B = (t) => {
  const e = T(t.type);
  return t.isRoot && e ? t.we : e ? B(R(t)) : t.el;
}, f = Object.assign(h, {
  renderGate: {
    beforePause() {
      if (M.value)
        throw new Error("Pause outside component rendering");
    }
  }
}).renderGate, je = (t, e, n) => {
  const s = [Mt(t, e)];
  return {
    advance: (c) => {
      for (; ; ) {
        const o = s[s.length - 1];
        if (o.cursor < o.children.length)
          s.push(
            Mt(
              o.children[o.cursor],
              o.originals[o.cursor],
              o
            )
          );
        else {
          if (Ke(o, n), s.pop(), !s.length)
            return o.wip;
          Xe(o);
        }
        if (c && c())
          return null;
      }
    }
  };
}, ze = (t, e) => !!e && Re[Ee(t)](t, e), He = (t) => {
  t.forEach((e) => e());
}, Mt = (t, e, n) => {
  t !== e && t.nr && (t = ce(t));
  const s = ze(t, e), c = me(t, s, e), o = Ze(c, s, e);
  c.nr = o;
  const r = {
    wip: c,
    needRerender: o,
    isSameType: s,
    originalWDom: e,
    children: V,
    originals: V,
    matchedIndexes: V,
    unused: null,
    built: V,
    cursor: 0,
    getParent: void 0,
    parent: n
  };
  return o !== "N" && we(r), r;
}, V = [], Ke = (t, e) => {
  const { wip: n, originalWDom: s, needRerender: c } = t, o = c === "N";
  if (!o) {
    if (t.unused) {
      const r = t.unused;
      e.push(() => Le(r, s));
    }
    n.children = t.built;
  }
  n.nr = c, Je(n, s, e, c), !o && s && e.push(() => {
    s.il = !0, s.ctor && (s.children = void 0);
  }), s && s.tag === "portal" && (n.tag = "portal"), xt(c) && n.type && !xt(Ye(t)) && Ne(n);
}, xt = (t) => t === "A" || t === "R" || t === "S", Ye = (t) => t.parent && t.parent.needRerender, Xe = (t) => {
  var c;
  const e = t.parent, n = e.cursor, s = e.matchedIndexes[n];
  s !== void 0 && (t.wip.oi = s), t.wip === t.originalWDom && ((c = f.reparent) == null || c.call(f, t.wip)), t.wip.getParent = e.getParent, e.built[n] = t.wip, e.cursor = n + 1;
}, Je = (t, e, n, s) => {
  s !== "A" && e && (t.el = e.el), (s === "D" || s === "R" || s === "S") && (e && n.push(() => Y(e)), t.oc = e && e.children), t.op = e && e.props;
}, Ze = (t, e, n) => {
  if (Ce(t)) return "D";
  if (t.type === "t" && e && t.text === (n && n.text) || t === n) return "N";
  if (!(n && n.type)) return "A";
  const o = R(n), r = !t.isRoot && o && o.type === "l" && ct(t);
  return e ? r ? "T" : "U" : r ? "S" : "R";
}, $e = (t, e) => {
  t && e !== t && (e = e || {}, Ct(t).forEach(
    (n) => Vt(e, n) || delete t[n]
  ), Ct(e).forEach((n) => t[n] = e[n]));
}, qe = (t, e) => {
  t && (t.splice(0, t.length), e && e.forEach((n) => t.push(n)));
}, Ge = (t, e) => {
  var l;
  const { compProps: n, compChild: s } = t, { props: c, children: o } = e;
  return n && $e(n, c), s && o && s !== o && qe(s, o), (l = f.blocks) != null && l.call(f, t) ? t : t.reRender && t.reRender();
}, me = (t, e, n) => K(t) ? e && n ? Ge(n, t) : (
  // Resolved before (children a component draws again somewhere else):
  // the first instance owns its props, which are also its key, so the
  // new instance is made from a copy.
  (t.rd ? dt(t) : (t.rd = !0, t)).resolve()
) : t, we = (t) => {
  const { wip: e, isSameType: n, originalWDom: s } = t, c = e.children;
  if (!c || !c.length || (t.children = c, t.built = new Array(c.length), t.getParent = Ut(e), !n || !s))
    return;
  t.originals = new Array(c.length);
  const o = s.children || [];
  if (e.type === "l" && $(e)) {
    t.matchedIndexes = new Array(c.length);
    const r = /* @__PURE__ */ new Map(), l = [];
    o.forEach((i, a) => {
      const p = Z(i);
      I(p) && !r.has(p) && r.set(p, a);
    }), c.forEach((i, a) => {
      const p = Z(i), P = I(p) ? r.get(p) : a < o.length && !ct(o[a]) ? a : void 0;
      P !== void 0 && (r.delete(p), l[P] = !0, t.originals[a] = o[P], t.matchedIndexes[a] = P);
    }), t.unused = o.filter((i, a) => !l[a]);
    return;
  }
  c.forEach((r, l) => {
    t.originals[l] = o[l];
  });
}, _ = { value: "sync" }, y = {
  sync: /* @__PURE__ */ new Map(),
  low: /* @__PURE__ */ new Map()
}, Un = (t) => {
  const e = _.value;
  _.value = "low";
  try {
    t();
  } finally {
    _.value = e;
  }
}, We = 5;
let De = We, et = !1, z = !1, qt = 0, J = null, H = [], g = null;
const tn = (t) => {
  g = t, x("low");
}, en = () => {
  g = null;
}, nt = () => {
  if (g) {
    const t = g;
    g = null, t();
  }
}, st = () => performance.now() >= qt, nn = () => {
  if (typeof MessageChannel != "function") {
    setTimeout(Nt);
    return;
  }
  if (!J) {
    const t = new MessageChannel();
    t.port1.onmessage = Nt, J = t.port2;
  }
  J.postMessage(null);
}, x = (t) => {
  t === "sync" ? et || (et = !0, queueMicrotask(sn)) : z || (z = !0, nn());
}, sn = () => {
  const t = E;
  E = !1;
  try {
    y.sync.forEach((e, n) => {
      y.sync.delete(n), e();
    });
  } finally {
    et = !1, E = t, y.sync.size && x("sync");
  }
};
let E = !1;
const on = f.beforePause;
f.beforePause = (t) => {
  var n;
  on();
  const e = E;
  E = !1;
  try {
    (n = f.settle) == null || n.call(f, t);
  } finally {
    E = e;
  }
};
const cn = () => E, Nt = () => {
  z = !1, E = !0;
  try {
    rn();
  } finally {
    E = !1, (y.low.size || g || H.length) && x("low");
  }
}, rn = () => {
  if (qt = performance.now() + De, g) {
    const n = g;
    if (g = null, n(), (y.low.size || g) && st()) {
      x("low");
      return;
    }
  }
  const t = y.low;
  for (const [n, s] of t)
    if (t.delete(n), s(), t.size && st()) {
      x("low");
      return;
    }
  if (g) {
    x("low");
    return;
  }
  const e = H;
  H = [], e.forEach((n) => n());
}, Tt = /* @__PURE__ */ new WeakMap(), ln = (t, e) => {
  const n = h.get(t);
  n && (Tt.set(t, e), n.up = () => {
    const s = _.value;
    if (s === "sync")
      y.low.delete(t);
    else if (y.sync.has(t))
      return;
    y[s].set(t, () => (Tt.get(t) || e)()), x(s);
  });
}, Vn = (t, e) => e ? y[e].has(t) : y.sync.has(t) || y.low.has(t), _n = () => y.low.size || z || g ? new Promise((t) => {
  H.push(t);
}) : Promise.resolve(), Gt = { value: 0 }, mt = () => Gt.value, In = () => {
  Gt.value += 1;
}, wt = (t) => () => {
  const e = h.get(t), n = e && e.up;
  return n ? (n(), !0) : !1;
}, Qn = (t, e = () => []) => {
  const n = A();
  n && (n.upR.push(() => St(t, e)), St(t, e));
}, un = () => {
  const t = A(), e = t && t.upR;
  e && e.length && e.forEach((n) => n());
}, at = (t, ...e) => ({
  type: "f",
  // fragment
  nr: void 0,
  [S]: !0,
  children: e
}), an = (t, e, ...n) => {
  const s = { value: void 0 }, c = se(s, n), o = Rn(t, e || {}, c);
  return K(o) || (s.value = o), o;
}, jn = (t, e) => an("portal", { portal: e }, t), zn = (t) => (e, n) => t, Hn = (t) => (e, n) => (Lt.add(t), t), fn = (t, e, n) => {
  const s = (c, o) => {
    if (!(!c || o.has(c))) {
      if (o.add(c), c.compChild) {
        const r = c.compChild.indexOf(e);
        r !== -1 && c.compChild.splice(r, 1, n);
      }
      s(c.getParent ? c.getParent() : void 0, o);
    }
  };
  s(t, /* @__PURE__ */ new Set());
}, pn = 2;
let N = null;
const dn = () => {
  N && (N.mounted = !0);
}, hn = (t) => {
  if (!N)
    return;
  const e = h.get(t);
  e && N.snapshots.push({
    compKey: t,
    // `upD` slots are replaced wholesale, never mutated in place, so copying
    // the outer array is enough.
    upD: [...e.upD],
    upCB: [...e.upCB],
    upS: e.upS.value,
    mts: [...e.mts]
  });
}, ft = (t) => t.some((e) => {
  const n = h.get(e.compKey);
  if (!n)
    return !1;
  for (let s = 0; s < n.upS.value; s++) {
    const c = e.upD[s], o = n.upD[s] || [];
    if (c && (!c.length || c.some((r, l) => r !== o[l])))
      return !0;
  }
  return !1;
}), pt = (t) => {
  for (let e = t.length - 1; e >= 0; e--) {
    const n = t[e], s = h.get(n.compKey);
    s && (s.upD = n.upD, s.upCB = n.upCB, s.upS.value = n.upS, s.mts = n.mts);
  }
};
let C = null;
const yn = (t, e, n, s) => {
  var o;
  let c = s;
  if (!(c.il || (o = f.blocks) != null && o.call(f, c))) {
    if (C) {
      if (C.props === e)
        if (C.trace.mounted || ft(C.trace.snapshots)) {
          if (nt(), c = ot(e) || c, c.il)
            return;
        } else
          ee();
      else if (Wt(C.props, e) && (nt(), c.il && (c = ot(e) || c, c.il)))
        return;
    }
    te(vn(t, e, n, c));
  }
}, At = (t, e) => {
  let n = ot(e);
  for (; n; )
    if (n = R(n), n && n.compKey === t)
      return !0;
  return !1;
}, Wt = (t, e) => At(t, e) || At(e, t), vn = (t, e, n, s) => {
  const c = {
    tag: t,
    props: e,
    children: n,
    originalWDom: s,
    trace: { snapshots: [], mounted: !1 },
    attempt: 0,
    startVersion: 0,
    effects: [],
    work: { advance: () => null }
  };
  return Dt(c), c;
}, Dt = (t) => {
  t.startVersion = mt(), t.trace.snapshots = [], t.trace.mounted = !1, t.effects = [], ne(t, () => {
    t.work = je(
      ht(t.tag, t.props, t.children),
      t.originalWDom,
      t.effects
    );
  });
}, te = (t) => {
  for (; ; ) {
    const e = ne(
      t,
      () => t.work.advance(Cn(t) ? kn : void 0)
    );
    if (!e) {
      C = t, tn(() => {
        C = null, gn(t);
      });
      return;
    }
    const n = Pn(t, e);
    if (!t.trace.mounted && t.attempt < pn && !ft(t.trace.snapshots) && mt() !== t.startVersion) {
      pt(t.trace.snapshots), t.attempt += 1, Dt(t);
      continue;
    }
    En(t.effects, n);
    return;
  }
}, gn = (t) => {
  if (t.originalWDom.il) {
    pt(t.trace.snapshots);
    return;
  }
  te(t);
}, Cn = (t) => cn() && !t.originalWDom.il, kn = () => st(), ot = (t) => {
  const e = Ot(t, "vd");
  return e && e.value;
}, ee = () => {
  const t = C;
  C = null, en(), pt(t.trace.snapshots);
};
f.settle = (t) => {
  var n;
  if (!C) return;
  const e = C;
  t && e.props !== t && !Wt(e.props, t) || (e.trace.mounted || ft(e.trace.snapshots) ? nt() : (ee(), (n = h.get(e.props)) == null || n.up()));
};
let F = null;
const ne = (t, e) => {
  const n = N, s = F;
  N = t.trace, F = t.effects, M.value = !0;
  try {
    return e();
  } finally {
    M.value = !1, N = n, F = s;
  }
}, Pn = (t, e) => {
  var i;
  const { originalWDom: n, effects: s } = t, { isRoot: c, getParent: o, we: r, ae: l } = n;
  if (e.getParent && e.getParent !== o && ((i = f.reparent) == null || i.call(f, e)), e.getParent = o, !c && o) {
    const a = o(), p = a && a.children || [], P = p.indexOf(n);
    s.push(() => {
      P !== -1 && p.splice(P, 1, e), fn(a, n, e);
    });
  } else
    e.isRoot = !0, e.we = r, e.ae = l;
  return e;
}, En = (t, e) => {
  He(t), tt(e), Ht();
}, Rn = (t, e, n) => {
  if (It(t))
    return at(e, ...n);
  if (K(t)) {
    const s = ht(t, e, n);
    if (M.value)
      return s;
    const c = dt(s).resolve();
    return c.rs = s, c;
  }
  return {
    type: "e",
    // element
    // Declared on every new node: a diff sets it, and a drawn node keeps it
    // ('N'), so the node keeps its shape and reading it is a plain lookup.
    nr: void 0,
    [S]: !0,
    tag: t,
    props: e,
    children: n
  };
}, se = (t, e) => {
  const n = () => t.value;
  return e.map((s) => {
    var o;
    const c = oe(s);
    return c.getParent && ((o = f.reparent) == null || o.call(f, c)), c.getParent = n, c;
  });
}, oe = (t) => {
  if (t == null || typeof t == "boolean")
    return { type: null, nr: void 0, [S]: !0 };
  if (Array.isArray(t)) {
    const e = { value: void 0 }, n = se(e, t), s = {
      type: "l",
      // loop (array mapping)
      nr: void 0,
      [S]: !0,
      children: n
    };
    return e.value = s, s;
  } else if (typeof t == "string" || typeof t == "number")
    return { type: "t", nr: void 0, [S]: !0, text: t };
  return t;
}, bn = (t, e, n) => (s = e) => {
  const c = M.value, o = k.value;
  M.value = !1;
  try {
    dn(), fe(s, t);
    const r = t(e, n);
    let l;
    if (typeof r == "function") {
      const i = r;
      l = Lt.has(i) ? i(e, n) : i(wt(s), e, n);
    } else {
      let i = !0;
      l = (a) => i ? (i = !1, r) : t(a, n);
    }
    return Sn(
      l,
      s,
      t,
      e,
      n
    );
  } finally {
    k.value = o, M.value = c;
  }
}, ce = (t) => t.ctor ? dt(
  t.rs || {
    ctor: t.ctor,
    props: t.compProps,
    children: t.compChild
  }
) : {
  type: t.type,
  tag: t.tag,
  props: t.props,
  text: t.text,
  children: t.children && [...t.children],
  getParent: t.getParent,
  [S]: !0
}, dt = ({
  ctor: t,
  props: e,
  children: n
}) => ht(t, { ...e }, [...n || []]), ht = (t, e, n) => {
  const s = t, c = n, o = bn(t, e, c);
  return { ctor: s, props: e, children: c, resolve: o };
}, Sn = (t, e, n, s, c) => {
  const o = (a) => oe(t(a)), { wrappedComponentMaker: r, customNode: l } = Nn(
    o,
    s
  ), i = Mn(
    r,
    e,
    n,
    s,
    c
  );
  return re(l, e, n, s, c, i), l;
}, Mn = (t, e, n, s, c) => {
  const o = () => xn(t, e, n, s, c, o);
  return o;
}, xn = (t, e, n, s, c, o) => {
  const r = k.value;
  try {
    hn(e), ae(e), un();
    const l = t(s);
    return re(l, e, n, s, c, o), l;
  } finally {
    k.value = r;
  }
}, Nn = (t, e) => {
  const n = (c) => {
    var l;
    const o = t(c), r = at({}, o);
    return o.getParent && ((l = f.reparent) == null || l.call(f, o)), o.getParent = () => r, r;
  }, s = n(e);
  return { wrappedComponentMaker: n, customNode: s };
}, re = (t, e, n, s, c, o) => {
  de(t, {
    compProps: s,
    compChild: c,
    ctor: n,
    compKey: e,
    reRender: o
  });
  const r = () => {
    ln(
      e,
      () => yn(
        n,
        t.compProps || s,
        t.compChild || c,
        t
      )
    );
    const l = Ot(e, "vd");
    l && (l.value = t);
  };
  F ? F.push(r) : r();
}, Kn = (t) => ({ value: t }), Yn = () => Promise.resolve(), Xn = () => {
  const t = ue();
  return t ? wt(t) : () => !1;
};
export {
  at as Fragment,
  h as componentMap,
  wt as componentUpdate,
  Un as deferRender,
  An as disposeComponentEntry,
  ue as getComponentKey,
  Ot as getComponentSubInfo,
  an as h,
  Vn as hasPending,
  Ln as isPropType,
  Hn as lmount,
  Lt as lmountComponentSet,
  zn as mount,
  Bn as mountCallback,
  On as mountReadyCallback,
  Yn as nextTick,
  In as notifyStoreWrite,
  jn as portal,
  Kn as ref,
  Fn as render,
  yn as replaceWDom,
  Tn as setComponentMapManualMode,
  mt as storeVersion,
  Qn as updateCallback,
  Xn as useRenew,
  _n as whenIdle
};
